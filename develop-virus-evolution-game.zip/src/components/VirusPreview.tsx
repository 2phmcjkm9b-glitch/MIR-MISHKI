import { useEffect, useRef } from "react";
import { buildTraits } from "../game/data";
import { drawVirusPreview } from "../game/draw";
import type { MutationDef } from "../game/types";

interface Props {
  levels: Record<string, number>;
  preview?: MutationDef | null;
  size?: number;
  scale?: number;
  className?: string;
}

/** Live animated specimen — shows exactly what the virus currently looks like. */
export function VirusPreview({
  levels,
  preview = null,
  size = 130,
  scale = 1.5,
  className = "",
}: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const levelsRef = useRef(levels);
  levelsRef.current = levels;

  const key = preview
    ? `${preview.id}:${(levels[preview.id] ?? 0) + 1}`
    : JSON.stringify(levels);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.round(size * dpr);
    c.height = Math.round(size * dpr);
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const lv = { ...levelsRef.current };
    if (preview) lv[preview.id] = (lv[preview.id] ?? 0) + 1;
    const traits = buildTraits(lv);
    let raf = 0;
    const t0 = performance.now();
    const loop = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      drawVirusPreview(ctx, traits, (t - t0) / 1000, size, size, scale);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, size, scale]);

  return (
    <canvas
      ref={ref}
      style={{ width: size, height: size }}
      className={className}
    />
  );
}
