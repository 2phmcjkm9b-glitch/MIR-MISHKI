import { memo } from "react";
import type { HudSnapshot } from "../game/types";
import { formatTime } from "../game/math";
import { MUTATION_BY_ID } from "../game/data";

interface Props {
  hud: HudSnapshot;
  muted: boolean;
  onPause: () => void;
  onMute: () => void;
  onDash: () => void;
}

function Stat({
  label,
  value,
  accent = "#dff7e6",
}: {
  label: string;
  value: string;
  accent?: string;
}) {
  return (
    <div className="flex flex-col items-end leading-none">
      <span className="mono text-[8px] tracking-[0.22em] text-emerald-200/50 sm:text-[9px]">
        {label}
      </span>
      <span
        className="display text-base sm:text-xl"
        style={{ color: accent, textShadow: `0 0 14px ${accent}55` }}
      >
        {value}
      </span>
    </div>
  );
}

export const Hud = memo(function Hud({
  hud,
  muted,
  onPause,
  onMute,
  onDash,
}: Props) {
  const hpPct = Math.max(0, (hud.hp / hud.maxHp) * 100);
  const quotaPct = Math.min(100, (hud.collected / hud.quota) * 100);
  const evolvePct = Math.min(100, (hud.dna / hud.dnaNeeded) * 100);
  const evolveReady = hud.dna >= hud.dnaNeeded;
  const lowHp = hpPct < 33;

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* ---------------- top bar ---------------- */}
      <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-2 sm:p-4">
        {/* stage */}
        <div className="hud-chip rounded-xl px-2.5 py-1.5 sm:px-3.5 sm:py-2">
          <div className="mono text-[8px] tracking-[0.25em] text-emerald-200/50 sm:text-[9px]">
            SECTOR {hud.stageIndex + 1}/{hud.stageCount}
          </div>
          <div className="display text-[11px] leading-tight text-emerald-100 sm:text-sm">
            {hud.stageName}
          </div>
          <div className="mono mt-0.5 flex gap-2 text-[9px] text-emerald-200/60 sm:text-[10px]">
            <span>⏱ {formatTime(hud.time)}</span>
            <span>☠ {hud.kills}</span>
          </div>
        </div>

        {/* genome quota */}
        <div className="hud-chip hidden min-w-[220px] max-w-[340px] flex-1 rounded-xl px-3 py-2 sm:block">
          <div className="mono mb-1 flex items-center justify-between text-[9px] tracking-[0.18em]">
            <span className={hud.locked ? "text-rose-300/80" : "text-lime-300"}>
              {hud.locked ? "🔒 HOST MEMBRANE" : "◉ HOST CELL OPEN"}
            </span>
            <span className="text-emerald-100/80">
              {hud.collected}/{hud.quota} DNA
            </span>
          </div>
          <div className="bar-track h-2.5">
            <div
              className="bar-fill"
              style={{
                width: `${quotaPct}%`,
                background: hud.locked
                  ? "linear-gradient(90deg,#ff6b81,#ffd45e)"
                  : "linear-gradient(90deg,#c8ff4d,#7dff5e)",
                boxShadow: "0 0 14px rgba(200,255,77,0.45)",
              }}
            />
          </div>
        </div>

        {/* score */}
        <div className="flex items-start gap-1.5 sm:gap-2">
          <div className="hud-chip rounded-xl px-2.5 py-1.5 text-right sm:px-3.5 sm:py-2">
            <Stat label="SCORE" value={hud.score.toLocaleString()} />
            {hud.combo > 1.05 && (
              <div
                className="display mt-0.5 text-right text-[11px] sm:text-sm"
                style={{ color: "#ffe066" }}
              >
                ×{hud.combo.toFixed(2)}
              </div>
            )}
          </div>
          <div className="pointer-events-auto flex flex-col gap-1.5">
            <button
              onClick={onPause}
              className="btn btn-ghost !px-2.5 !py-2 !text-[10px] sm:!px-3"
              aria-label="Pause"
            >
              ❙❙
            </button>
            <button
              onClick={onMute}
              className="btn btn-ghost !px-2.5 !py-2 !text-[10px] sm:!px-3"
              aria-label="Toggle sound"
            >
              {muted ? "🔇" : "🔊"}
            </button>
          </div>
        </div>
      </div>

      {/* mobile quota bar */}
      <div className="absolute inset-x-2 top-[68px] sm:hidden">
        <div className="mono mb-0.5 flex justify-between text-[8px] tracking-[0.16em] text-emerald-200/70">
          <span>{hud.locked ? "🔒 HOST" : "◉ OPEN"}</span>
          <span>
            {hud.collected}/{hud.quota} DNA
          </span>
        </div>
        <div className="bar-track h-2">
          <div
            className="bar-fill"
            style={{
              width: `${quotaPct}%`,
              background: hud.locked
                ? "linear-gradient(90deg,#ff6b81,#ffd45e)"
                : "linear-gradient(90deg,#c8ff4d,#7dff5e)",
            }}
          />
        </div>
      </div>

      {/* boss bar */}
      {hud.bossHp >= 0 && (
        <div className="absolute inset-x-0 top-[104px] mx-auto w-[70%] max-w-md sm:top-20">
          <div className="mono mb-1 text-center text-[9px] tracking-[0.3em] text-orange-300">
            SENTINEL
          </div>
          <div className="bar-track h-2.5">
            <div
              className="bar-fill"
              style={{
                width: `${hud.bossHp * 100}%`,
                background: "linear-gradient(90deg,#ff7a2f,#ffd45e)",
                boxShadow: "0 0 16px rgba(255,122,47,0.6)",
              }}
            />
          </div>
        </div>
      )}

      {/* ---------------- bottom-left: vitals ---------------- */}
      <div className="absolute bottom-2 left-2 w-[46%] max-w-[290px] sm:bottom-4 sm:left-4">
        <div className="hud-chip rounded-xl px-2.5 py-2 sm:px-3 sm:py-2.5">
          <div className="mono mb-1 flex items-center justify-between text-[9px] tracking-[0.18em]">
            <span className={lowHp ? "text-rose-300" : "text-emerald-200/70"}>
              {lowHp ? "⚠ INTEGRITY" : "INTEGRITY"}
            </span>
            <span className="text-emerald-100/80">
              {Math.ceil(hud.hp)}/{Math.round(hud.maxHp)}
            </span>
          </div>
          <div className="bar-track h-3">
            <div
              className="bar-fill"
              style={{
                width: `${hpPct}%`,
                background: lowHp
                  ? "linear-gradient(90deg,#ff2d55,#ff8a3d)"
                  : "linear-gradient(90deg,#7dff9c,#5ef0ff)",
                boxShadow: lowHp
                  ? "0 0 16px rgba(255,45,85,0.6)"
                  : "0 0 14px rgba(125,255,156,0.4)",
              }}
            />
          </div>

          {/* evolve meter */}
          <div className="mono mt-2 flex items-center justify-between text-[9px] tracking-[0.18em]">
            <span
              className={evolveReady ? "ready-flash text-lime-300" : "text-emerald-200/60"}
            >
              {evolveReady ? "✦ MUTATION READY" : "EVOLVE"}
            </span>
            <span className="text-emerald-100/80">
              {Math.floor(hud.dna)}/{hud.dnaNeeded}
            </span>
          </div>
          <div className="bar-track mt-1 h-2">
            <div
              className="bar-fill"
              style={{
                width: `${evolvePct}%`,
                background: evolveReady
                  ? "linear-gradient(90deg,#fff,#c8ff4d)"
                  : "linear-gradient(90deg,#3ddc97,#7dff5e)",
              }}
            />
          </div>

          {/* shields */}
          {hud.shieldMax > 0 && (
            <div className="mt-2 flex gap-1">
              {Array.from({ length: hud.shieldMax }).map((_, i) => (
                <span
                  key={i}
                  className="h-2.5 w-2.5 rounded-full"
                  style={{
                    background:
                      i < hud.shield ? "#6ea8ff" : "rgba(110,168,255,0.18)",
                    boxShadow: i < hud.shield ? "0 0 10px #6ea8ff" : "none",
                  }}
                />
              ))}
            </div>
          )}

          {/* mutation pills */}
          {Object.keys(hud.levels).length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {Object.entries(hud.levels)
                .filter(([, lv]) => lv > 0)
                .map(([id, lv]) => {
                  const def = MUTATION_BY_ID[id];
                  if (!def) return null;
                  return (
                    <span
                      key={id}
                      className="mono rounded-md px-1.5 py-0.5 text-[8px] tracking-wider"
                      style={{
                        color: def.tint,
                        border: `1px solid ${def.tint}44`,
                        background: `${def.tint}14`,
                      }}
                    >
                      {def.name.toUpperCase()} {lv}
                    </span>
                  );
                })}
            </div>
          )}
        </div>
      </div>

      {/* ---------------- hint ---------------- */}
      {hud.hint && (
        <div className="absolute inset-x-0 bottom-32 flex justify-center px-4 sm:bottom-16">
          <div
            key={hud.hint}
            className="hint-in glass-soft max-w-[86%] rounded-full px-4 py-2 text-center"
          >
            <span className="mono text-[10px] tracking-[0.12em] text-emerald-100/90 sm:text-xs">
              {hud.hint}
            </span>
          </div>
        </div>
      )}

      {/* ---------------- dash button (touch) ---------------- */}
      {hud.touch && (
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            onDash();
          }}
          className="pointer-events-auto absolute bottom-6 right-4 flex h-20 w-20 flex-col items-center justify-center rounded-full border-2 border-emerald-300/40 bg-emerald-400/15 backdrop-blur-sm active:scale-95 active:bg-emerald-300/40"
          style={{ opacity: 0.55 + hud.dashReady * 0.45 }}
        >
          <span className="text-2xl">⚡</span>
          <span className="mono text-[8px] tracking-[0.2em] text-emerald-100">
            DASH
          </span>
          <span
            className="absolute bottom-1.5 h-1 w-10 overflow-hidden rounded-full bg-black/50"
            aria-hidden
          >
            <span
              className="block h-full rounded-full bg-lime-300"
              style={{ width: `${hud.dashReady * 100}%` }}
            />
          </span>
        </button>
      )}

      {/* keyboard dash meter (desktop) */}
      {!hud.touch && (
        <div className="absolute bottom-3 right-4 hidden items-center gap-2 sm:flex">
          <span className="mono text-[9px] tracking-[0.2em] text-emerald-200/50">
            DASH
          </span>
          <div className="bar-track h-2 w-24">
            <div
              className="bar-fill"
              style={{
                width: `${hud.dashReady * 100}%`,
                background: "linear-gradient(90deg,#5ef0ff,#c8ff4d)",
              }}
            />
          </div>
          <span className="mono rounded border border-emerald-300/25 px-1.5 py-0.5 text-[9px] text-emerald-200/70">
            SPACE
          </span>
        </div>
      )}
    </div>
  );
});
