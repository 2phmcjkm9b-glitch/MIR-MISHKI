import type { HudSnapshot, MutationDef, ScoreEntry } from "../game/types";
import { STAGES } from "../game/data";
import { formatTime } from "../game/math";
import { VirusPreview } from "./VirusPreview";

/* ------------------------------------------------------------------ */

export function ScoreTable({
  scores,
  title = "LOCAL HIGH SCORES",
}: {
  scores: ScoreEntry[];
  title?: string;
}) {
  return (
    <div className="w-full">
      <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
        {title}
      </div>
      {scores.length === 0 ? (
        <div className="mono rounded-lg border border-emerald-300/10 bg-black/30 px-3 py-3 text-center text-[10px] tracking-widest text-emerald-200/40">
          NO INFECTIONS RECORDED — BE FIRST
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-emerald-300/12 bg-black/35">
          {scores.map((s, i) => (
            <div
              key={`${s.date}-${i}-${s.score}`}
              className={`mono flex items-center gap-2 px-2.5 py-1.5 text-[10px] tracking-wider ${
                i % 2 ? "bg-white/[0.02]" : ""
              }`}
            >
              <span
                className="w-5 shrink-0 text-center font-bold"
                style={{ color: i === 0 ? "#ffe066" : "#7dffb0aa" }}
              >
                {i + 1}
              </span>
              <span className="flex-1 text-right text-emerald-100">
                {s.score.toLocaleString()}
              </span>
              <span className="w-20 shrink-0 text-center text-emerald-200/50">
                {s.victory ? "★ CLEAR" : `SEC ${s.stage + 1}`}
              </span>
              <span className="hidden w-16 shrink-0 text-center text-emerald-200/40 sm:block">
                {s.evolutions} MUT
              </span>
              <span className="hidden w-16 shrink-0 text-right text-emerald-200/30 sm:block">
                {s.date}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatBox({ label, value, tint }: { label: string; value: string; tint?: string }) {
  return (
    <div className="rounded-lg border border-emerald-300/12 bg-black/30 px-2 py-1.5 text-center">
      <div className="mono text-[8px] tracking-[0.2em] text-emerald-200/45">
        {label}
      </div>
      <div
        className="display text-sm sm:text-base"
        style={{ color: tint ?? "#dff7e6" }}
      >
        {value}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function StartScreen({
  onStart,
  onHelp,
  scores,
  muted,
  onMute,
}: {
  onStart: () => void;
  onHelp: () => void;
  scores: ScoreEntry[];
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-between overflow-hidden p-4 sm:p-8">
      <div className="scanlines pointer-events-none absolute inset-0 opacity-40" />

      <header className="relative z-10 mt-2 text-center sm:mt-6">
        <div className="mono mb-1 text-[9px] tracking-[0.5em] text-emerald-300/60 sm:text-[11px]">
          SPECIMEN 0-1 · LIVE CULTURE
        </div>
        <h1
          className="display title-glitch text-5xl leading-none sm:text-7xl md:text-8xl"
          style={{
            color: "#c8ff4d",
            textShadow:
              "0 0 22px rgba(200,255,77,0.55), 0 0 70px rgba(125,255,94,0.28), 0 6px 0 #0b3b18",
          }}
        >
          VIRUS
        </h1>
        <div className="mono mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[9px] tracking-[0.28em] text-emerald-200/60 sm:text-[11px]">
          <span>COLLECT DNA</span>
          <span className="text-lime-400">◆</span>
          <span>EVOLVE</span>
          <span className="text-lime-400">◆</span>
          <span>INFECT THE HOST</span>
        </div>
      </header>

      <div className="relative z-10 hidden flex-1 sm:block" />

      <div className="relative z-10 mb-1 w-full max-w-5xl">
        <div className="grid gap-3 sm:grid-cols-[1.1fr_0.9fr]">
          <div className="glass pop-in rounded-2xl p-4">
            <div className="mono mb-2 text-[9px] tracking-[0.3em] text-emerald-200/50">
              MISSION BRIEF
            </div>
            <p className="mono mb-3 text-[11px] leading-relaxed text-emerald-100/80 sm:text-xs">
              You are a newborn spiky virus loose in a microscopic ecosystem.
              Harvest loose genetic material, mutate into something stronger and
              fight your way to the host cell in four very different chambers.
            </p>
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary glow-pulse" onClick={onStart}>
                ▶ START INFECTION
              </button>
              <button className="btn" onClick={onHelp}>
                ? HOW TO PLAY
              </button>
              <button className="btn btn-ghost !px-3" onClick={onMute}>
                {muted ? "🔇 SOUND OFF" : "🔊 SOUND ON"}
              </button>
            </div>
            <div className="mono mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[9px] tracking-[0.14em] text-emerald-200/45">
              <span>WASD / ARROWS / MOUSE / TOUCH</span>
              <span>SPACE = DASH</span>
              <span>ESC = PAUSE</span>
            </div>
          </div>
          <div className="glass-soft rounded-2xl p-3">
            <ScoreTable scores={scores} />
            <div className="mono mt-2 text-[9px] leading-relaxed tracking-wider text-emerald-200/40">
              4 SECTORS · 12 MUTATIONS × 3 TIERS · SCORES SAVED LOCALLY
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function Briefing({ hud, onBegin }: { hud: HudSnapshot; onBegin: () => void }) {
  const stage = STAGES[hud.stageIndex];
  const threats = Object.entries(stage.spawns)
    .map(([k]) => k)
    .filter((k) => k !== "sentinel");
  return (
    <div
      className="absolute inset-0 flex items-center justify-center bg-black/45 p-4 backdrop-blur-[2px]"
      onClick={onBegin}
    >
      <div className="glass pop-in w-full max-w-lg rounded-2xl p-5 text-center">
        <div className="mono text-[9px] tracking-[0.4em] text-emerald-300/60">
          SECTOR {hud.stageIndex + 1} OF {hud.stageCount}
        </div>
        <h2
          className="display mt-1 text-2xl sm:text-4xl"
          style={{ color: "#c8ff4d", textShadow: "0 0 24px rgba(200,255,77,0.4)" }}
        >
          {stage.name}
        </h2>
        <div className="mono mt-1 text-[10px] tracking-[0.2em] text-emerald-200/60">
          {stage.subtitle}
        </div>
        <p className="mono mt-3 text-[11px] leading-relaxed text-emerald-100/75 sm:text-xs">
          {stage.brief}
        </p>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <StatBox label="DNA QUOTA" value={`${stage.quota}`} tint="#c8ff4d" />
          <StatBox label="THREATS" value={`${threats.length}`} tint="#ff8a8a" />
          <StatBox label="HAZARDS" value={`${stage.acids.length + stage.currents.length}`} tint="#ffd45e" />
        </div>

        {Object.values(hud.levels).some((v) => v > 0) && (
          <div className="mono mt-3 text-[9px] tracking-[0.18em] text-emerald-200/50">
            CARRYING {Object.entries(hud.levels).filter(([, v]) => v > 0).length}{" "}
            MUTATIONS
          </div>
        )}

        <button className="btn btn-primary mt-4 w-full" onClick={onBegin}>
          ▶ BEGIN (ENTER / TAP)
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function MutationCard({
  def,
  level,
  levels,
  selected,
  index,
  onChoose,
  onHover,
}: {
  def: MutationDef;
  level: number;
  levels: Record<string, number>;
  selected: boolean;
  index: number;
  onChoose: () => void;
  onHover: () => void;
}) {
  const next = level + 1;
  return (
    <button
      onClick={onChoose}
      onMouseEnter={onHover}
      className={`card-sel glass relative flex flex-col items-center overflow-hidden rounded-2xl p-3 text-center ${
        selected ? "sel" : ""
      }`}
      style={{
        borderColor: selected ? def.tint : "rgba(125,255,150,0.14)",
        boxShadow: selected
          ? `0 0 34px ${def.tint}66, inset 0 0 30px ${def.tint}22`
          : undefined,
      }}
    >
      <span
        className="mono absolute left-2 top-2 rounded px-1.5 py-0.5 text-[8px] tracking-widest"
        style={{ color: def.tint, border: `1px solid ${def.tint}55` }}
      >
        {index + 1}
      </span>
      <span
        className="mono absolute right-2 top-2 rounded px-1.5 py-0.5 text-[8px] tracking-widest"
        style={{ color: def.tint, border: `1px solid ${def.tint}55` }}
      >
        {level > 0 ? `LV ${level}→${next}` : "NEW"}
      </span>

      <VirusPreview
        levels={levels}
        preview={def}
        size={92}
        scale={1.15}
        className="mt-3"
      />

      <div className="display mt-1 text-base leading-tight" style={{ color: def.tint }}>
        {def.name}
      </div>
      <div className="mono text-[8px] tracking-[0.22em] text-emerald-200/45">
        {def.kind.toUpperCase()}
      </div>
      <p className="mono mt-2 text-[10px] leading-snug text-emerald-100/75">
        {def.levels[Math.min(2, next - 1)]}
      </p>
      <div className="mt-2 flex gap-1">
        {[1, 2, 3].map((i) => (
          <span
            key={i}
            className="h-1.5 w-5 rounded-full"
            style={{
              background: i <= next ? def.tint : "rgba(255,255,255,0.12)",
              boxShadow: i <= next ? `0 0 8px ${def.tint}` : "none",
            }}
          />
        ))}
      </div>
    </button>
  );
}

export function MutationModal({
  hud,
  selected,
  onChoose,
  onSelect,
}: {
  hud: HudSnapshot;
  selected: number;
  onChoose: (id: string) => void;
  onSelect: (i: number) => void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 p-3 backdrop-blur-sm sm:p-6">
      <div className="pop-in w-full max-w-4xl">
        <div className="mb-3 text-center">
          <div className="mono text-[9px] tracking-[0.45em] text-lime-300/70">
            GENOME SATURATED
          </div>
          <h2
            className="display text-2xl sm:text-4xl"
            style={{
              color: "#c8ff4d",
              textShadow: "0 0 26px rgba(200,255,77,0.45)",
            }}
          >
            MUTATION AVAILABLE
          </h2>
          <div className="mono mt-1 text-[10px] tracking-[0.2em] text-emerald-200/60">
            PICK ONE ADAPTATION — YOUR BODY CHANGES PERMANENTLY
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {hud.choices.map((def, i) => (
            <MutationCard
              key={def.id}
              def={def}
              level={hud.levels[def.id] ?? 0}
              index={i}
              selected={i === selected}
              levels={hud.levels}
              onChoose={() => onChoose(def.id)}
              onHover={() => onSelect(i)}
            />
          ))}
        </div>

        <div className="mono mt-3 text-center text-[9px] tracking-[0.22em] text-emerald-200/45">
          PRESS 1 · 2 · 3 OR CLICK — MUTATIONS STACK AND GROW OVER A RUN
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function PauseOverlay({
  hud,
  onResume,
  onNewRun,
  onRetryStage,
  onMenu,
  onHelp,
  muted,
  onMute,
}: {
  hud: HudSnapshot;
  onResume: () => void;
  onNewRun: () => void;
  onRetryStage: () => void;
  onMenu: () => void;
  onHelp: () => void;
  muted: boolean;
  onMute: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/65 p-4 backdrop-blur-md">
      <div className="glass pop-in w-full max-w-md rounded-2xl p-5">
        <div className="mono text-center text-[9px] tracking-[0.45em] text-emerald-300/60">
          CULTURE SUSPENDED
        </div>
        <h2
          className="display mb-3 text-center text-3xl sm:text-4xl"
          style={{ color: "#7dff5e", textShadow: "0 0 22px rgba(125,255,94,0.4)" }}
        >
          PAUSED
        </h2>

        <div className="mb-3 grid grid-cols-3 gap-2">
          <StatBox label="SCORE" value={hud.score.toLocaleString()} tint="#c8ff4d" />
          <StatBox label="DNA" value={`${hud.collected}/${hud.quota}`} />
          <StatBox label="TIME" value={formatTime(hud.time)} />
        </div>

        <div className="grid gap-2">
          <button className="btn btn-primary" onClick={onResume}>
            ▶ RESUME (ESC)
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button className="btn" onClick={onRetryStage}>
              ↻ RESTART SECTOR
            </button>
            <button className="btn" onClick={onHelp}>
              ? CONTROLS
            </button>
            <button className="btn" onClick={onMute}>
              {muted ? "🔇 SOUND OFF" : "🔊 SOUND ON"}
            </button>
            <button className="btn btn-ghost" onClick={onNewRun}>
              ⟲ NEW RUN
            </button>
          </div>
          <button className="btn btn-ghost" onClick={onMenu}>
            ⌂ MAIN MENU
          </button>
        </div>
        <div className="mono mt-3 text-center text-[9px] tracking-[0.2em] text-emerald-200/40">
          ALL TIMERS AND ORGANISMS ARE FROZEN
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function StageClear({
  hud,
  onNext,
  onRetry,
}: {
  hud: HudSnapshot;
  onNext: () => void;
  onRetry: () => void;
}) {
  const nextStage = STAGES[Math.min(hud.stageIndex + 1, STAGES.length - 1)];
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md">
      <div className="glass pop-in w-full max-w-md rounded-2xl p-5 text-center">
        <div className="mono text-[9px] tracking-[0.45em] text-lime-300/70">
          HOST CELL BREACHED
        </div>
        <h2
          className="display text-3xl sm:text-5xl"
          style={{ color: "#c8ff4d", textShadow: "0 0 28px rgba(200,255,77,0.5)" }}
        >
          SECTOR CLEARED
        </h2>

        <div className="my-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <StatBox label="SCORE" value={hud.score.toLocaleString()} tint="#c8ff4d" />
          <StatBox label="DNA" value={`${hud.dnaTotal}`} />
          <StatBox label="KILLS" value={`${hud.kills}`} />
          <StatBox label="TIME" value={formatTime(hud.time)} />
        </div>

        <div className="glass-soft mb-3 rounded-xl p-3">
          <div className="mono text-[8px] tracking-[0.3em] text-emerald-200/45">
            NEXT SECTOR
          </div>
          <div className="display text-lg text-emerald-100">{nextStage.name}</div>
          <div className="mono text-[9px] tracking-[0.18em] text-emerald-200/50">
            {nextStage.subtitle}
          </div>
        </div>

        <div className="grid gap-2">
          <button className="btn btn-primary glow-pulse" onClick={onNext}>
            ▶ ENTER NEXT SECTOR
          </button>
          <button className="btn btn-ghost" onClick={onRetry}>
            ↻ REPLAY THIS SECTOR
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function RunEnd({
  hud,
  scores,
  victory,
  onNewRun,
  onRetry,
  onMenu,
}: {
  hud: HudSnapshot;
  scores: ScoreEntry[];
  victory: boolean;
  onNewRun: () => void;
  onRetry: () => void;
  onMenu: () => void;
}) {
  const rank =
    hud.score > 12000
      ? "S — LEGENDARY PATHOGEN"
      : hud.score > 8000
        ? "A — VIRULENT STRAIN"
        : hud.score > 4500
          ? "B — AGGRESSIVE STRAIN"
          : hud.score > 2000
            ? "C — STABLE STRAIN"
            : "D — FRAGILE STRAIN";

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-3 backdrop-blur-md sm:p-6">
      <div className="pop-in grid w-full max-w-3xl gap-3 sm:grid-cols-[1fr_0.85fr]">
        <div
          className="glass rounded-2xl p-5 text-center"
          style={{
            borderColor: victory ? "rgba(200,255,77,0.4)" : "rgba(255,45,85,0.35)",
          }}
        >
          <div className="mono text-[9px] tracking-[0.45em] text-emerald-300/60">
            {victory ? "FULL INFECTION ACHIEVED" : "CAPSID RUPTURED"}
          </div>
          <h2
            className="display text-3xl sm:text-5xl"
            style={{
              color: victory ? "#c8ff4d" : "#ff5f7e",
              textShadow: `0 0 28px ${victory ? "rgba(200,255,77,0.5)" : "rgba(255,95,126,0.5)"}`,
            }}
          >
            {victory ? "PANDEMIC" : "LYSED"}
          </h2>
          <p className="mono mt-1 text-[10px] leading-relaxed tracking-[0.14em] text-emerald-200/60">
            {victory
              ? "THE NUCLEUS IS YOURS. THE ORGANISM IS YOURS."
              : "THE IMMUNE SYSTEM WON THIS ROUND. EVOLVE HARDER."}
          </p>

          <div className="display my-3 text-4xl sm:text-5xl" style={{ color: "#ffe066" }}>
            {hud.score.toLocaleString()}
          </div>
          <div className="mono text-[9px] tracking-[0.3em] text-emerald-200/50">
            {rank}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatBox
              label="SECTOR"
              value={`${hud.stageIndex + 1}/${hud.stageCount}`}
            />
            <StatBox label="DNA" value={`${hud.dnaTotal}`} tint="#c8ff4d" />
            <StatBox label="KILLS" value={`${hud.kills}`} />
            <StatBox label="MUTATIONS" value={`${hud.evolutions}`} tint="#5ef0ff" />
          </div>

          <div className="mt-4 grid gap-2">
            <button className="btn btn-primary glow-pulse" onClick={onNewRun}>
              ⟲ INSTANT RESTART (R)
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button className="btn" onClick={onRetry}>
                ↻ RETRY SECTOR
              </button>
              <button className="btn btn-ghost" onClick={onMenu}>
                ⌂ MAIN MENU
              </button>
            </div>
          </div>
        </div>

        <div className="glass-soft rounded-2xl p-3">
          <ScoreTable scores={scores} />
          <div className="mono mt-3 text-[9px] leading-relaxed tracking-wider text-emerald-200/40">
            TIP: DASHING SHREDS SMALL ORGANISMS AND CANCELS THEIR DAMAGE. STACK
            HARVEST MUTATIONS EARLY, THEN GO ALL-IN ON OFFENSE.
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export function HelpModal({ onClose }: { onClose: () => void }) {
  const rows = [
    ["MOVE", "W A S D / Arrow keys"],
    ["STEER", "Hold the mouse — virus follows the cursor"],
    ["TOUCH", "Drag anywhere for a joystick"],
    ["DASH", "SPACE · SHIFT · right-click · DASH button"],
    ["PAUSE", "ESC or P"],
    ["RESTART", "R (when paused or dead)"],
    ["MUTATE", "1 · 2 · 3 or click a card"],
  ];
  const bestiary = [
    ["#ff9f5e", "MITE", "Harmless drifters. Dash through them for DNA."],
    ["#c98bff", "SPORE", "Splits in two when popped."],
    ["#ff6bd6", "MACROPHAGE", "Chases you on sight. Bait and juke it."],
    ["#ff7a2f", "SPIKE MINE", "Immobile, lethal on contact. Detonates."],
    ["#8fc6ff", "ANTIBODY", "Keeps range and fires tracking bolts."],
    ["#ffd45e", "SENTINEL", "Final guardian. Shielded until quota met."],
  ];
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/75 p-3 backdrop-blur-md sm:p-6">
      <div className="glass pop-in no-scrollbar max-h-full w-full max-w-2xl overflow-y-auto rounded-2xl p-5">
        <div className="mono text-[9px] tracking-[0.45em] text-emerald-300/60">
          FIELD MANUAL
        </div>
        <h2
          className="display mb-3 text-2xl sm:text-3xl"
          style={{ color: "#7dff5e" }}
        >
          HOW TO PLAY
        </h2>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
              CONTROLS
            </div>
            <div className="overflow-hidden rounded-lg border border-emerald-300/12">
              {rows.map(([k, v]) => (
                <div
                  key={k}
                  className="mono flex items-center justify-between gap-3 px-2.5 py-1.5 text-[10px] tracking-wider odd:bg-white/[0.02]"
                >
                  <span className="text-lime-300">{k}</span>
                  <span className="text-right text-emerald-100/70">{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="mono mb-1.5 text-[9px] tracking-[0.3em] text-emerald-200/50">
              BESTIARY
            </div>
            <div className="space-y-1.5">
              {bestiary.map(([c, n, d]) => (
                <div key={n} className="flex items-start gap-2">
                  <span
                    className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ background: c, boxShadow: `0 0 10px ${c}` }}
                  />
                  <div>
                    <span className="mono text-[10px] font-bold tracking-widest text-emerald-100">
                      {n}
                    </span>
                    <span className="mono block text-[10px] leading-snug text-emerald-200/60">
                      {d}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mono mt-4 rounded-lg border border-lime-300/20 bg-lime-300/5 p-3 text-[10px] leading-relaxed tracking-wider text-lime-200/80">
          <b className="text-lime-300">THE LOOP:</b> collect DNA → the EVOLVE bar
          fills → pick one of three mutations → your body visibly changes. Each
          sector needs a DNA quota before the host cell membrane opens. Dash into
          the open cell to infect it and advance.
        </div>

        <button className="btn btn-primary mt-4 w-full" onClick={onClose}>
          ✓ GOT IT
        </button>
      </div>
    </div>
  );
}
