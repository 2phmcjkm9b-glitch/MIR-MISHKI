import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "../game/engine";
import { Hud } from "./Hud";
import {
  Briefing,
  HelpModal,
  MutationModal,
  PauseOverlay,
  RunEnd,
  StageClear,
  StartScreen,
} from "./Overlays";
import { loadScores } from "../game/save";
import type { HudSnapshot, Phase, ScoreEntry } from "../game/types";

const EMPTY_HUD: HudSnapshot = {
  phase: "menu",
  hp: 100,
  maxHp: 100,
  dna: 0,
  dnaNeeded: 8,
  collected: 0,
  quota: 18,
  score: 0,
  combo: 1,
  stageIndex: 0,
  stageCount: 4,
  stageName: "",
  stageSubtitle: "",
  time: 0,
  kills: 0,
  shield: 0,
  shieldMax: 0,
  dashReady: 1,
  hint: "",
  choices: [],
  levels: {},
  dnaTotal: 0,
  evolutions: 0,
  locked: true,
  bossHp: -1,
  touch: false,
  muted: false,
};

export function GameShell() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);

  const [hud, setHud] = useState<HudSnapshot>(EMPTY_HUD);
  const [phase, setPhase] = useState<Phase>("menu");
  const [help, setHelp] = useState(false);
  const [sel, setSel] = useState(0);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const muted = hud.muted;

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const game = new Game(canvas, wrap, {
      onHud: setHud,
      onPhase: setPhase,
    });
    gameRef.current = game;
    game.start();
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  // Refresh the local high-score table whenever a run ends.
  useEffect(() => {
    if (phase === "dead" || phase === "won") setScores(loadScores());
  }, [phase]);

  useEffect(() => {
    if (phase === "mutate") setSel(0);
  }, [phase]);

  const g = () => gameRef.current;

  const start = useCallback(() => {
    g()?.startRun();
  }, []);
  const openHelp = useCallback(() => {
    const game = g();
    if (game && game.phase === "playing") game.pause();
    setHelp(true);
  }, []);
  const closeHelp = useCallback(() => setHelp(false), []);
  const toggleMute = useCallback(() => {
    g()?.toggleMute();
  }, []);

  // Keyboard shortcuts for the overlay screens (the engine handles in-game keys).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const game = gameRef.current;
      if (!game) return;
      if (help) {
        if (k === "escape" || k === "enter" || k === "h") setHelp(false);
        return;
      }
      if (phase === "mutate") {
        const n = hud.choices.length;
        if (k === "arrowleft" || k === "arrowup") {
          setSel((s) => (s - 1 + n) % n);
          e.preventDefault();
        } else if (k === "arrowright" || k === "arrowdown") {
          setSel((s) => (s + 1) % n);
          e.preventDefault();
        } else if (k === "1" || k === "2" || k === "3") {
          const idx = Number(k) - 1;
          if (hud.choices[idx]) game.choose(hud.choices[idx].id);
        } else if (k === "enter") {
          if (hud.choices[sel]) game.choose(hud.choices[sel].id);
        }
        return;
      }
      if (phase === "briefing" && (k === " " || k === "enter")) {
        game.beginStage();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, help, hud.choices, sel]);

  const showHud =
    phase === "playing" ||
    phase === "paused" ||
    phase === "briefing" ||
    phase === "mutate" ||
    phase === "clear" ||
    phase === "dead" ||
    phase === "won";

  return (
    <div
      ref={wrapRef}
      className="absolute inset-0 overflow-hidden bg-[#030a0e]"
      style={{ touchAction: "none" }}
    >
      <canvas
        ref={canvasRef}
        className="block h-full w-full"
        style={{ touchAction: "none" }}
      />

      {showHud && (
        <Hud
          hud={hud}
          muted={muted}
          onPause={() => g()?.pause()}
          onMute={toggleMute}
          onDash={() => g()?.requestDash()}
        />
      )}

      {phase === "menu" && !help && (
        <StartScreen
          onStart={start}
          onHelp={openHelp}
          scores={scores}
          muted={muted}
          onMute={toggleMute}
        />
      )}

      {phase === "briefing" && (
        <Briefing hud={hud} onBegin={() => g()?.beginStage()} />
      )}

      {phase === "mutate" && (
        <MutationModal
          hud={hud}
          selected={sel}
          onSelect={setSel}
          onChoose={(id) => g()?.choose(id)}
        />
      )}

      {phase === "paused" && !help && (
        <PauseOverlay
          hud={hud}
          onResume={() => g()?.resume()}
          onNewRun={start}
          onRetryStage={() => g()?.retryStage()}
          onMenu={() => g()?.toMenu()}
          onHelp={openHelp}
          muted={muted}
          onMute={toggleMute}
        />
      )}

      {phase === "clear" && (
        <StageClear
          hud={hud}
          onNext={() => g()?.nextStage()}
          onRetry={() => g()?.retryStage()}
        />
      )}

      {(phase === "dead" || phase === "won") && (
        <RunEnd
          hud={hud}
          scores={scores}
          victory={phase === "won"}
          onNewRun={start}
          onRetry={() => g()?.retryStage()}
          onMenu={() => g()?.toMenu()}
        />
      )}

      {help && <HelpModal onClose={closeHelp} />}

      <div className="portrait-hint pointer-events-none absolute inset-x-0 bottom-0 justify-center pb-1">
        <span className="mono rounded-full bg-black/60 px-2.5 py-1 text-[8px] tracking-[0.2em] text-emerald-200/60">
          ↻ ROTATE FOR A WIDER VIEW
        </span>
      </div>
    </div>
  );
}
