import { GameShell } from "./components/GameShell";

export default function App() {
  return (
    <div className="fixed inset-0 overflow-hidden bg-[#030a0e] text-emerald-50">
      <GameShell />
    </div>
  );
}
