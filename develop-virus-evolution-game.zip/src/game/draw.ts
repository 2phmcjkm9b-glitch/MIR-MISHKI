import type { Enemy, Palette, Particle, Pickup, Traits, Virus } from "./types";
import type { World } from "./world";
import { TAU, clamp, easeOut, roundRectPath } from "./math";

export interface View {
  x: number;
  y: number;
  w: number;
  h: number;
}

/* ------------------------------------------------------------------ */
/* Cached sprites                                                      */
/* ------------------------------------------------------------------ */

const glowCache = new Map<string, HTMLCanvasElement>();

export function getGlow(color: string): HTMLCanvasElement {
  const hit = glowCache.get(color);
  if (hit) return hit;
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const g = c.getContext("2d")!;
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, color);
  grad.addColorStop(0.35, withAlpha(color, 0.55));
  grad.addColorStop(1, withAlpha(color, 0));
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  glowCache.set(color, c);
  return c;
}

function withAlpha(color: string, a: number): string {
  if (color.startsWith("hsl")) {
    const inner = color.slice(color.indexOf("(") + 1, color.lastIndexOf(")"));
    return `hsl(${inner} / ${a})`;
  }
  if (color.startsWith("#")) {
    const hex = color.slice(1);
    const full =
      hex.length === 3
        ? hex
            .split("")
            .map((ch) => ch + ch)
            .join("")
        : hex.slice(0, 6);
    const n = parseInt(full, 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    return `rgba(${r},${g},${b},${a})`;
  }
  return color;
}

const tileCache = new Map<number, { canvas: HTMLCanvasElement; pattern: CanvasPattern | null }>();

function getTile(stageId: number, p: Palette, ctx: CanvasRenderingContext2D) {
  const hit = tileCache.get(stageId);
  if (hit) {
    if (!hit.pattern) hit.pattern = ctx.createPattern(hit.canvas, "repeat");
    return hit.pattern;
  }
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = withAlpha(p.blob, 0.1);
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 6 + Math.random() * 34;
    const rad = g.createRadialGradient(x, y, 0, x, y, r);
    rad.addColorStop(0, withAlpha(p.blob, 0.16));
    rad.addColorStop(1, withAlpha(p.blob, 0));
    g.fillStyle = rad;
    g.beginPath();
    g.arc(x, y, r, 0, TAU);
    g.fill();
  }
  g.strokeStyle = withAlpha(p.blob, 0.07);
  g.lineWidth = 2;
  for (let i = 0; i < 12; i++) {
    g.beginPath();
    const y = Math.random() * 256;
    g.moveTo(0, y);
    g.bezierCurveTo(80, y - 30, 160, y + 30, 256, y);
    g.stroke();
  }
  const entry = { canvas: c, pattern: ctx.createPattern(c, "repeat") };
  tileCache.set(stageId, entry);
  return entry.pattern;
}

function glow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  alpha = 1,
) {
  const before = ctx.globalAlpha;
  ctx.globalAlpha = alpha;
  ctx.drawImage(getGlow(color), x - r, y - r, r * 2, r * 2);
  ctx.globalAlpha = before;
}

/* ------------------------------------------------------------------ */
/* The player virus                                                    */
/* ------------------------------------------------------------------ */

export function drawVirus(
  ctx: CanvasRenderingContext2D,
  v: Virus,
  t: Traits,
  time: number,
  scaleUp = 1,
) {
  const r = v.r * scaleUp * (1 + Math.sin(v.pulse * 1.4) * 0.035 + v.morph * 0.25);
  const hue = t.bodyHue;
  const light = (l: number, s = 85) => `hsl(${hue} ${s}% ${l}%)`;

  // ---- Trail -----------------------------------------------------
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = v.trail.length - 1; i > 0; i--) {
    const p = v.trail[i];
    const k = 1 - i / v.trail.length;
    const a = p.a * k * 0.5;
    if (a < 0.02) continue;
    ctx.globalAlpha = a;
    ctx.fillStyle = light(60);
    ctx.beginPath();
    ctx.arc(p.x, p.y, r * (0.35 + k * 0.5), 0, TAU);
    ctx.fill();
  }
  ctx.restore();

  // ---- Harvest tendrils ------------------------------------------
  if (t.tendrils > 0) {
    ctx.save();
    ctx.strokeStyle = withAlpha("#8affe0", 0.4);
    ctx.lineWidth = 2;
    const n = 3 + t.tendrils;
    for (let i = 0; i < n; i++) {
      const back = v.angle + Math.PI;
      const spread = (i / (n - 1) - 0.5) * 1.7;
      const seg = 4 + t.tendrils;
      ctx.beginPath();
      for (let s = 0; s <= seg; s++) {
        const f = s / seg;
        const d = r * (1.1 + f * (2.4 + t.tendrils * 1.1));
        const wig = Math.sin(time * 5 + i * 1.7 + f * 5) * (6 + f * 14);
        const a = back + spread * f + (wig / 40) * f;
        const x = v.pos.x + Math.cos(a) * d;
        const y = v.pos.y + Math.sin(a) * d;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Flagellum -------------------------------------------------
  if (t.tail > 0) {
    ctx.save();
    ctx.lineCap = "round";
    const tails = t.tail >= 3 ? 2 : 1;
    for (let ti = 0; ti < tails; ti++) {
      const off = ti === 0 ? 0 : 0.34;
      const segs = 16;
      const L = r * (2.6 + t.tail * 0.85);
      ctx.strokeStyle = light(62);
      ctx.lineWidth = 5 - ti * 1.6;
      ctx.beginPath();
      for (let s = 0; s <= segs; s++) {
        const f = s / segs;
        const d = r * 0.9 + f * L;
        const wave =
          Math.sin(v.pulse * 3.4 - f * 6 + ti * 2) * (4 + f * (10 + t.tail * 4));
        const a = v.angle + Math.PI + off;
        const nx = Math.cos(a + Math.PI / 2) * wave;
        const ny = Math.sin(a + Math.PI / 2) * wave;
        const x = v.pos.x + Math.cos(a) * d + nx;
        const y = v.pos.y + Math.sin(a) * d + ny;
        if (s === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Magnet aura -----------------------------------------------
  if (t.aura > 80) {
    ctx.save();
    ctx.translate(v.pos.x, v.pos.y);
    ctx.rotate(time * 0.4);
    ctx.strokeStyle = withAlpha("#c98bff", 0.22);
    ctx.lineWidth = 2;
    ctx.setLineDash([12, 16]);
    ctx.beginPath();
    ctx.arc(0, 0, t.aura, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  ctx.save();
  ctx.translate(v.pos.x, v.pos.y);

  // ---- Cilia -----------------------------------------------------
  if (t.cilia > 0) {
    ctx.save();
    ctx.rotate(v.spin * 1.4);
    ctx.strokeStyle = withAlpha(light(70), 0.75);
    ctx.lineWidth = 1.6;
    const n = 14 + t.cilia * 8;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const beat = Math.sin(time * 16 + i * 0.9) * 0.35;
      const l = r + 5 + t.cilia * 2.5 + beat * 6;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      ctx.lineTo(Math.cos(a + beat * 0.3) * l, Math.sin(a + beat * 0.3) * l);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ---- Spikes ----------------------------------------------------
  ctx.save();
  ctx.rotate(v.spin);
  const spikeCount = t.spikes;
  for (let i = 0; i < spikeCount; i++) {
    const a = (i / spikeCount) * TAU;
    const wob = Math.sin(v.pulse * 2 + i * 1.3) * 0.16;
    const l = t.spikeLen * (1 + wob);
    const tipR = r + l;
    const halfW = 0.09 + t.spikeLen * 0.005;
    const grad = ctx.createLinearGradient(
      Math.cos(a) * r,
      Math.sin(a) * r,
      Math.cos(a) * tipR,
      Math.sin(a) * tipR,
    );
    grad.addColorStop(0, light(52));
    grad.addColorStop(1, t.thorns > 0 ? "#ff6b6b" : light(72));
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(
      Math.cos(a - halfW) * (r - 2),
      Math.sin(a - halfW) * (r - 2),
    );
    ctx.lineTo(Math.cos(a) * tipR, Math.sin(a) * tipR);
    ctx.lineTo(
      Math.cos(a + halfW) * (r - 2),
      Math.sin(a + halfW) * (r - 2),
    );
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // ---- Body ------------------------------------------------------
  const bodyGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r);
  bodyGrad.addColorStop(0, light(78));
  bodyGrad.addColorStop(0.55, light(56));
  bodyGrad.addColorStop(1, light(30, 70));
  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  ctx.fill();

  // Inner membrane ring
  ctx.strokeStyle = withAlpha(light(85), 0.5);
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.74, 0, TAU);
  ctx.stroke();

  // ---- Chitin plates --------------------------------------------
  if (t.plates > 0) {
    ctx.save();
    ctx.rotate(-v.spin * 0.7);
    const n = 3 + t.plates;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      ctx.save();
      ctx.rotate(a);
      ctx.fillStyle = withAlpha("#ffd45e", 0.34);
      ctx.strokeStyle = withAlpha("#ffe9a8", 0.75);
      ctx.lineWidth = 1.4;
      const pw = (TAU * r) / (n * 3.1);
      roundRectPath(ctx, r * 0.5, -pw / 2, r * 0.44, pw, 3);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }

  // ---- Regen orbs ------------------------------------------------
  if (t.innerOrbs > 0) {
    const n = 2 + t.innerOrbs;
    for (let i = 0; i < n; i++) {
      const a = time * 1.3 + (i / n) * TAU;
      const d = r * 0.45;
      const pr = r * (0.13 + 0.03 * Math.sin(time * 4 + i));
      ctx.fillStyle = withAlpha("#59ffb0", 0.85);
      ctx.beginPath();
      ctx.arc(Math.cos(a) * d, Math.sin(a) * d, pr, 0, TAU);
      ctx.fill();
    }
  }

  // ---- Nucleoid core --------------------------------------------
  ctx.save();
  ctx.rotate(time * 0.9);
  const core = ctx.createRadialGradient(0, 0, 0, 0, 0, r * 0.42);
  core.addColorStop(0, "rgba(255,255,255,0.95)");
  core.addColorStop(0.5, light(88, 90));
  core.addColorStop(1, withAlpha(light(60), 0));
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.42, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = withAlpha("#0b2a12", 0.5);
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.3, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  // ---- Taxis eye -------------------------------------------------
  if (t.eye > 0) {
    const a = v.angle;
    ctx.save();
    ctx.translate(Math.cos(a) * r * 0.34, Math.sin(a) * r * 0.34);
    ctx.fillStyle = "#0d1b0f";
    ctx.beginPath();
    ctx.ellipse(0, 0, r * 0.24, r * 0.17, a, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#ffe066";
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.11 * t.eye * 0.5 + r * 0.05, 0, TAU);
    ctx.fill();
    ctx.restore();
  }

  ctx.restore();

  // ---- Shield spores --------------------------------------------
  if (v.shield > 0) {
    for (let i = 0; i < v.shield; i++) {
      const a = time * 1.6 + (i / Math.max(1, v.shield)) * TAU;
      const d = r + 14;
      const x = v.pos.x + Math.cos(a) * d;
      const y = v.pos.y + Math.sin(a) * d;
      ctx.fillStyle = "#6ea8ff";
      ctx.beginPath();
      ctx.arc(x, y, 6 + v.shieldFlash * 4, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = withAlpha("#cfe4ff", 0.8);
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  // ---- Overlays --------------------------------------------------
  if (v.invuln > 0) {
    const blink = 0.35 + Math.abs(Math.sin(time * 18)) * 0.45;
    ctx.strokeStyle = withAlpha("#ffffff", blink);
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(v.pos.x, v.pos.y, r + 7, 0, TAU);
    ctx.stroke();
  }
  if (v.hurt > 0) {
    ctx.fillStyle = withAlpha("#ff2d55", v.hurt * 0.4);
    ctx.beginPath();
    ctx.arc(v.pos.x, v.pos.y, r, 0, TAU);
    ctx.fill();
  }
  if (v.evolveFlash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, v.pos.x, v.pos.y, r * 4.5, "#ffffff", v.evolveFlash * 0.55);
    ctx.restore();
  }

  // Enzyme droplets on the rim
  if (t.digest > 0) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const n = Math.min(7, 2 + Math.floor(t.digest / 40));
    for (let i = 0; i < n; i++) {
      const a = time * 0.8 + (i / n) * TAU;
      const d = r + 6;
      glow(
        ctx,
        v.pos.x + Math.cos(a) * d,
        v.pos.y + Math.sin(a) * d,
        7,
        "#b4ff3d",
        0.85,
      );
    }
    ctx.restore();
  }
}

/** Standalone preview used by menus (own canvas, own scale). */
export function drawVirusPreview(
  ctx: CanvasRenderingContext2D,
  traits: Traits,
  time: number,
  w: number,
  h: number,
  scaleUp = 1,
) {
  const fake: Virus = {
    pos: { x: w / 2, y: h / 2 },
    vel: { x: 0, y: 0 },
    angle: -Math.PI / 2,
    spin: time * 0.5,
    r: traits.radius,
    hp: traits.maxHp,
    invuln: 0,
    hitFlash: 0,
    hurt: 0,
    dashTime: 0,
    dashCd: 0,
    dashDir: { x: 0, y: 0 },
    evolveFlash: 0,
    morph: 0,
    trail: [],
    pulse: time * 2,
    shield: traits.shieldMax,
    shieldFlash: 0,
  };
  ctx.clearRect(0, 0, w, h);
  drawVirus(ctx, fake, traits, time, scaleUp);
}

/* ------------------------------------------------------------------ */
/* Enemies                                                             */
/* ------------------------------------------------------------------ */

export function drawEnemy(
  ctx: CanvasRenderingContext2D,
  e: Enemy,
  time: number,
) {
  const flash = e.hitFlash;
  ctx.save();
  ctx.translate(e.pos.x, e.pos.y);

  switch (e.kind) {
    case "mite": {
      const wob = Math.sin(e.t * 6 + e.seed) * 0.12;
      ctx.save();
      ctx.rotate(e.angle);
      ctx.strokeStyle = "rgba(255,175,120,0.55)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        const a = -0.6 + i * 0.4;
        const l = e.r * (1.5 + Math.sin(time * 12 + i) * 0.3);
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r, Math.sin(a) * e.r);
        ctx.lineTo(Math.cos(a) * l, Math.sin(a) * l);
        ctx.stroke();
      }
      ctx.restore();
      const g = ctx.createRadialGradient(-e.r * 0.3, -e.r * 0.3, 1, 0, 0, e.r);
      g.addColorStop(0, "#ffd2a8");
      g.addColorStop(0.6, "#ff9f5e");
      g.addColorStop(1, "#c85a2e");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.ellipse(0, 0, e.r * (1 + wob), e.r * (1 - wob), e.angle, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(60,20,10,0.7)";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.32, 0, TAU);
      ctx.fill();
      break;
    }
    case "spore": {
      ctx.save();
      ctx.rotate(e.angle * 0.4);
      ctx.strokeStyle = "rgba(200,150,255,0.5)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.8, Math.sin(a) * e.r * 0.8);
        ctx.lineTo(Math.cos(a) * e.r * 1.35, Math.sin(a) * e.r * 1.35);
        ctx.stroke();
      }
      ctx.restore();
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, e.r);
      g.addColorStop(0, "#f0dcff");
      g.addColorStop(0.55, "#b07bff");
      g.addColorStop(1, "#5c2b9c");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      break;
    }
    case "chaser": {
      // Macrophage: lobed blob reaching toward its target
      const lobes = 9;
      ctx.beginPath();
      for (let i = 0; i <= lobes; i++) {
        const a = (i / lobes) * TAU;
        const reach = 1 + 0.22 * Math.cos(a - e.angle);
        const rr = e.r * reach * (1 + 0.08 * Math.sin(e.t * 5 + i * 2));
        const x = Math.cos(a) * rr;
        const y = Math.sin(a) * rr;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(0, 0, e.r * 0.2, 0, 0, e.r * 1.2);
      g.addColorStop(0, "rgba(255,190,235,0.95)");
      g.addColorStop(0.5, "rgba(255,110,200,0.75)");
      g.addColorStop(1, "rgba(150,30,110,0.45)");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,200,240,0.8)";
      ctx.lineWidth = 2;
      ctx.stroke();
      // Nucleus + granules
      ctx.fillStyle = "rgba(90,15,70,0.75)";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.42, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      for (let i = 0; i < 5; i++) {
        const a = e.t * 1.2 + i * 1.3;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * e.r * 0.6, Math.sin(a) * e.r * 0.6, 3, 0, TAU);
        ctx.fill();
      }
      break;
    }
    case "spiker": {
      ctx.save();
      ctx.rotate(e.angle);
      ctx.strokeStyle = "#ff7a2f";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.7, Math.sin(a) * e.r * 0.7);
        ctx.lineTo(Math.cos(a) * e.r * 1.85, Math.sin(a) * e.r * 1.85);
        ctx.stroke();
      }
      ctx.restore();
      const pulse = 0.5 + Math.abs(Math.sin(e.t * 3)) * 0.5;
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, e.r);
      g.addColorStop(0, `rgba(255,220,120,${0.6 + pulse * 0.4})`);
      g.addColorStop(0.6, "#8c2f10");
      g.addColorStop(1, "#3a1206");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = `rgba(255,90,40,${0.4 + pulse * 0.6})`;
      ctx.lineWidth = 3;
      ctx.stroke();
      break;
    }
    case "hunter": {
      // Y-shaped antibody
      ctx.save();
      ctx.rotate(e.angle);
      ctx.lineCap = "round";
      ctx.strokeStyle = flash > 0 ? "#ffffff" : "#dff0ff";
      ctx.lineWidth = e.r * 0.42;
      ctx.beginPath();
      ctx.moveTo(-e.r * 0.9, 0);
      ctx.lineTo(e.r * 0.3, 0);
      ctx.stroke();
      ctx.lineWidth = e.r * 0.34;
      ctx.beginPath();
      ctx.moveTo(e.r * 0.2, 0);
      ctx.lineTo(e.r * 1.0, -e.r * 0.85);
      ctx.moveTo(e.r * 0.2, 0);
      ctx.lineTo(e.r * 1.0, e.r * 0.85);
      ctx.stroke();
      ctx.fillStyle = "#8fc6ff";
      ctx.beginPath();
      ctx.arc(-e.r * 0.9, 0, e.r * 0.34, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ff5f7e";
      ctx.beginPath();
      ctx.arc(e.r * 1.0, -e.r * 0.85, e.r * 0.24, 0, TAU);
      ctx.arc(e.r * 1.0, e.r * 0.85, e.r * 0.24, 0, TAU);
      ctx.fill();
      ctx.restore();
      // Telegraph the shot
      if (e.cool < 0.45) {
        ctx.strokeStyle = `rgba(255,210,60,${0.25 + Math.sin(time * 30) * 0.2})`;
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 10]);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(Math.cos(e.angle) * 300, Math.sin(e.angle) * 300);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      break;
    }
    case "sentinel": {
      const pulse = 0.5 + Math.sin(time * 2) * 0.5;
      ctx.save();
      ctx.rotate(e.angle);
      // Outer ring
      ctx.strokeStyle = "#ff9a3d";
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.stroke();
      // Spokes
      ctx.strokeStyle = "rgba(255,180,90,0.85)";
      ctx.lineWidth = 5;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * e.r * 0.4, Math.sin(a) * e.r * 0.4);
        ctx.lineTo(Math.cos(a) * e.r, Math.sin(a) * e.r);
        ctx.stroke();
      }
      // Core
      const g = ctx.createRadialGradient(0, 0, 2, 0, 0, e.r * 0.7);
      g.addColorStop(0, "#fff2cc");
      g.addColorStop(0.5, "#ff8a3d");
      g.addColorStop(1, "#7a1f0a");
      ctx.fillStyle = flash > 0 ? "#ffffff" : g;
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.55 * (1 + pulse * 0.05), 0, TAU);
      ctx.fill();
      ctx.restore();
      // Orbit pods
      for (let i = 0; i < 4; i++) {
        const a = -e.angle * 1.6 + (i / 4) * TAU;
        const d = e.r * 1.4;
        ctx.fillStyle = "#ffd45e";
        ctx.beginPath();
        ctx.arc(Math.cos(a) * d, Math.sin(a) * d, 9, 0, TAU);
        ctx.fill();
      }
      if (e.shielded) {
        ctx.strokeStyle = `rgba(255,212,94,${0.4 + pulse * 0.35})`;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * 1.75, 0, TAU);
        ctx.stroke();
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * TAU + time * 0.7;
          ctx.fillStyle = "rgba(255,212,94,0.75)";
          ctx.beginPath();
          ctx.arc(
            Math.cos(a) * e.r * 1.75,
            Math.sin(a) * e.r * 1.75,
            4,
            0,
            TAU,
          );
          ctx.fill();
        }
      }
      break;
    }
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Pickups, bullets, particles                                         */
/* ------------------------------------------------------------------ */

export function drawPickup(
  ctx: CanvasRenderingContext2D,
  p: Pickup,
  pal: Palette,
  time: number,
) {
  const bob = Math.sin(time * 3 + p.seed) * 3;
  ctx.save();
  ctx.translate(p.pos.x, p.pos.y + bob);
  if (p.kind === "dna") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 20, pal.dna, 0.7);
    ctx.restore();
    ctx.strokeStyle = pal.dna;
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    const spin = time * 2 + p.seed;
    for (let s = -1; s <= 1; s += 2) {
      ctx.beginPath();
      for (let i = 0; i <= 8; i++) {
        const f = i / 8;
        const y = (f - 0.5) * 18;
        const x = Math.sin(f * Math.PI * 2 + spin) * 5 * s;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 3; i++) {
      const f = 0.2 + i * 0.3;
      const y = (f - 0.5) * 18;
      const x = Math.sin(f * Math.PI * 2 + spin) * 5;
      ctx.beginPath();
      ctx.moveTo(-x, y);
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  } else if (p.kind === "plasmid") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 34, "#ffe066", 0.85);
    ctx.restore();
    ctx.rotate(time * 1.4 + p.seed);
    ctx.strokeStyle = "#ffe066";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, p.r, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 8]);
    ctx.beginPath();
    ctx.arc(0, 0, p.r * 0.55, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (p.kind === "heal") {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 26, "#7dff9c", 0.7);
    ctx.restore();
    ctx.fillStyle = "#7dff9c";
    roundRectPath(ctx, -10, -4, 20, 8, 3);
    ctx.fill();
    roundRectPath(ctx, -4, -10, 8, 20, 3);
    ctx.fill();
  } else {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    glow(ctx, 0, 0, 26, "#6ea8ff", 0.7);
    ctx.restore();
    ctx.rotate(time * 0.9);
    ctx.strokeStyle = "#6ea8ff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU;
      const x = Math.cos(a) * 11;
      const y = Math.sin(a) * 11;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();
}

export function drawBullet(
  ctx: CanvasRenderingContext2D,
  b: { pos: { x: number; y: number }; vel: { x: number; y: number }; r: number; color: string; t: number; life: number; maxLife: number; kind: string },
) {
  const a = Math.atan2(b.vel.y, b.vel.x);
  ctx.save();
  ctx.translate(b.pos.x, b.pos.y);
  ctx.rotate(a);
  ctx.globalCompositeOperation = "lighter";
  glow(ctx, 0, 0, b.r * 4, b.color, 0.8);
  ctx.globalCompositeOperation = "source-over";
  if (b.kind === "shard") {
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.moveTo(b.r * 1.6, 0);
    ctx.lineTo(-b.r, b.r * 0.8);
    ctx.lineTo(-b.r, -b.r * 0.8);
    ctx.closePath();
    ctx.fill();
  } else if (b.kind === "wave") {
    const pulse = 1 + Math.sin(b.t * 20) * 0.15;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(0, 0, b.r * pulse, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.beginPath();
    ctx.arc(0, 0, b.r * 0.45, 0, TAU);
    ctx.fill();
  } else {
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.ellipse(0, 0, b.r * 2, b.r * 0.8, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.ellipse(0, 0, b.r * 0.9, b.r * 0.4, 0, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

export function drawParticle(
  ctx: CanvasRenderingContext2D,
  p: Particle,
) {
  const k = clamp(p.life / p.maxLife, 0, 1);
  ctx.save();
  if (p.kind === "ring") {
    ctx.globalAlpha = k * 0.8;
    ctx.strokeStyle = p.color;
    ctx.lineWidth = 2 + k * 5;
    ctx.beginPath();
    ctx.arc(p.pos.x, p.pos.y, p.r, 0, TAU);
    ctx.stroke();
  } else if (p.kind === "blob") {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = k * 0.75;
    glow(ctx, p.pos.x, p.pos.y, p.r * 2.4, p.color, 1);
  } else if (p.kind === "shard") {
    ctx.globalAlpha = k;
    ctx.translate(p.pos.x, p.pos.y);
    ctx.rotate(p.angle);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.moveTo(p.r, 0);
    ctx.lineTo(-p.r * 0.7, p.r * 0.6);
    ctx.lineTo(-p.r * 0.7, -p.r * 0.6);
    ctx.closePath();
    ctx.fill();
  } else if (p.kind === "dna") {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = k;
    glow(ctx, p.pos.x, p.pos.y, p.r * 3, p.color, 1);
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.pos.x, p.pos.y, p.r * 0.4, 0, TAU);
    ctx.fill();
  } else {
    ctx.globalAlpha = k;
    ctx.globalCompositeOperation = "lighter";
    ctx.strokeStyle = p.color;
    ctx.lineWidth = Math.max(1, p.r * 0.5);
    ctx.beginPath();
    ctx.moveTo(p.pos.x, p.pos.y);
    ctx.lineTo(p.pos.x - p.vel.x * 0.03, p.pos.y - p.vel.y * 0.03);
    ctx.stroke();
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Arena                                                               */
/* ------------------------------------------------------------------ */

export function drawTargetCell(ctx: CanvasRenderingContext2D, w: World, time: number) {
  const t = w.target;
  const p = w.stage.palette;
  const r = t.r;
  ctx.save();
  ctx.translate(t.pos.x, t.pos.y);

  // Outer halo
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const halo = t.unlocked ? p.dna : "#ff6b81";
  glow(ctx, 0, 0, r * (t.unlocked ? 3.4 : 2.6), halo, 0.55 + Math.sin(time * 2) * 0.12);
  ctx.restore();

  // Membrane (wobbling)
  const lobes = 14;
  ctx.beginPath();
  for (let i = 0; i <= lobes; i++) {
    const a = (i / lobes) * TAU;
    const rr = r * (1 + 0.055 * Math.sin(a * 3 + time * 1.6));
    const x = Math.cos(a) * rr;
    const y = Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  const g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
  if (t.unlocked) {
    g.addColorStop(0, "rgba(255,255,230,0.95)");
    g.addColorStop(0.5, "rgba(180,255,120,0.7)");
    g.addColorStop(1, "rgba(40,120,60,0.35)");
  } else {
    g.addColorStop(0, "rgba(255,225,225,0.9)");
    g.addColorStop(0.5, "rgba(255,120,150,0.6)");
    g.addColorStop(1, "rgba(120,30,60,0.3)");
  }
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = t.unlocked ? p.dna : "#ff8fa3";
  ctx.lineWidth = 3;
  ctx.stroke();

  // Nucleus
  const ng = ctx.createRadialGradient(0, 0, 2, 0, 0, r * 0.44);
  ng.addColorStop(0, "rgba(255,255,255,0.95)");
  ng.addColorStop(0.6, t.unlocked ? "rgba(150,255,120,0.8)" : "rgba(255,160,180,0.75)");
  ng.addColorStop(1, "rgba(30,20,60,0.2)");
  ctx.fillStyle = ng;
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.44 * (1 + t.infected * 0.5), 0, TAU);
  ctx.fill();

  // Chromatin specks
  ctx.fillStyle = t.unlocked ? "rgba(60,120,40,0.5)" : "rgba(90,30,60,0.5)";
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * TAU + time * 0.3;
    const d = r * (0.6 + 0.2 * Math.sin(time + i));
    ctx.beginPath();
    ctx.arc(Math.cos(a) * d, Math.sin(a) * d, 4.5, 0, TAU);
    ctx.fill();
  }

  if (!t.unlocked) {
    // Lock ring showing required DNA
    const frac = clamp(w.collected / w.stage.quota, 0, 1);
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(0, 0, r + 26, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = p.dna;
    ctx.beginPath();
    ctx.arc(0, 0, r + 26, -Math.PI / 2, -Math.PI / 2 + frac * TAU);
    ctx.stroke();
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + time * 0.5;
      ctx.fillStyle = "rgba(255,120,140,0.8)";
      ctx.save();
      ctx.rotate(a);
      roundRectPath(ctx, r + 18, -3, 12, 6, 2);
      ctx.fill();
      ctx.restore();
    }
  } else {
    // Pulsing invitation rings
    for (let i = 0; i < 3; i++) {
      const f = (time * 0.55 + i / 3) % 1;
      ctx.globalAlpha = (1 - f) * 0.5;
      ctx.strokeStyle = p.dna;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, r + f * 70, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

function drawWalls(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  const p = w.stage.palette;
  for (const r of w.wallRects()) {
    if (
      r.x + r.w < view.x ||
      r.y + r.h < view.y ||
      r.x > view.x + view.w ||
      r.y > view.y + view.h
    )
      continue;
    const g = ctx.createLinearGradient(r.x, r.y, r.x, r.y + r.h);
    g.addColorStop(0, withAlpha(p.wall, 0.95));
    g.addColorStop(1, withAlpha(p.wallGlow, 0.55));
    ctx.fillStyle = g;
    roundRectPath(ctx, r.x, r.y, r.w, r.h, Math.min(28, Math.min(r.w, r.h) * 0.4));
    ctx.fill();
    ctx.strokeStyle = withAlpha(p.wallEdge, 0.5 + Math.sin(time * 2) * 0.08);
    ctx.lineWidth = 2;
    ctx.stroke();
    // Inner texture dots
    ctx.fillStyle = withAlpha(p.wallEdge, 0.14);
    const step = 34;
    for (let x = r.x + 16; x < r.x + r.w - 8; x += step) {
      for (let y = r.y + 16; y < r.y + r.h - 8; y += step) {
        ctx.beginPath();
        ctx.arc(x + ((y / step) % 2) * 10, y, 2.6, 0, TAU);
        ctx.fill();
      }
    }
  }
}

function drawAcids(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  for (const a of w.stage.acids) {
    if (
      a.x + a.r < view.x ||
      a.y + a.r < view.y ||
      a.x - a.r > view.x + view.w ||
      a.y - a.r > view.y + view.h
    )
      continue;
    ctx.save();
    const g = ctx.createRadialGradient(a.x, a.y, a.r * 0.2, a.x, a.y, a.r);
    g.addColorStop(0, "rgba(214,255,61,0.42)");
    g.addColorStop(0.7, "rgba(150,220,40,0.26)");
    g.addColorStop(1, "rgba(90,180,20,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = "rgba(214,255,61,0.55)";
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 12]);
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.r * (0.96 + Math.sin(time * 1.5) * 0.02), 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    // Bubbles
    ctx.fillStyle = "rgba(230,255,150,0.5)";
    for (let i = 0; i < 9; i++) {
      const ang = (i / 9) * TAU + time * 0.25;
      const rr = a.r * (0.3 + 0.5 * ((i * 37) % 10) / 10);
      const s = 3 + ((i * 13) % 5);
      const rise = ((time * 30 + i * 20) % 60) / 60;
      ctx.beginPath();
      ctx.arc(
        a.x + Math.cos(ang) * rr,
        a.y + Math.sin(ang) * rr - rise * 24,
        s * (1 - rise * 0.6),
        0,
        TAU,
      );
      ctx.fill();
    }
    ctx.restore();
  }
}

function drawCurrents(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  for (const c of w.stage.currents) {
    const r = c.rect;
    if (
      r.x + r.w < view.x ||
      r.y + r.h < view.y ||
      r.x > view.x + view.w ||
      r.y > view.y + view.h
    )
      continue;
    ctx.save();
    ctx.beginPath();
    ctx.rect(r.x, r.y, r.w, r.h);
    ctx.clip();
    const g = ctx.createLinearGradient(r.x, r.y, r.x + r.w, r.y);
    g.addColorStop(0, "rgba(80,170,255,0.02)");
    g.addColorStop(0.5, "rgba(80,170,255,0.09)");
    g.addColorStop(1, "rgba(80,170,255,0.02)");
    ctx.fillStyle = g;
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.strokeStyle = "rgba(150,220,255,0.35)";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    const spacing = 110;
    const dirX = c.dir.x;
    const dirY = c.dir.y;
    const offset = (time * c.strength) % spacing;
    for (let i = -1; i < r.w / spacing + 2; i++) {
      for (let j = 0; j < r.h / spacing + 1; j++) {
        const bx = r.x + i * spacing + offset * dirX;
        const by = r.y + j * spacing + (dirY !== 0 ? offset : 0);
        const len = 42;
        const a = Math.atan2(dirY, dirX);
        ctx.beginPath();
        ctx.moveTo(bx - Math.cos(a) * len * 0.5, by - Math.sin(a) * len * 0.5);
        ctx.lineTo(bx + Math.cos(a) * len * 0.5, by + Math.sin(a) * len * 0.5);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(
          bx + Math.cos(a) * len * 0.5,
          by + Math.sin(a) * len * 0.5,
        );
        ctx.lineTo(
          bx + Math.cos(a - 0.6) * len * 0.22,
          by + Math.sin(a - 0.6) * len * 0.22,
        );
        ctx.moveTo(
          bx + Math.cos(a) * len * 0.5,
          by + Math.sin(a) * len * 0.5,
        );
        ctx.lineTo(
          bx + Math.cos(a + 0.6) * len * 0.22,
          by + Math.sin(a + 0.6) * len * 0.22,
        );
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

function drawDecor(ctx: CanvasRenderingContext2D, w: World, view: View, time: number) {
  const p = w.stage.palette;
  for (const d of w.decor) {
    if (
      d.pos.x + d.r < view.x ||
      d.pos.y + d.r < view.y ||
      d.pos.x - d.r > view.x + view.w ||
      d.pos.y - d.r > view.y + view.h
    )
      continue;
    const wobble = Math.sin(time * 0.6 + d.hue * 6) * 0.08;
    ctx.save();
    ctx.translate(d.pos.x, d.pos.y);
    ctx.rotate(time * d.spin * 0.1 + d.hue * TAU);
    ctx.globalAlpha = d.a;
    const g = ctx.createRadialGradient(0, 0, d.r * 0.1, 0, 0, d.r);
    g.addColorStop(0, withAlpha(p.blob, 0.6));
    g.addColorStop(1, withAlpha(p.blob, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    if (d.kind === 0) ctx.arc(0, 0, d.r * (1 + wobble), 0, TAU);
    else if (d.kind === 1) {
      ctx.ellipse(0, 0, d.r * 0.6, d.r, 0, 0, TAU);
    } else {
      ctx.moveTo(0, -d.r);
      ctx.quadraticCurveTo(d.r, 0, 0, d.r);
      ctx.quadraticCurveTo(-d.r, 0, 0, -d.r);
    }
    ctx.fill();
    if (d.kind === 1) {
      ctx.strokeStyle = withAlpha(p.blob, 0.35);
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(0, 0, d.r * 0.35, d.r * 0.85, 0, 0, TAU);
      ctx.stroke();
    }
    ctx.restore();
  }
}

/** Serum fluid: a cached repeating tile, drawn in world space so it scrolls. */
function drawFluid(ctx: CanvasRenderingContext2D, w: World, view: View) {
  const pat = getTile(w.stage.id, w.stage.palette, ctx);
  if (pat) {
    ctx.save();
    ctx.fillStyle = pat;
    ctx.fillRect(view.x - 64, view.y - 64, view.w + 128, view.h + 128);
    ctx.restore();
  }
}

function drawBounds(ctx: CanvasRenderingContext2D, w: World, time: number) {
  const p = w.stage.palette;
  const W = w.stage.world.w;
  const H = w.stage.world.h;
  ctx.save();
  ctx.strokeStyle = withAlpha(p.wallEdge, 0.35);
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.rect(-7, -7, W + 14, H + 14);
  ctx.stroke();
  ctx.strokeStyle = withAlpha(p.wallGlow, 0.18);
  ctx.lineWidth = 40;
  ctx.stroke();
  // Marker ticks
  ctx.strokeStyle = withAlpha(p.wallEdge, 0.2);
  ctx.lineWidth = 3;
  for (let x = 0; x < W; x += 180) {
    const a = 0.12 + Math.sin(time * 1.5 + x * 0.01) * 0.08;
    ctx.globalAlpha = a;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 40, 0);
    ctx.moveTo(x, H);
    ctx.lineTo(x + 40, H);
    ctx.stroke();
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* Master scene draw                                                   */
/* ------------------------------------------------------------------ */

export function drawScene(
  ctx: CanvasRenderingContext2D,
  w: World,
  view: View,
  time: number,
) {
  const p = w.stage.palette;

  drawFluid(ctx, w, view);
  drawDecor(ctx, w, view, time);
  drawCurrents(ctx, w, view, time);
  drawAcids(ctx, w, view, time);
  drawBounds(ctx, w, time);
  drawWalls(ctx, w, view, time);
  drawTargetCell(ctx, w, time);

  for (const e of w.enemies) {
    if (
      e.pos.x + e.r * 2 < view.x ||
      e.pos.y + e.r * 2 < view.y ||
      e.pos.x - e.r * 2 > view.x + view.w ||
      e.pos.y - e.r * 2 > view.y + view.h
    )
      continue;
    drawEnemy(ctx, e, time);
  }

  for (const pt of w.parts.list) drawParticle(ctx, pt);
  for (const pk of w.pickups) {
    if (
      pk.pos.x + 40 < view.x ||
      pk.pos.y + 40 < view.y ||
      pk.pos.x - 40 > view.x + view.w ||
      pk.pos.y - 40 > view.y + view.h
    )
      continue;
    drawPickup(ctx, pk, p, time);
  }
  for (const b of w.bullets) drawBullet(ctx, b);

  if (w.deathT <= 0) drawVirus(ctx, w.virus, w.traits, time, 1);

  // Floating score text
  for (const t of w.parts.texts) {
    const k = clamp(t.life / t.maxLife, 0, 1);
    ctx.save();
    ctx.globalAlpha = easeOut(k);
    ctx.font = `900 ${t.size}px ui-rounded, "Trebuchet MS", system-ui, sans-serif`;
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(0,0,0,0.65)";
    ctx.strokeText(t.text, t.pos.x, t.pos.y);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.pos.x, t.pos.y);
    ctx.restore();
  }
}

/** Screen-space overlays: vignette, damage flash, off-screen goal arrow. */
export function drawOverlays(
  ctx: CanvasRenderingContext2D,
  w: World,
  cw: number,
  ch: number,
  screenCenter: { x: number; y: number },
) {
  // Critical-health warning glow around the viewport
  const hpFrac = w.virus.hp / w.traits.maxHp;
  if (hpFrac < 0.34 && w.deathT <= 0) {
    const intensity = (1 - hpFrac / 0.34) * (0.2 + Math.abs(Math.sin(performance.now() / 240)) * 0.34);
    const g = ctx.createRadialGradient(
      cw / 2,
      ch / 2,
      Math.min(cw, ch) * 0.22,
      cw / 2,
      ch / 2,
      Math.max(cw, ch) * 0.72,
    );
    g.addColorStop(0, "rgba(255,20,60,0)");
    g.addColorStop(1, `rgba(255,20,60,${intensity.toFixed(3)})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, cw, ch);
  }

  if (w.flash > 0.01) {
    ctx.save();
    ctx.globalAlpha = Math.min(0.8, w.flash);
    ctx.fillStyle = w.flashColor;
    ctx.fillRect(0, 0, cw, ch);
    ctx.restore();
  }
  // Off-screen indicator pointing at the goal
  const v = w.virus;
  const dx = w.target.pos.x - v.pos.x;
  const dy = w.target.pos.y - v.pos.y;
  const margin = 46;
  const onScreen =
    w.target.pos.x > screenCenter.x - cw / 2 + margin &&
    w.target.pos.x < screenCenter.x + cw / 2 - margin &&
    w.target.pos.y > screenCenter.y - ch / 2 + margin &&
    w.target.pos.y < screenCenter.y + ch / 2 - margin;
  if (!onScreen && (w.target.unlocked || w.collected > w.stage.quota * 0.5)) {
    const a = Math.atan2(dy, dx);
    const rad = Math.min(cw, ch) * 0.36;
    const x = cw / 2 + Math.cos(a) * rad;
    const y = ch / 2 + Math.sin(a) * rad;
    const pulse = 0.6 + Math.abs(Math.sin(performance.now() / 300)) * 0.4;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(a);
    ctx.globalAlpha = w.target.unlocked ? pulse : pulse * 0.45;
    ctx.fillStyle = w.target.unlocked ? w.stage.palette.dna : "#ffffff";
    ctx.beginPath();
    ctx.moveTo(20, 0);
    ctx.lineTo(-12, 13);
    ctx.lineTo(-6, 0);
    ctx.lineTo(-12, -13);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = w.target.unlocked ? 0.9 : 0.5;
    ctx.fillStyle = w.target.unlocked ? w.stage.palette.dna : "#ffffff";
    ctx.font = '700 11px ui-monospace, monospace';
    ctx.textAlign = "center";
    const dist = Math.hypot(dx, dy);
    ctx.fillText(
      w.target.unlocked ? `HOST ${Math.round(dist)}m` : `HOST ${Math.round(dist)}m`,
      cw / 2 + Math.cos(a) * (rad + 26),
      ch / 2 + Math.sin(a) * (rad + 26) + 4,
    );
    ctx.restore();
  }
}
