import type { FloatText, Particle, ParticleKind, Vec } from "./types";
import { TAU, fromAngle, rand } from "./math";

const MAX_PARTICLES = 460;

export class Particles {
  list: Particle[] = [];
  texts: FloatText[] = [];

  clear() {
    this.list.length = 0;
    this.texts.length = 0;
  }

  private push(p: Particle) {
    if (this.list.length >= MAX_PARTICLES) {
      // Replace the oldest for a stable frame budget.
      this.list[Math.floor(Math.random() * this.list.length)] = p;
      return;
    }
    this.list.push(p);
  }

  spawn(
    pos: Vec,
    vel: Vec,
    r: number,
    life: number,
    color: string,
    kind: ParticleKind = "spark",
    drag = 2.2,
    spin = 0,
  ) {
    this.push({
      pos: { x: pos.x, y: pos.y },
      vel: { x: vel.x, y: vel.y },
      r,
      life,
      maxLife: life,
      color,
      kind,
      angle: rand(TAU),
      spin,
      drag,
    });
  }

  burst(pos: Vec, count: number, color: string, speed = 220, r = 4, life = 0.5) {
    for (let i = 0; i < count; i++) {
      const a = rand(TAU);
      const s = speed * (0.35 + Math.random() * 0.9);
      this.spawn(
        pos,
        fromAngle(a, s),
        r * (0.5 + Math.random()),
        life * (0.6 + Math.random() * 0.7),
        color,
        Math.random() < 0.3 ? "blob" : "spark",
        2.6,
      );
    }
  }

  ring(pos: Vec, color: string, r = 30, life = 0.45, growth = 260) {
    this.push({
      pos: { x: pos.x, y: pos.y },
      vel: { x: growth, y: 0 },
      r,
      life,
      maxLife: life,
      color,
      kind: "ring",
      angle: 0,
      spin: 0,
      drag: 0,
    });
  }

  shards(pos: Vec, count: number, color: string, speed = 320) {
    for (let i = 0; i < count; i++) {
      const a = rand(TAU);
      this.spawn(
        pos,
        fromAngle(a, speed * (0.4 + Math.random())),
        5 + Math.random() * 6,
        0.55 + Math.random() * 0.4,
        color,
        "shard",
        1.6,
        rand(-14, 14),
      );
    }
  }

  helix(pos: Vec, count: number, color: string) {
    for (let i = 0; i < count; i++) {
      const a = rand(TAU);
      this.spawn(
        pos,
        fromAngle(a, 40 + Math.random() * 110),
        3 + Math.random() * 4,
        0.9,
        color,
        "dna",
        1.1,
        rand(-6, 6),
      );
    }
  }

  text(pos: Vec, text: string, color = "#fff", size = 20, vel?: Vec) {
    if (this.texts.length > 40) this.texts.shift();
    this.texts.push({
      pos: { x: pos.x, y: pos.y },
      vel: vel ?? { x: rand(50, -50), y: -70 },
      text,
      life: 0.9,
      maxLife: 0.9,
      color,
      size,
    });
  }

  update(dt: number) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.list.splice(i, 1);
        continue;
      }
      if (p.kind === "ring") {
        p.r += p.vel.x * dt;
        continue;
      }
      const d = Math.exp(-p.drag * dt);
      p.vel.x *= d;
      p.vel.y *= d;
      p.pos.x += p.vel.x * dt;
      p.pos.y += p.vel.y * dt;
      p.angle += p.spin * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      if (t.life <= 0) {
        this.texts.splice(i, 1);
        continue;
      }
      t.pos.x += t.vel.x * dt;
      t.pos.y += t.vel.y * dt;
      t.vel.y += 60 * dt;
      t.vel.x *= Math.exp(-2 * dt);
    }
  }

  /** Drop particles that are far away (keeps mobile frame time flat). */
  cull(center: Vec, radius: number) {
    if (this.list.length < 120) return;
    const r2 = radius * radius;
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      const dx = p.pos.x - center.x;
      const dy = p.pos.y - center.y;
      if (dx * dx + dy * dy > r2) this.list.splice(i, 1);
    }
  }
}
