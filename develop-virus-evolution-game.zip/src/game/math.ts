import type { Circ, Rect, Vec } from "./types";

export const TAU = Math.PI * 2;

export const clamp = (v: number, lo: number, hi: number) =>
  v < lo ? lo : v > hi ? hi : v;

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const dist2 = (a: Vec, b: Vec) => {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return dx * dx + dy * dy;
};

export const dist = (a: Vec, b: Vec) => Math.sqrt(dist2(a, b));

export const len = (v: Vec) => Math.hypot(v.x, v.y);

export const norm = (v: Vec): Vec => {
  const l = Math.hypot(v.x, v.y);
  return l < 0.000001 ? { x: 0, y: 0 } : { x: v.x / l, y: v.y / l };
};

export const scale = (v: Vec, s: number): Vec => ({ x: v.x * s, y: v.y * s });

export const add = (a: Vec, b: Vec): Vec => ({ x: a.x + b.x, y: a.y + b.y });

export const sub = (a: Vec, b: Vec): Vec => ({ x: a.x - b.x, y: a.y - b.y });

export const dot = (a: Vec, b: Vec) => a.x * b.x + a.y * b.y;

export const fromAngle = (a: number, m = 1): Vec => ({
  x: Math.cos(a) * m,
  y: Math.sin(a) * m,
});

export const angleOf = (v: Vec) => Math.atan2(v.y, v.x);

export const rand = (a = 1, b = 0) => b + Math.random() * (a - b);

export const randInt = (a: number, b: number) =>
  Math.floor(a + Math.random() * (b - a + 1));

export const pick = <T,>(arr: readonly T[]): T =>
  arr[Math.floor(Math.random() * arr.length)];

export const chance = (p: number) => Math.random() < p;

export const easeOut = (t: number) => 1 - (1 - t) * (1 - t);
export const easeIn = (t: number) => t * t;
export const easeInOut = (t: number) =>
  t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

/** Frame-rate independent smoothing toward a target. */
export const smooth = (current: number, target: number, rate: number, dt: number) =>
  current + (target - current) * (1 - Math.exp(-rate * dt));

export const smoothVec = (
  current: Vec,
  target: Vec,
  rate: number,
  dt: number,
): Vec => ({
  x: smooth(current.x, target.x, rate, dt),
  y: smooth(current.y, target.y, rate, dt),
});

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function rectCenter(r: Rect): Vec {
  return { x: r.x + r.w / 2, y: r.y + r.h / 2 };
}

export function circleRect(c: Vec, r: number, rc: Rect): boolean {
  const cx = clamp(c.x, rc.x, rc.x + rc.w);
  const cy = clamp(c.y, rc.y, rc.y + rc.h);
  const dx = c.x - cx;
  const dy = c.y - cy;
  return dx * dx + dy * dy <= r * r;
}

export function pointInRect(p: Vec, rc: Rect): boolean {
  return (
    p.x >= rc.x && p.x <= rc.x + rc.w && p.y >= rc.y && p.y <= rc.y + rc.h
  );
}

export function pointInCircle(p: Vec, c: Circ): boolean {
  return dist2(p, c) <= c.r * c.r;
}

export function circlesOverlap(a: Circ, b: Circ): boolean {
  const rr = a.r + b.r;
  return dist2({ x: a.x, y: a.y }, { x: b.x, y: b.y }) <= rr * rr;
}

/** Push a circle out of an axis-aligned rect. Returns null if no overlap. */
export function resolveCircleRect(c: Vec, r: number, rc: Rect): Vec | null {
  const cx = clamp(c.x, rc.x, rc.x + rc.w);
  const cy = clamp(c.y, rc.y, rc.y + rc.h);
  let dx = c.x - cx;
  let dy = c.y - cy;
  const d2 = dx * dx + dy * dy;
  if (d2 > r * r) return null;
  if (d2 > 0.0001) {
    const d = Math.sqrt(d2);
    return { x: (dx / d) * (r - d), y: (dy / d) * (r - d) };
  }
  const left = c.x - rc.x;
  const right = rc.x + rc.w - c.x;
  const top = c.y - rc.y;
  const bottom = rc.y + rc.h - c.y;
  const m = Math.min(left, right, top, bottom);
  if (m === left) return { x: -(left + r), y: 0 };
  if (m === right) return { x: right + r, y: 0 };
  if (m === top) return { x: 0, y: -(top + r) };
  return { x: 0, y: bottom + r };
}

export function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

/** Format seconds as m:ss */
export function formatTime(s: number): string {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}
