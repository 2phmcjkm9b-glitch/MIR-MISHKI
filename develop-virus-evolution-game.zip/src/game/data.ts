import type { MutationDef, Palette, Rect, StageDef, Traits } from "./types";

export const BASE_TRAITS: Traits = {
  maxHp: 100,
  speed: 252,
  accel: 1650,
  drag: 5.4,
  radius: 22,
  spikes: 9,
  spikeLen: 9,
  bodyHue: 112,
  tail: 0,
  cilia: 0,
  tendrils: 0,
  plates: 0,
  innerOrbs: 0,
  aura: 64,
  regen: 0,
  thorns: 0,
  digest: 0,
  dashPower: 440,
  dashTime: 0.2,
  dashCd: 1.45,
  dashInvuln: 0.14,
  shock: 0,
  shieldMax: 0,
  dnaValue: 1,
  glow: 0.55,
  eye: 0,
};

/** Recompute the full trait set (stats + look) from the mutation levels. */
export function buildTraits(levels: Record<string, number>): Traits {
  const t: Traits = { ...BASE_TRAITS };
  for (const [id, lv] of Object.entries(levels)) {
    const def = MUTATION_BY_ID[id];
    if (def && lv > 0) def.apply(t, lv);
  }
  return t;
}

export const MENU_PALETTE: Palette = {
  bgA: "#02141c",
  bgB: "#06303a",
  blob: "#12d6c0",
  wall: "#0e6b74",
  wallEdge: "#7ffff0",
  wallGlow: "#1de3c8",
  accent: "#6dffd9",
  danger: "#ff5f7e",
  dna: "#c8ff4d",
  fog: "#052b34",
};

export const KIND_LABEL: Record<MutationDef["kind"], string> = {
  move: "LOCOMOTION",
  defense: "MEMBRANE",
  collect: "HARVEST",
  attack: "OFFENSE",
};

export const MUTATIONS: MutationDef[] = [
  {
    id: "flagellum",
    name: "Flagellum",
    kind: "move",
    glyph: "tail",
    max: 3,
    tint: "#7dff9c",
    tagline: "Grow a whipping tail for violent bursts of speed.",
    levels: [
      "Unlock DASH. Stronger thrust, shorter recovery.",
      "Longer tail. Dash power up, cooldown down.",
      "Twin-tail lash: brutal speed and near-instant recovery.",
    ],
    apply: (t, lv) => {
      t.tail = lv;
      t.dashPower = 440 + lv * 120;
      t.dashCd = 1.45 - lv * 0.19;
      t.dashTime = 0.2 + lv * 0.02;
      t.speed += lv * 16;
    },
  },
  {
    id: "cilia",
    name: "Cilia Surge",
    kind: "move",
    glyph: "cilia",
    max: 3,
    tint: "#9dff5e",
    tagline: "Carpet your capsule in beating cilia.",
    levels: [
      "+18% top speed, much tighter steering.",
      "+36% top speed, razor-sharp handling.",
      "+56% top speed. You barely drift anymore.",
    ],
    apply: (t, lv) => {
      t.cilia = lv;
      t.speed = 252 * (1 + lv * 0.18);
      t.accel = 1650 + lv * 900;
      t.drag = 5.4 + lv * 1.6;
    },
  },
  {
    id: "phase",
    name: "Phase Membrane",
    kind: "move",
    glyph: "phase",
    max: 3,
    tint: "#5ef0ff",
    tagline: "Desync your capsid to slip through matter.",
    levels: [
      "Dashing makes you untouchable for a moment.",
      "Longer phase window and a cyan double membrane.",
      "Dash through anything — bullets, spikes, hunters.",
    ],
    apply: (t, lv) => {
      t.dashInvuln = 0.16 + lv * 0.16;
      t.bodyHue = 112 + lv * 14;
      t.glow += lv * 0.18;
      t.dashTime += 0.03 * lv;
    },
  },
  {
    id: "plating",
    name: "Chitin Plating",
    kind: "defense",
    glyph: "plate",
    max: 3,
    tint: "#ffd45e",
    tagline: "Grow hardened plates over your capsid.",
    levels: [
      "+40 max health, +1 body size.",
      "+95 max health, +2 body size.",
      "+165 max health. You are a rolling fortress.",
    ],
    apply: (t, lv) => {
      t.plates = lv;
      t.maxHp = 100 + [0, 40, 95, 165][lv];
      t.radius = 22 + lv * 2;
      t.glow += lv * 0.05;
    },
  },
  {
    id: "regen",
    name: "Regen Cytoplasm",
    kind: "defense",
    glyph: "orb",
    max: 3,
    tint: "#59ffb0",
    tagline: "Spontaneously rebuild damaged protein shells.",
    levels: [
      "Repair 1.4 health per second.",
      "Repair 3 health per second.",
      "Repair 5.5 health per second — damage fades fast.",
    ],
    apply: (t, lv) => {
      t.innerOrbs = lv;
      t.regen = lv === 1 ? 1.4 : lv === 2 ? 3 : 5.5;
    },
  },
  {
    id: "barbs",
    name: "Spike Barbs",
    kind: "attack",
    glyph: "spike",
    max: 3,
    tint: "#ff6b6b",
    tagline: "Harden your spikes into toxin-loaded harpoons.",
    levels: [
      "Longer spikes. Attackers take 14 damage.",
      "Extra spikes. Attackers take 26 damage.",
      "A crown of red harpoons. Attackers take 45 damage.",
    ],
    apply: (t, lv) => {
      t.spikeLen = 9 + lv * 8;
      t.spikes = 9 + lv * 2;
      t.thorns = lv === 1 ? 14 : lv === 2 ? 26 : 45;
    },
  },
  {
    id: "magnet",
    name: "Magnetic Genome",
    kind: "collect",
    glyph: "aura",
    max: 3,
    tint: "#c98bff",
    tagline: "Bend nearby DNA strands toward your core.",
    levels: [
      "DNA is pulled from a wide radius.",
      "Half the arena's strands drift to you.",
      "A huge purple field vacuums everything nearby.",
    ],
    apply: (t, lv) => {
      t.aura = 64 + lv * 86;
      t.glow += 0.1 * lv;
    },
  },
  {
    id: "net",
    name: "Filament Net",
    kind: "collect",
    glyph: "net",
    max: 3,
    tint: "#8affe0",
    tagline: "Trail sticky filaments that soak up genes.",
    levels: [
      "Your wake collects DNA on its own.",
      "Longer filaments, wider catch.",
      "A huge drifting web of harvesting tendrils.",
    ],
    apply: (t, lv) => {
      t.tendrils = lv;
      t.aura += lv * 26;
    },
  },
  {
    id: "enzymes",
    name: "Lytic Enzymes",
    kind: "attack",
    glyph: "drop",
    max: 3,
    tint: "#b4ff3d",
    tagline: "Secrete enzymes that dissolve other organisms.",
    levels: [
      "Touch small organisms to digest them for DNA.",
      "Stronger enzymes — digest mid-size organisms.",
      "Dissolve almost anything you brush against.",
    ],
    apply: (t, lv) => {
      t.digest = lv === 1 ? 34 : lv === 2 ? 62 : 108;
    },
  },
  {
    id: "fission",
    name: "Binary Fission",
    kind: "defense",
    glyph: "shield",
    max: 3,
    tint: "#6ea8ff",
    tagline: "Bud off decoy spores that absorb a hit.",
    levels: [
      "1 orbiting spore shield.",
      "2 orbiting spore shields.",
      "3 orbiting spore shields.",
    ],
    apply: (t, lv) => {
      t.shieldMax = lv;
    },
  },
  {
    id: "taxis",
    name: "Taxis Sense",
    kind: "collect",
    glyph: "eye",
    max: 3,
    tint: "#ffe066",
    tagline: "Sense chemical gradients — every strand counts more.",
    levels: [
      "DNA is worth 35% more.",
      "DNA is worth 80% more.",
      "DNA is worth 140% more. A single eye opens.",
    ],
    apply: (t, lv) => {
      t.dnaValue = lv === 1 ? 1.35 : lv === 2 ? 1.8 : 2.4;
      t.eye = lv;
      t.aura += lv * 14;
    },
  },
  {
    id: "volt",
    name: "Electrostatic Burst",
    kind: "attack",
    glyph: "bolt",
    max: 3,
    tint: "#7fe7ff",
    tagline: "Discharge your membrane when you dash.",
    levels: [
      "Dashing shocks nearby organisms for 26 damage.",
      "Bigger field, 48 damage.",
      "A devastating 260-range storm for 80 damage.",
    ],
    apply: (t, lv) => {
      t.shock = lv === 1 ? 140 : lv === 2 ? 200 : 265;
      t.digest += lv * 6;
    },
  },
];

export const MUTATION_BY_ID: Record<string, MutationDef> = Object.fromEntries(
  MUTATIONS.map((m) => [m.id, m]),
);

/* ------------------------------------------------------------------ */
/* Stage layouts                                                       */
/* ------------------------------------------------------------------ */

const P1 = {
  bgA: "#04222c",
  bgB: "#0a4a52",
  blob: "#12d6c0",
  wall: "#0e6b74",
  wallEdge: "#7ffff0",
  wallGlow: "#1de3c8",
  accent: "#6dffd9",
  danger: "#ff5f7e",
  dna: "#c8ff4d",
  fog: "#052b34",
};

const P2 = {
  bgA: "#24082a",
  bgB: "#5c1440",
  blob: "#ff4fa3",
  wall: "#7a1f5c",
  wallEdge: "#ffb3e6",
  wallGlow: "#ff5fb0",
  accent: "#ff9ad5",
  danger: "#ffd23d",
  dna: "#ffe14d",
  fog: "#2c0a2e",
};

const P3 = {
  bgA: "#060f34",
  bgB: "#123a72",
  blob: "#4f8cff",
  wall: "#173a7a",
  wallEdge: "#9fd0ff",
  wallGlow: "#4fa8ff",
  accent: "#7fc4ff",
  danger: "#ff4f4f",
  dna: "#9dff5e",
  fog: "#08133a",
};

const P4 = {
  bgA: "#150529",
  bgB: "#3d0a4a",
  blob: "#ff7a2f",
  wall: "#4a1550",
  wallEdge: "#ffc78f",
  wallGlow: "#ff8a3d",
  accent: "#ffb45e",
  danger: "#ff3b6b",
  dna: "#ffd84d",
  fog: "#1a0630",
};

/** Scatter of capsule walls used by the open stages. */
function scatterWalls(
  seed: number,
  count: number,
  w: number,
  h: number,
  avoid: Rect,
  minSize = 90,
  maxSize = 210,
): Rect[] {
  // Deterministic pseudo-random so layouts are stable per stage.
  let s = seed;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
  const out: Rect[] = [];
  let guard = 0;
  while (out.length < count && guard < count * 40) {
    guard++;
    const rw = minSize + rnd() * (maxSize - minSize);
    const rh = minSize + rnd() * (maxSize - minSize);
    const x = 180 + rnd() * (w - 360 - rw);
    const y = 180 + rnd() * (h - 360 - rh);
    const r = { x, y, w: rw, h: rh };
    const pad = 130;
    if (
      x < avoid.x + avoid.w + pad &&
      x + rw > avoid.x - pad &&
      y < avoid.y + avoid.h + pad &&
      y + rh > avoid.y - pad
    ) {
      continue;
    }
    if (out.some((o) => Math.hypot(o.x - x, o.y - y) < 260)) continue;
    out.push(r);
  }
  return out;
}

function pillarGrid(
  w: number,
  h: number,
  step: number,
  size: number,
  skip: (x: number, y: number) => boolean,
): Rect[] {
  const out: Rect[] = [];
  for (let x = step; x < w - step * 0.5; x += step) {
    for (let y = step; y < h - step * 0.5; y += step) {
      if (skip(x, y)) continue;
      if (((x / step) * 7 + (y / step) * 13) % 5 === 0) continue;
      out.push({ x: x - size / 2, y: y - size / 2, w: size, h: size });
    }
  }
  return out;
}

export const STAGES: StageDef[] = [
  {
    id: 1,
    name: "PLASMA SHALLOWS",
    subtitle: "Sector 01 · warm nutrient broth",
    brief:
      "Drift in, feed on loose genetic strands and find the lone host cell. Its membrane only opens once you have taken enough DNA.",
    world: { w: 2500, h: 1750 },
    quota: 14,
    firstEvolve: 8,
    walls: scatterWalls(9271, 13, 2500, 1750, { x: 120, y: 800, w: 320, h: 320 }),
    acids: [],
    currents: [],
    spawns: { mite: 16, chaser: 3 },
    respawn: { mite: 1, chaser: 1 },
    respawnEvery: 7,
    pickupCount: 54,
    boss: false,
    palette: P1,
    hints: [
      "Move: WASD / arrows, hold mouse, or drag anywhere",
      "Collect the glowing DNA strands",
      "DASH (Space / Shift / tap button) shreds small organisms",
      "Fill the EVOLVE bar to mutate",
      "Quota met — find the host cell and infect it",
    ],
  },
  {
    id: 2,
    name: "ACID DUCTS",
    subtitle: "Sector 02 · corrosive capillary maze",
    brief:
      "Tight ducts, dead ends and pools of lytic acid. Macrophages hunt by scent. Spike mines are immobile but lethal.",
    world: { w: 2900, h: 1950 },
    quota: 26,
    firstEvolve: 12,
    walls: [
      { x: 700, y: 170, w: 64, h: 620 },
      { x: 1380, y: 420, w: 64, h: 700 },
      { x: 2060, y: 170, w: 64, h: 620 },
      { x: 190, y: 900, w: 880, h: 64 },
      { x: 1520, y: 1210, w: 1120, h: 64 },
      { x: 300, y: 1520, w: 620, h: 64 },
      { x: 980, y: 190, w: 150, h: 130 },
      { x: 1720, y: 330, w: 150, h: 150 },
      { x: 620, y: 1250, w: 170, h: 130 },
      { x: 2480, y: 880, w: 130, h: 170 },
      { x: 1060, y: 1580, w: 130, h: 130 },
    ],
    acids: [
      { x: 1120, y: 620, r: 190 },
      { x: 1780, y: 1020, r: 210 },
      { x: 2560, y: 640, r: 175 },
      { x: 720, y: 1760, r: 150 },
      { x: 2280, y: 1560, r: 165 },
      { x: 380, y: 480, r: 150 },
    ],
    currents: [],
    spawns: { mite: 14, chaser: 9, spiker: 9 },
    respawn: { mite: 1, chaser: 2 },
    respawnEvery: 6,
    pickupCount: 62,
    boss: false,
    palette: P2,
    hints: [
      "Acid pools burn — dash across them",
      "Spike mines detonate on contact. Keep your distance",
      "Macrophages chase in straight lines — juke them",
      "Quota met — reach the host cell",
    ],
  },
  {
    id: 3,
    name: "ANTIBODY STORM",
    subtitle: "Sector 03 · open serum with currents",
    brief:
      "A wide serum channel swept by currents. Antibody hunters fire tracking bolts from range. Spores split when destroyed.",
    world: { w: 3100, h: 2100 },
    quota: 36,
    firstEvolve: 14,
    walls: scatterWalls(4413, 17, 3100, 2100, { x: 130, y: 950, w: 300, h: 300 }, 110, 240),
    acids: [
      { x: 1500, y: 600, r: 200 },
      { x: 2300, y: 1500, r: 230 },
    ],
    currents: [
      {
        rect: { x: 0, y: 420, w: 3100, h: 240 },
        dir: { x: 1, y: 0 },
        strength: 190,
      },
      {
        rect: { x: 0, y: 1060, w: 3100, h: 260 },
        dir: { x: -1, y: 0 },
        strength: 210,
      },
      {
        rect: { x: 0, y: 1660, w: 3100, h: 240 },
        dir: { x: 1, y: 0 },
        strength: 165,
      },
    ],
    spawns: { mite: 16, hunter: 8, spore: 8, chaser: 5 },
    respawn: { mite: 1, hunter: 2, spore: 1 },
    respawnEvery: 6,
    pickupCount: 70,
    boss: false,
    palette: P3,
    hints: [
      "Blue currents push you — ride them",
      "Hunters shoot bolts. Keep moving, weave",
      "Spores split in two when popped",
      "Quota met — reach the host cell",
    ],
  },
  {
    id: 4,
    name: "THE NUCLEUS",
    subtitle: "Sector 04 · final chamber",
    brief:
      "The host's heart. A Sentinel guards the nucleus behind a lattice of organelles. Break its shield with DNA, then dive in.",
    world: { w: 2700, h: 2700 },
    quota: 42,
    firstEvolve: 16,
    walls: pillarGrid(2700, 2700, 270, 96, (x, y) => {
      const cx = 1350;
      const cy = 1350;
      if (Math.hypot(x - cx, y - cy) < 520) return true;
      if (Math.hypot(x - 260, y - 260) < 330) return true;
      return false;
    }),
    acids: [
      { x: 700, y: 2100, r: 200 },
      { x: 2100, y: 700, r: 200 },
      { x: 2200, y: 2200, r: 170 },
      { x: 600, y: 600, r: 170 },
    ],
    currents: [
      {
        rect: { x: 0, y: 1300, w: 760, h: 200 },
        dir: { x: 0, y: -1 },
        strength: 170,
      },
      {
        rect: { x: 1940, y: 1200, w: 760, h: 200 },
        dir: { x: 0, y: 1 },
        strength: 170,
      },
    ],
    spawns: { mite: 14, hunter: 5, chaser: 5, spiker: 8, spore: 6, sentinel: 1 },
    respawn: { mite: 1, hunter: 1, chaser: 1 },
    respawnEvery: 7,
    pickupCount: 80,
    boss: true,
    palette: P4,
    hints: [
      "The Sentinel's shield breaks when your quota is met",
      "Dash through its shards, then dive into the nucleus",
      "This is the last chamber. Survive it",
      "Quota met — the nucleus is open",
    ],
  },
];

export function nextEvolveCost(evolutionCount: number, stage: StageDef): number {
  return Math.round(stage.firstEvolve + evolutionCount * 7);
}
