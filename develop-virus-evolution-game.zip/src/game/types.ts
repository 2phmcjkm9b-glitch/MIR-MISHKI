/** Shared type definitions for VIRUS. */

export interface Vec {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Circ {
  x: number;
  y: number;
  r: number;
}

export type Phase =
  | "menu"
  | "briefing"
  | "playing"
  | "mutate"
  | "paused"
  | "dead"
  | "clear"
  | "won";

export type EnemyKind =
  | "mite"
  | "chaser"
  | "spiker"
  | "hunter"
  | "spore"
  | "sentinel";

export interface Enemy {
  kind: EnemyKind;
  pos: Vec;
  vel: Vec;
  r: number;
  hp: number;
  maxHp: number;
  dmg: number;
  angle: number;
  spin: number;
  t: number;
  cool: number;
  wander: Vec;
  hitFlash: number;
  alive: boolean;
  genome: number;
  score: number;
  seed: number;
  home: Vec;
  aggro: number;
  shielded: boolean;
  phase: number;
}

export type PickupKind = "dna" | "plasmid" | "heal" | "shield";

export interface Pickup {
  kind: PickupKind;
  pos: Vec;
  vel: Vec;
  r: number;
  t: number;
  alive: boolean;
  value: number;
  seed: number;
}

export interface Bullet {
  pos: Vec;
  vel: Vec;
  r: number;
  life: number;
  maxLife: number;
  dmg: number;
  color: string;
  t: number;
  hostile: boolean;
  kind: "bolt" | "shard" | "wave";
}

export type ParticleKind = "spark" | "blob" | "ring" | "shard" | "dna";

export interface Particle {
  pos: Vec;
  vel: Vec;
  r: number;
  life: number;
  maxLife: number;
  color: string;
  kind: ParticleKind;
  angle: number;
  spin: number;
  drag: number;
}

export interface FloatText {
  pos: Vec;
  vel: Vec;
  text: string;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

/** Everything the player has evolved. Both stats and looks derive from this. */
export interface Traits {
  maxHp: number;
  speed: number;
  accel: number;
  drag: number;
  radius: number;
  spikes: number;
  spikeLen: number;
  bodyHue: number;
  tail: number;
  cilia: number;
  tendrils: number;
  plates: number;
  innerOrbs: number;
  aura: number;
  regen: number;
  thorns: number;
  digest: number;
  dashPower: number;
  dashTime: number;
  dashCd: number;
  dashInvuln: number;
  shock: number;
  shieldMax: number;
  dnaValue: number;
  glow: number;
  eye: number;
}

export interface Virus {
  pos: Vec;
  vel: Vec;
  angle: number;
  spin: number;
  r: number;
  hp: number;
  invuln: number;
  hitFlash: number;
  hurt: number;
  dashTime: number;
  dashCd: number;
  dashDir: Vec;
  evolveFlash: number;
  morph: number;
  trail: { x: number; y: number; a: number }[];
  pulse: number;
  shield: number;
  shieldFlash: number;
}

export interface Palette {
  bgA: string;
  bgB: string;
  blob: string;
  wall: string;
  wallEdge: string;
  wallGlow: string;
  accent: string;
  danger: string;
  dna: string;
  fog: string;
}

export interface StageDef {
  id: number;
  name: string;
  subtitle: string;
  brief: string;
  world: { w: number; h: number };
  quota: number;
  firstEvolve: number;
  walls: Rect[];
  acids: Circ[];
  currents: { rect: Rect; dir: Vec; strength: number }[];
  spawns: Partial<Record<EnemyKind, number>>;
  respawn: Partial<Record<EnemyKind, number>>;
  respawnEvery: number;
  pickupCount: number;
  boss: boolean;
  palette: Palette;
  hints: string[];
}

export interface MutationDef {
  id: string;
  name: string;
  kind: "move" | "defense" | "collect" | "attack";
  glyph: string;
  max: number;
  tint: string;
  tagline: string;
  levels: [string, string, string];
  apply: (t: Traits, level: number) => void;
}

export interface HudSnapshot {
  phase: Phase;
  hp: number;
  maxHp: number;
  dna: number;
  dnaNeeded: number;
  collected: number;
  quota: number;
  score: number;
  combo: number;
  stageIndex: number;
  stageCount: number;
  stageName: string;
  stageSubtitle: string;
  time: number;
  kills: number;
  shield: number;
  shieldMax: number;
  dashReady: number;
  hint: string;
  choices: MutationDef[];
  levels: Record<string, number>;
  dnaTotal: number;
  evolutions: number;
  locked: boolean;
  bossHp: number;
  touch: boolean;
  muted: boolean;
}

export interface RunResult {
  score: number;
  stageIndex: number;
  victory: boolean;
  dna: number;
  kills: number;
  time: number;
  evolutions: number;
}

export interface ScoreEntry {
  score: number;
  stage: number;
  victory: boolean;
  evolutions: number;
  date: string;
}
