import type { Vec } from "./types";
import { clamp } from "./math";

export type InputEvent = "pause" | "restart" | "confirm" | "mute" | "help";

const STICK_RADIUS = 74;

/**
 * Unified input: keyboard (WASD/arrows/space), mouse (hold to steer,
 * right-click to dash) and touch (dynamic joystick anywhere on the canvas).
 */
export class Input {
  keys = new Set<string>();
  pressed = new Set<string>();
  pointer = { x: 0, y: 0, down: false, has: false, type: "mouse" as string };
  stick = {
    active: false,
    id: -1,
    ox: 0,
    oy: 0,
    x: 0,
    y: 0,
  };
  stickVec: Vec = { x: 0, y: 0 };
  touchMode = false;
  dashQueued = false;
  gameInput = true;
  onEvent?: (e: InputEvent) => void;
  onAnyInput?: () => void;

  private el: HTMLElement | null = null;

  attach(el: HTMLElement) {
    this.el = el;
    // Show touch controls straight away on coarse-pointer devices.
    if (typeof window !== "undefined" && window.matchMedia) {
      if (window.matchMedia("(pointer: coarse)").matches) this.touchMode = true;
    }
    window.addEventListener("keydown", this.keyDown);
    window.addEventListener("keyup", this.keyUp);
    window.addEventListener("blur", this.blur);
    el.addEventListener("pointerdown", this.pointerDown);
    window.addEventListener("pointermove", this.pointerMove);
    window.addEventListener("pointerup", this.pointerUp);
    window.addEventListener("pointercancel", this.pointerUp);
    el.addEventListener("contextmenu", this.ctxMenu);
  }

  detach() {
    window.removeEventListener("keydown", this.keyDown);
    window.removeEventListener("keyup", this.keyUp);
    window.removeEventListener("blur", this.blur);
    const el = this.el;
    if (el) {
      el.removeEventListener("pointerdown", this.pointerDown);
      el.removeEventListener("contextmenu", this.ctxMenu);
    }
    window.removeEventListener("pointermove", this.pointerMove);
    window.removeEventListener("pointerup", this.pointerUp);
    window.removeEventListener("pointercancel", this.pointerUp);
    this.el = null;
  }

  private ctxMenu = (e: Event) => e.preventDefault();

  private blur = () => {
    this.keys.clear();
    this.pointer.down = false;
    this.stick.active = false;
    this.stickVec = { x: 0, y: 0 };
  };

  private keyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (
      [
        "arrowup",
        "arrowdown",
        "arrowleft",
        "arrowright",
        " ",
        "spacebar",
      ].includes(k)
    ) {
      e.preventDefault();
    }
    if (!this.keys.has(k)) this.pressed.add(k);
    this.keys.add(k);
    this.onAnyInput?.();
    if (k === "escape" || k === "p") this.onEvent?.("pause");
    if (k === "r") this.onEvent?.("restart");
    if (k === "enter") this.onEvent?.("confirm");
    if (k === "m") this.onEvent?.("mute");
    if (k === "h" || k === "?") this.onEvent?.("help");
    if (this.gameInput && (k === " " || k === "shift")) this.dashQueued = true;
  };

  private keyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  private localPos(e: PointerEvent) {
    const r = (this.el as HTMLElement).getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private pointerDown = (e: PointerEvent) => {
    this.onAnyInput?.();
    const p = this.localPos(e);
    if (e.pointerType === "touch") {
      this.touchMode = true;
      if (!this.stick.active) {
        this.stick.active = true;
        this.stick.id = e.pointerId;
        this.stick.ox = p.x;
        this.stick.oy = p.y;
        this.stick.x = p.x;
        this.stick.y = p.y;
        this.stickVec = { x: 0, y: 0 };
      }
      return;
    }
    this.pointer.x = p.x;
    this.pointer.y = p.y;
    this.pointer.has = true;
    this.pointer.type = e.pointerType;
    if (e.button === 2) {
      if (this.gameInput) this.dashQueued = true;
      return;
    }
    this.pointer.down = true;
  };

  private pointerMove = (e: PointerEvent) => {
    if (!this.el) return;
    const p = this.localPos(e);
    if (e.pointerType === "touch") {
      if (this.stick.active && this.stick.id === e.pointerId) {
        this.stick.x = p.x;
        this.stick.y = p.y;
        const dx = p.x - this.stick.ox;
        const dy = p.y - this.stick.oy;
        const l = Math.hypot(dx, dy);
        const n = l < 0.001 ? { x: 0, y: 0 } : { x: dx / l, y: dy / l };
        const m = clamp(l / STICK_RADIUS, 0, 1);
        // Slight dead zone so taps don't drift the virus.
        this.stickVec = l < 8 ? { x: 0, y: 0 } : { x: n.x * m, y: n.y * m };
      }
      return;
    }
    this.pointer.x = p.x;
    this.pointer.y = p.y;
    this.pointer.has = true;
    this.pointer.type = e.pointerType;
  };

  private pointerUp = (e: PointerEvent) => {
    if (e.pointerType === "touch") {
      if (this.stick.id === e.pointerId) {
        this.stick.active = false;
        this.stick.id = -1;
        this.stickVec = { x: 0, y: 0 };
      }
      return;
    }
    if (e.button === 2) return;
    this.pointer.down = false;
  };

  /** Relative steering vector, -1..1 per axis. */
  moveVector(): Vec {
    if (this.stick.active) {
      const v = this.stickVec;
      if (v.x !== 0 || v.y !== 0) return v;
    }
    let x = 0;
    let y = 0;
    if (this.keys.has("a") || this.keys.has("arrowleft")) x -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) x += 1;
    if (this.keys.has("w") || this.keys.has("arrowup")) y -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) y += 1;
    if (x !== 0 || y !== 0) {
      const l = Math.hypot(x, y);
      return { x: x / l, y: y / l };
    }
    return { x: 0, y: 0 };
  }

  isDown(k: string) {
    return this.keys.has(k);
  }

  consumePressed(k: string) {
    if (this.pressed.has(k)) {
      this.pressed.delete(k);
      return true;
    }
    return false;
  }

  endFrame() {
    this.pressed.clear();
  }

  consumeDash() {
    if (this.dashQueued) {
      this.dashQueued = false;
      return true;
    }
    return false;
  }
}

export const STICK_VISUAL_RADIUS = STICK_RADIUS;
