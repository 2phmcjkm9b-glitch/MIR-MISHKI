# VIRUS

A complete, original browser arcade game. You are a living green spiky virus
loose inside a colorful microscopic ecosystem: harvest loose DNA, dodge (or
shred) hostile organisms, **mutate** to visibly evolve your body, and infect the
host cell at the heart of each chamber.

Built with **React 19 + TypeScript + Vite + HTML5 Canvas**. No art assets —
every organism, particle and effect is drawn procedurally, and every sound is
synthesised with the Web Audio API.

---

## Running it

```bash
npm install
npm run dev      # development server (http://localhost:5173)
npm run build    # production build -> dist/
npm run preview  # serve the production build
```

Works in any modern desktop or mobile browser. On phones, play in landscape for
the widest view (the game is fully playable in portrait too).

---

## Controls

| Action | Keyboard | Mouse | Touch |
| --- | --- | --- | --- |
| Move | `W A S D` / arrow keys | hold the button — the virus chases the cursor | drag anywhere for a joystick |
| Dash | `Space` or `Shift` | right-click | big ⚡ DASH button |
| Pause | `Esc` or `P` | ❙❙ button | ❙❙ button |
| Choose mutation | `1` `2` `3` / `←→` + `Enter` | click a card | tap a card |
| Restart run | `R` (paused / dead / won) | button | button |
| Mute | `M` | 🔊 button | 🔊 button |

Dash is your only innate weapon: it shreds small organisms, cancels their
damage, and crosses acid pools safely. Everything else is earned by mutating.

---

## The loop

1. **Collect DNA** — glowing double helices (and gold plasmids worth 5). Quick
   chains build a score multiplier up to ×6.
2. **Evolve** — fill the EVOLVE bar and pick one of **three mutations** from
   twelve, each with three tiers. Your capsid visibly grows spikes, tails,
   cilia, plates, tendrils, aura and shield spores.
3. **Hit the quota** — each sector needs a DNA total before the host cell
   membrane unlocks (a progress ring is drawn around it).
4. **Infect** — dive into the open cell to clear the sector.

Score = DNA × multiplier + kills + mutations + sector bonuses (health and time
bonus). Best eight runs are stored in `localStorage`.

---

## The four sectors

| # | Sector | What makes it different |
| --- | --- | --- |
| 1 | **Plasma Shallows** | Open broth, drifting mites, first macrophages. Tutorial hints fire as you play. |
| 2 | **Acid Ducts** | Walled capillary maze, lytic acid pools that burn over time, immobile spike mines that detonate on contact, aggressive macrophage packs. |
| 3 | **Antibody Storm** | Wide open serum with three pushing currents, antibody hunters that keep range and fire bolt spreads, spores that split in two. |
| 4 | **The Nucleus** | Organelle lattice around a guarded nucleus, radial-burst **Sentinel** boss that stays shielded until your quota is met. |

---

## Mutations (12 × 3 tiers)

- **Locomotion** — Flagellum, Cilia Surge, Phase Membrane
- **Membrane** — Chitin Plating, Regen Cytoplasm, Binary Fission (spore shields)
- **Harvest** — Magnetic Genome, Filament Net, Taxis Sense
- **Offense** — Spike Barbs (thorns), Lytic Enzymes (digest on touch),
  Electrostatic Burst (dash shockwave)

Mutations stack across a whole run, and the drawn specimen always reflects the
exact combination you carry (see the live preview on the mutation cards and the
main menu).

---

## Project layout

```
src/
  App.tsx                 root
  index.css               theme, animations, UI classes
  components/
    GameShell.tsx         canvas + engine wiring + overlay routing
    Hud.tsx               health, DNA quota, evolve meter, score, touch dash
    Overlays.tsx          start screen, briefing, mutation picker, pause,
                          sector clear, run end, high scores, field manual
    VirusPreview.tsx      animated specimen canvas for menus
  game/
    engine.ts             fixed-step loop, phases, camera, input→world bridge
    world.ts              simulation: virus, enemies, pickups, hazards, scoring
    data.ts               stages, arenas, palettes, mutation definitions
    draw.ts               all procedural art + culling
    particles.ts          pooled particle / floating-text system
    input.ts              keyboard + mouse + touch joystick
    audio.ts              synthesised SFX
    save.ts               localStorage high scores
    math.ts, types.ts     helpers and shared types
```

The simulation runs at a fixed 60 Hz step with an accumulator, so behaviour is
identical on any refresh rate; rendering is once per animation frame with
camera culling, a cached serum pattern, cached glow sprites and a hard particle
cap for a stable 60 fps on mobile.
