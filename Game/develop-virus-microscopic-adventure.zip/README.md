# 🦠 VIRUS — A Microscopic Adventure

An original browser action game built entirely from scratch with **React + TypeScript + Vite + Canvas 2D**. You are a spiky green virus fighting through a living host, one chapter at a time: learn enemy patterns, dodge telegraphed attacks, harvest DNA, buy mutations, defeat the boss and infect the host cell.

## 🚀 Launch

```bash
npm install     # install dependencies
npm run dev     # start the dev server (open the printed localhost URL)
npm run build   # production build → dist/index.html (single file)
npm run preview # serve the production build locally
```

## 🎮 Controls

| Action | Keyboard / Mouse | Touch |
|---|---|---|
| Move | WASD / Arrow keys | Virtual joystick (left side) |
| Spike burst | Hold Left mouse / Space / J | SPIKE button |
| Dash (i-frames + contact damage) | Shift / Right mouse / K | DASH button |
| Pause | Esc / P | ❚❚ button |
| Instant restart (on defeat) | R | Restart button |

Aiming: with a mouse, spikes fire toward the cursor; on keyboard-only or touch, they auto-aim at the nearest threat.

## ✅ What is fully implemented

- **3 complete chapters**, each with a distinct environment, palette, enemy AI, hazard and boss:
  1. **The Bloodstream** — lunging Antibody Drones, the *Plasma Surge* current hazard, boss **The Macrophage** (telegraphed charges, area slams, minion summons).
  2. **The Lymph Node** — ranged Killer T-Cells with locking aim-lines, drifting *Antibody Mines*, boss **B-Cell Matriarch** (radial bullet rings, aimed volleys, mine drops, enrage phase).
  3. **The Neural Net** — teleporting Microglia Stalkers, *Synapse Storm* lightning zones, boss **The Overmind** (warned laser sweeps, expanding pulse rings, blinks, enrage phase).
- **Chapter loop**: destroy the kill quota → boss warning → boss fight → host cell appears → stand inside to **infect** it → chapter complete.
- **DNA economy + mutation shop** between chapters (8 balanced mutations: damage, extra spikes, max HP, cooldowns, lifesteal, dash, speed, DNA magnet).
- **Readable attack warnings** for every dangerous attack (pulsing red/colored circles, lines, aim-lasers, mine fuses, surge arrows).
- **Full state machine**: start screen, chapter intro briefings, pause, mutation shop, game over with instant restart, victory screen.
- **Score system + local high-score table** (top 8, persisted in `localStorage`, named entries).
- **Juice**: screen shake, hit-stop freeze frames, particle bursts, shockwave rings, floating damage numbers, hit flashes, dash trails, squash-and-stretch, expressive blinking eyes that track your aim.
- **Canvas-drawn HUD**: HP bar, DNA counter, score, objective tracker, boss HP bar, ability cooldown dials, off-screen host-cell arrow.
- **Input**: keyboard, mouse and multi-touch (joystick + buttons) simultaneously supported; responsive layout for desktop and mobile; devicePixelRatio-aware rendering targeting 60 fps.
- **All visuals are procedural Canvas primitives** — zero external assets.

## 🏗 Architecture (built to scale to 10 chapters / 100 levels)

```
src/game/
  chapters.ts   ← pure data: add a chapter entry here to add content
  mutations.ts  ← pure data: upgrade definitions
  game.ts       ← engine: loop, entities, bosses, hazards, rendering, HUD
  input.ts      ← unified keyboard/mouse/touch layer
  fx.ts         ← particles, floaters, shake, hit-stop
  highscores.ts ← persistence
  utils.ts      ← math helpers
src/App.tsx     ← React overlays (menus only; gameplay is pure canvas)
```

Enemy behaviors (`lunger` / `shooter` / `blinker`), hazards (`current` / `mines` / `storm`) and boss patterns are keyed by id in the chapter config, so new chapters reuse or extend behaviors without touching the core loop.
