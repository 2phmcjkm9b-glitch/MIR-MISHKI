import { useCallback, useEffect, useRef, useState } from "react";
import { Game, type UIState } from "./game/game";
import { isHighScore, loadScores, saveScore, type ScoreEntry } from "./game/highscores";
import { formatScore } from "./game/utils";

// ─── Small presentational helpers ──────────────────────────────────────────

function Btn({
  children,
  onClick,
  variant = "primary",
  disabled = false,
}: {
  children: React.ReactNode;
  onClick: () => void;
  variant?: "primary" | "ghost" | "danger";
  disabled?: boolean;
}) {
  const base =
    "px-6 py-3 rounded-xl font-bold tracking-wide transition-all duration-150 select-none active:scale-95 text-sm sm:text-base";
  const styles =
    variant === "primary"
      ? "bg-lime-400 text-lime-950 hover:bg-lime-300 shadow-[0_0_24px_rgba(163,230,53,0.45)]"
      : variant === "danger"
        ? "bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30"
        : "bg-white/10 text-white border border-white/20 hover:bg-white/20";
  return (
    <button
      className={`${base} ${styles} ${disabled ? "opacity-40 pointer-events-none" : ""}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

function Panel({ children, wide = false }: { children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/55 backdrop-blur-[3px] overflow-y-auto">
      <div
        className={`m-4 w-full ${wide ? "max-w-2xl" : "max-w-md"} rounded-2xl border border-lime-400/25 bg-[#07130a]/90 p-6 sm:p-8 shadow-[0_0_60px_rgba(163,230,53,0.15)] text-center`}
      >
        {children}
      </div>
    </div>
  );
}

function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight?: number }) {
  if (scores.length === 0)
    return <p className="text-white/40 text-sm italic">No infections recorded yet…</p>;
  return (
    <div className="mt-2 text-left text-sm">
      <div className="grid grid-cols-[2rem_1fr_4rem_5.5rem] gap-1 text-lime-300/60 font-bold text-xs uppercase tracking-wider pb-1 border-b border-white/10">
        <span>#</span>
        <span>Strain</span>
        <span className="text-right">Ch.</span>
        <span className="text-right">Score</span>
      </div>
      {scores.map((s, i) => (
        <div
          key={i}
          className={`grid grid-cols-[2rem_1fr_4rem_5.5rem] gap-1 py-1 border-b border-white/5 ${
            highlight !== undefined && s.score === highlight
              ? "text-lime-300 font-bold"
              : "text-white/80"
          }`}
        >
          <span>{i + 1}</span>
          <span className="truncate">{s.name}</span>
          <span className="text-right">{s.chapter}</span>
          <span className="text-right tabular-nums">{formatScore(s.score)}</span>
        </div>
      ))}
    </div>
  );
}

const Title = () => (
  <h1 className="text-5xl sm:text-6xl font-black tracking-[0.3em] text-lime-400 drop-shadow-[0_0_25px_rgba(163,230,53,0.6)]">
    VIRUS
  </h1>
);

// ─── Main app ───────────────────────────────────────────────────────────────

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [ui, setUI] = useState<UIState | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [name, setName] = useState(
    () => localStorage.getItem("virus-player-name") ?? "PATIENT-0"
  );
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas);
    gameRef.current = game;
    game.onUI = (s) => {
      setUI({ ...s });
      if (s.screen === "gameover" || s.screen === "victory") setSaved(false);
    };
    game.backToMenu();
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  const g = () => gameRef.current!;

  const handleSave = useCallback(() => {
    if (!ui || saved) return;
    const trimmed = name.trim().slice(0, 14) || "PATIENT-0";
    localStorage.setItem("virus-player-name", trimmed);
    setScores(
      saveScore({
        name: trimmed,
        score: ui.score,
        chapter: ui.reachedChapter,
        date: new Date().toISOString().slice(0, 10),
      })
    );
    setSaved(true);
  }, [ui, saved, name]);

  const screen = ui?.screen ?? "menu";

  return (
    <div className="fixed inset-0 bg-black overflow-hidden font-sans">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full touch-none select-none"
        style={{ touchAction: "none" }}
      />

      {/* in-game pause button (works for touch) */}
      {screen === "playing" && (
        <button
          aria-label="Pause"
          className="absolute top-3 right-3 z-10 w-10 h-10 rounded-full bg-black/40 border border-white/20 text-white/80 text-lg leading-none hover:bg-black/60 active:scale-90 transition-all"
          onClick={() => g().togglePause()}
        >
          ❚❚
        </button>
      )}

      {/* ── START SCREEN ── */}
      {screen === "menu" && ui && (
        <Panel wide>
          <div className="text-6xl mb-2 animate-bounce">🦠</div>
          <Title />
          <p className="mt-2 text-lime-200/70 text-sm tracking-widest uppercase">
            A microscopic adventure in three chapters
          </p>
          <div className="mt-5 grid sm:grid-cols-2 gap-4 text-left text-sm text-white/70">
            <div className="rounded-xl bg-white/5 p-4 border border-white/10">
              <p className="font-bold text-lime-300 mb-2">⌨️ Keyboard + Mouse</p>
              <p>Move — WASD / Arrows</p>
              <p>Spike burst — hold LMB / Space</p>
              <p>Dash — Shift / Right-click</p>
              <p>Pause — Esc / P</p>
            </div>
            <div className="rounded-xl bg-white/5 p-4 border border-white/10">
              <p className="font-bold text-lime-300 mb-2">📱 Touch</p>
              <p>Left side — virtual joystick</p>
              <p>SPIKE / DASH — on-screen buttons</p>
              <p className="mt-2 text-white/50">
                Collect 🧬 DNA, dodge the red warnings, defeat each boss and
                infect the host cell.
              </p>
            </div>
          </div>
          <div className="mt-6">
            <Btn onClick={() => g().startRun()}>BEGIN INFECTION</Btn>
          </div>
          <div className="mt-6 text-left">
            <p className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">
              Most virulent strains
            </p>
            <ScoreTable scores={scores} />
          </div>
        </Panel>
      )}

      {/* ── CHAPTER INTRO ── */}
      {screen === "intro" && ui && (
        <Panel wide>
          <p className="text-lime-300/60 text-xs font-bold tracking-[0.4em] uppercase">
            {ui.chapter.subtitle}
          </p>
          <h2 className="mt-1 text-3xl sm:text-4xl font-black tracking-widest text-lime-300">
            {ui.chapter.name}
          </h2>
          <p className="mt-4 text-white/75 text-sm sm:text-base leading-relaxed text-left">
            {ui.chapter.briefing}
          </p>
          <div className="mt-4 grid grid-cols-3 gap-2 text-xs text-left">
            <div className="rounded-lg bg-white/5 border border-white/10 p-2.5">
              <p className="text-rose-300 font-bold">ENEMY</p>
              <p className="text-white/70 mt-1">{ui.chapter.enemyName}</p>
            </div>
            <div className="rounded-lg bg-white/5 border border-white/10 p-2.5">
              <p className="text-amber-300 font-bold">HAZARD</p>
              <p className="text-white/70 mt-1">{ui.chapter.hazardName}</p>
            </div>
            <div className="rounded-lg bg-white/5 border border-white/10 p-2.5">
              <p className="text-fuchsia-300 font-bold">BOSS</p>
              <p className="text-white/70 mt-1">{ui.chapter.bossName}</p>
            </div>
          </div>
          <div className="mt-6 flex justify-center gap-3">
            <Btn onClick={() => g().beginChapter()}>ENTER CHAPTER {ui.chapter.id}</Btn>
          </div>
        </Panel>
      )}

      {/* ── PAUSE ── */}
      {screen === "paused" && ui && (
        <Panel>
          <h2 className="text-3xl font-black tracking-widest text-white">PAUSED</h2>
          <p className="mt-2 text-white/50 text-sm">
            Chapter {ui.chapter.id} · Score {formatScore(ui.score)} · 🧬 {ui.dna}
          </p>
          <div className="mt-6 flex flex-col gap-3 items-center">
            <Btn onClick={() => g().togglePause()}>RESUME</Btn>
            <Btn variant="ghost" onClick={() => g().restart()}>
              RESTART RUN
            </Btn>
            <Btn variant="danger" onClick={() => g().backToMenu()}>
              QUIT TO MENU
            </Btn>
          </div>
        </Panel>
      )}

      {/* ── MUTATION SHOP ── */}
      {screen === "mutation" && ui && (
        <Panel wide>
          <h2 className="text-2xl sm:text-3xl font-black tracking-widest text-lime-300">
            CHAPTER {ui.chapter.id} INFECTED
          </h2>
          <p className="mt-1 text-white/60 text-sm">
            Spend DNA on one mutation before moving deeper. You carry{" "}
            <span className="text-lime-300 font-bold">🧬 {ui.dna} DNA</span>.
          </p>
          <div className="mt-5 grid sm:grid-cols-3 gap-3">
            {ui.mutationOffer.map((m) => {
              const affordable = ui.dna >= m.cost;
              return (
                <button
                  key={m.id}
                  onClick={() => g().pickMutation(m.id)}
                  disabled={!affordable}
                  className={`rounded-xl border p-4 text-left transition-all active:scale-95 ${
                    affordable
                      ? "border-lime-400/40 bg-lime-400/10 hover:bg-lime-400/20 cursor-pointer"
                      : "border-white/10 bg-white/5 opacity-45"
                  }`}
                >
                  <div className="text-2xl">{m.icon}</div>
                  <p className="font-bold text-white mt-1 text-sm">{m.name}</p>
                  <p className="text-white/60 text-xs mt-1">{m.desc}</p>
                  <p
                    className={`mt-2 text-xs font-bold ${affordable ? "text-lime-300" : "text-rose-400"}`}
                  >
                    🧬 {m.cost} DNA
                  </p>
                </button>
              );
            })}
          </div>
          <div className="mt-5">
            <Btn variant="ghost" onClick={() => g().skipMutation()}>
              CONTINUE WITHOUT MUTATING →
            </Btn>
          </div>
        </Panel>
      )}

      {/* ── GAME OVER ── */}
      {screen === "gameover" && ui && (
        <Panel>
          <div className="text-5xl mb-1">💀</div>
          <h2 className="text-3xl font-black tracking-widest text-rose-400">
            STRAIN NEUTRALIZED
          </h2>
          <p className="mt-3 text-white/70 text-sm">
            The immune system prevailed in Chapter {ui.chapter.id}.
          </p>
          <p className="mt-2 text-2xl font-black text-white tabular-nums">
            {formatScore(ui.score)}
            <span className="text-sm font-normal text-white/40 ml-2">pts</span>
          </p>
          {!saved && isHighScore(ui.score) ? (
            <div className="mt-4 flex gap-2 justify-center">
              <input
                value={name}
                maxLength={14}
                onChange={(e) => setName(e.target.value)}
                className="w-40 rounded-lg bg-white/10 border border-lime-400/40 px-3 py-2 text-white text-sm outline-none focus:border-lime-300"
                placeholder="Strain name"
              />
              <Btn onClick={handleSave}>SAVE</Btn>
            </div>
          ) : (
            <div className="mt-3">
              <ScoreTable scores={scores} highlight={saved ? ui.score : undefined} />
            </div>
          )}
          <div className="mt-6 flex flex-col gap-3 items-center">
            <Btn onClick={() => g().restart()}>RESTART (R)</Btn>
            <Btn variant="ghost" onClick={() => g().backToMenu()}>
              MAIN MENU
            </Btn>
          </div>
        </Panel>
      )}

      {/* ── VICTORY ── */}
      {screen === "victory" && ui && (
        <Panel>
          <div className="text-5xl mb-1">🏆</div>
          <h2 className="text-3xl font-black tracking-widest text-lime-300">
            TOTAL INFECTION
          </h2>
          <p className="mt-3 text-white/70 text-sm leading-relaxed">
            All three chapters conquered — bloodstream, lymph node and neural
            net now belong to you. The host never stood a chance.
          </p>
          <p className="mt-3 text-2xl font-black text-white tabular-nums">
            {formatScore(ui.score)}
            <span className="text-sm font-normal text-white/40 ml-2">pts</span>
          </p>
          <p className="text-white/40 text-xs mt-1">
            Run time {Math.floor(ui.runTime / 60)}m {Math.floor(ui.runTime % 60)}s
          </p>
          {!saved && isHighScore(ui.score) ? (
            <div className="mt-4 flex gap-2 justify-center">
              <input
                value={name}
                maxLength={14}
                onChange={(e) => setName(e.target.value)}
                className="w-40 rounded-lg bg-white/10 border border-lime-400/40 px-3 py-2 text-white text-sm outline-none focus:border-lime-300"
                placeholder="Strain name"
              />
              <Btn onClick={handleSave}>SAVE</Btn>
            </div>
          ) : (
            <div className="mt-3">
              <ScoreTable scores={scores} highlight={saved ? ui.score : undefined} />
            </div>
          )}
          <div className="mt-6 flex flex-col gap-3 items-center">
            <Btn onClick={() => g().restart()}>NEW RUN</Btn>
            <Btn variant="ghost" onClick={() => g().backToMenu()}>
              MAIN MENU
            </Btn>
          </div>
        </Panel>
      )}
    </div>
  );
}
