// ─── Mutation upgrades purchased with DNA between chapters ────────────────

export interface PlayerStats {
  maxHp: number;
  speed: number;
  spikeDmg: number;
  spikeCount: number;
  spikeCd: number;
  dashCd: number;
  dashInvuln: number;
  lifeSteal: number; // hp per kill
  magnet: number; // DNA pickup radius
}

export function baseStats(): PlayerStats {
  return {
    maxHp: 100,
    speed: 265,
    spikeDmg: 12,
    spikeCount: 3,
    spikeCd: 0.42,
    dashCd: 3.2,
    dashInvuln: 0.4,
    lifeSteal: 0,
    magnet: 120,
  };
}

export interface MutationDef {
  id: string;
  name: string;
  icon: string;
  desc: string;
  cost: number;
  apply: (s: PlayerStats) => void;
}

export const MUTATIONS: MutationDef[] = [
  {
    id: "sharp",
    name: "Sharper Spikes",
    icon: "🗡",
    desc: "+35% spike damage",
    cost: 30,
    apply: (s) => (s.spikeDmg *= 1.35),
  },
  {
    id: "replicate",
    name: "Viral Replication",
    icon: "🧬",
    desc: "Fire +2 extra spikes per burst",
    cost: 45,
    apply: (s) => (s.spikeCount += 2),
  },
  {
    id: "capsid",
    name: "Thick Capsid",
    icon: "🛡",
    desc: "+30 max HP and fully heal",
    cost: 35,
    apply: (s) => (s.maxHp += 30),
  },
  {
    id: "rapid",
    name: "Rapid Mutation",
    icon: "⚡",
    desc: "−25% spike cooldown",
    cost: 35,
    apply: (s) => (s.spikeCd *= 0.75),
  },
  {
    id: "leech",
    name: "Membrane Leech",
    icon: "🩸",
    desc: "Kills restore 3 HP",
    cost: 30,
    apply: (s) => (s.lifeSteal += 3),
  },
  {
    id: "phase",
    name: "Phase Protein",
    icon: "💨",
    desc: "−40% dash cooldown, longer invulnerability",
    cost: 30,
    apply: (s) => {
      s.dashCd *= 0.6;
      s.dashInvuln += 0.15;
    },
  },
  {
    id: "flagella",
    name: "Turbo Flagella",
    icon: "🌀",
    desc: "+18% movement speed",
    cost: 25,
    apply: (s) => (s.speed *= 1.18),
  },
  {
    id: "enzyme",
    name: "Binding Enzyme",
    icon: "🧲",
    desc: "DNA is attracted from much farther away",
    cost: 20,
    apply: (s) => (s.magnet += 160),
  },
];

/** Pick up to 3 mutations the player does not own yet. */
export function offerMutations(owned: Set<string>): MutationDef[] {
  const pool = MUTATIONS.filter((m) => !owned.has(m.id));
  const out: MutationDef[] = [];
  const copy = [...pool];
  while (out.length < 3 && copy.length > 0) {
    const i = Math.floor(Math.random() * copy.length);
    out.push(copy.splice(i, 1)[0]);
  }
  return out;
}
