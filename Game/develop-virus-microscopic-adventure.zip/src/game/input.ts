// ─── Unified input: keyboard, mouse, multi-touch virtual controls ──────────

import { clamp } from "./utils";

export interface VirtualButton {
  x: number; // CSS px, set by the game each frame (layout-responsive)
  y: number;
  r: number;
  pressed: boolean;
  pointerId: number;
  label: string;
}

interface TrackedPointer {
  id: number;
  x: number;
  y: number;
  isTouch: boolean;
}

export class Input {
  keys = new Set<string>();
  // mouse (CSS pixel space, relative to canvas)
  mouseX = 0;
  mouseY = 0;
  mouseDown = false; // left button held
  mouseUsed = false; // has the mouse moved recently (aim source)
  touchMode = false; // show virtual controls

  // virtual joystick
  joyActive = false;
  joyPointer = -1;
  joyBaseX = 0;
  joyBaseY = 0;
  joyX = 0; // -1..1
  joyY = 0;

  burstBtn: VirtualButton = { x: 0, y: 0, r: 44, pressed: false, pointerId: -1, label: "SPIKE" };
  dashBtn: VirtualButton = { x: 0, y: 0, r: 36, pressed: false, pointerId: -1, label: "DASH" };

  /** one-shot flags consumed by the game */
  dashQueued = false;
  pauseQueued = false;

  private pointers = new Map<number, TrackedPointer>();
  private canvas: HTMLCanvasElement;
  private detachFns: Array<() => void> = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;

    const on = (
      target: Window | HTMLElement,
      type: string,
      fn: (e: never) => void,
      opts?: AddEventListenerOptions
    ) => {
      target.addEventListener(type, fn as EventListener, opts);
      this.detachFns.push(() => target.removeEventListener(type, fn as EventListener, opts));
    };

    on(window, "keydown", (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      if (!e.repeat) {
        if (k === "shift") this.dashQueued = true;
        if (k === "escape" || k === "p") this.pauseQueued = true;
      }
      this.keys.add(k);
    });
    on(window, "keyup", (e: KeyboardEvent) => this.keys.delete(e.key.toLowerCase()));
    on(window, "blur", () => {
      this.keys.clear();
      this.mouseDown = false;
    });

    on(canvas, "contextmenu", (e: Event) => e.preventDefault());

    on(canvas, "pointerdown", (e: PointerEvent) => this.onPointerDown(e), { passive: false });
    on(window, "pointermove", (e: PointerEvent) => this.onPointerMove(e), { passive: false });
    on(window, "pointerup", (e: PointerEvent) => this.onPointerUp(e));
    on(window, "pointercancel", (e: PointerEvent) => this.onPointerUp(e));
  }

  destroy() {
    this.detachFns.forEach((f) => f());
    this.detachFns = [];
  }

  private toLocal(e: PointerEvent): { x: number; y: number } {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private onPointerDown(e: PointerEvent) {
    e.preventDefault();
    const { x, y } = this.toLocal(e);
    const isTouch = e.pointerType === "touch";
    this.pointers.set(e.pointerId, { id: e.pointerId, x, y, isTouch });

    if (isTouch) {
      this.touchMode = true;
      this.mouseUsed = false;
      // Buttons first (right side)
      if (this.hitBtn(this.burstBtn, x, y)) {
        this.burstBtn.pressed = true;
        this.burstBtn.pointerId = e.pointerId;
        return;
      }
      if (this.hitBtn(this.dashBtn, x, y)) {
        this.dashBtn.pressed = true;
        this.dashBtn.pointerId = e.pointerId;
        this.dashQueued = true;
        return;
      }
      // Left ~60% of screen → joystick
      const rect = this.canvas.getBoundingClientRect();
      if (x < rect.width * 0.6 && !this.joyActive) {
        this.joyActive = true;
        this.joyPointer = e.pointerId;
        this.joyBaseX = x;
        this.joyBaseY = y;
        this.joyX = 0;
        this.joyY = 0;
      }
      return;
    }

    // Mouse / pen
    this.mouseUsed = true;
    this.mouseX = x;
    this.mouseY = y;
    if (e.button === 0) this.mouseDown = true;
    if (e.button === 2) this.dashQueued = true;
  }

  private onPointerMove(e: PointerEvent) {
    const { x, y } = this.toLocal(e);
    const p = this.pointers.get(e.pointerId);
    if (p) {
      p.x = x;
      p.y = y;
    }
    if (e.pointerType !== "touch") {
      this.mouseX = x;
      this.mouseY = y;
      this.mouseUsed = true;
    }
    if (this.joyActive && e.pointerId === this.joyPointer) {
      const dx = x - this.joyBaseX;
      const dy = y - this.joyBaseY;
      const max = 52;
      const len = Math.sqrt(dx * dx + dy * dy);
      const s = len > max ? max / len : 1;
      this.joyX = clamp((dx * s) / max, -1, 1);
      this.joyY = clamp((dy * s) / max, -1, 1);
    }
  }

  private onPointerUp(e: PointerEvent) {
    this.pointers.delete(e.pointerId);
    if (e.pointerType !== "touch" && e.button === 0) this.mouseDown = false;
    if (e.pointerId === this.joyPointer) {
      this.joyActive = false;
      this.joyPointer = -1;
      this.joyX = 0;
      this.joyY = 0;
    }
    if (e.pointerId === this.burstBtn.pointerId) {
      this.burstBtn.pressed = false;
      this.burstBtn.pointerId = -1;
    }
    if (e.pointerId === this.dashBtn.pointerId) {
      this.dashBtn.pressed = false;
      this.dashBtn.pointerId = -1;
    }
  }

  private hitBtn(b: VirtualButton, x: number, y: number): boolean {
    const dx = x - b.x;
    const dy = y - b.y;
    return dx * dx + dy * dy <= (b.r + 14) * (b.r + 14);
  }

  /** movement vector −1..1 from keyboard or joystick */
  getMove(): { x: number; y: number } {
    let x = 0;
    let y = 0;
    if (this.keys.has("a") || this.keys.has("arrowleft")) x -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) x += 1;
    if (this.keys.has("w") || this.keys.has("arrowup")) y -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) y += 1;
    if (x !== 0 || y !== 0) {
      const len = Math.sqrt(x * x + y * y);
      return { x: x / len, y: y / len };
    }
    if (this.joyActive) return { x: this.joyX, y: this.joyY };
    return { x: 0, y: 0 };
  }

  firing(): boolean {
    return this.mouseDown || this.keys.has(" ") || this.keys.has("j") || this.burstBtn.pressed;
  }

  consumeDash(): boolean {
    const q = this.dashQueued || this.keys.has("k");
    this.dashQueued = false;
    return q;
  }

  consumePause(): boolean {
    const q = this.pauseQueued;
    this.pauseQueued = false;
    return q;
  }
}
