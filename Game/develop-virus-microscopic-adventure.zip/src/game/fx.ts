// ─── Juice: particles, floating text, screen shake ─────────────────────────

import { rand, TAU } from "./utils";

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  drag: number;
  grav: number;
  shape: "dot" | "spark" | "ring";
}

export interface Floater {
  x: number;
  y: number;
  vy: number;
  life: number;
  maxLife: number;
  text: string;
  color: string;
  size: number;
}

const MAX_PARTICLES = 420;

export class FX {
  particles: Particle[] = [];
  floaters: Floater[] = [];
  shakeT = 0;
  shakeMag = 0;
  flashT = 0;
  flashColor = "#ffffff";
  hitStop = 0; // brief time-freeze for impact

  shake(mag: number, dur = 0.25) {
    if (mag > this.shakeMag) this.shakeMag = mag;
    this.shakeT = Math.max(this.shakeT, dur);
  }

  flash(color: string, dur = 0.12) {
    this.flashT = Math.max(this.flashT, dur);
    this.flashColor = color;
  }

  freeze(dur: number) {
    this.hitStop = Math.max(this.hitStop, dur);
  }

  burst(
    x: number,
    y: number,
    count: number,
    color: string,
    opts: Partial<{ speed: number; size: number; life: number; shape: Particle["shape"]; spread: number; angle: number; grav: number }> = {}
  ) {
    const { speed = 180, size = 4, life = 0.6, shape = "dot", spread = TAU, angle = 0, grav = 0 } = opts;
    const budget = Math.min(count, MAX_PARTICLES - this.particles.length);
    for (let i = 0; i < budget; i++) {
      const a = angle + (Math.random() - 0.5) * spread;
      const sp = speed * rand(0.35, 1.15);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: life * rand(0.6, 1.3),
        maxLife: life,
        size: size * rand(0.6, 1.4),
        color,
        drag: 3.2,
        grav,
        shape,
      });
    }
  }

  ring(x: number, y: number, color: string, size = 10) {
    if (this.particles.length >= MAX_PARTICLES) return;
    this.particles.push({
      x,
      y,
      vx: 0,
      vy: 0,
      life: 0.45,
      maxLife: 0.45,
      size,
      color,
      drag: 0,
      grav: 0,
      shape: "ring",
    });
  }

  float(x: number, y: number, text: string, color: string, size = 15) {
    if (this.floaters.length > 40) this.floaters.shift();
    this.floaters.push({ x, y, vy: -46, life: 0.9, maxLife: 0.9, text, color, size });
  }

  update(dt: number) {
    this.shakeT = Math.max(0, this.shakeT - dt);
    if (this.shakeT <= 0) this.shakeMag = 0;
    this.flashT = Math.max(0, this.flashT - dt);
    this.hitStop = Math.max(0, this.hitStop - dt);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      const d = Math.exp(-p.drag * dt);
      p.vx *= d;
      p.vy = p.vy * d + p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.floaters.length - 1; i >= 0; i--) {
      const f = this.floaters[i];
      f.life -= dt;
      f.y += f.vy * dt;
      f.vy *= Math.exp(-2 * dt);
      if (f.life <= 0) this.floaters.splice(i, 1);
    }
  }

  getShakeOffset(time: number): { x: number; y: number } {
    if (this.shakeT <= 0) return { x: 0, y: 0 };
    const m = this.shakeMag * (this.shakeT > 0.2 ? 1 : this.shakeT / 0.2);
    return {
      x: Math.sin(time * 61.7) * m + Math.sin(time * 37.3) * m * 0.5,
      y: Math.cos(time * 53.1) * m + Math.cos(time * 41.9) * m * 0.5,
    };
  }

  drawWorld(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      const t = p.life / p.maxLife;
      ctx.globalAlpha = Math.min(1, t * 1.6);
      ctx.fillStyle = p.color;
      if (p.shape === "ring") {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3 * t;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.6 - t), 0, TAU);
        ctx.stroke();
      } else if (p.shape === "spark") {
        const len = Math.max(2, Math.hypot(p.vx, p.vy) * 0.045);
        const a = Math.atan2(p.vy, p.vx);
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(a);
        ctx.fillRect(-len, -p.size * t * 0.5, len * 2, p.size * t);
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.4, p.size * t), 0, TAU);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
    for (const f of this.floaters) {
      const t = f.life / f.maxLife;
      ctx.globalAlpha = Math.min(1, t * 2);
      ctx.font = `bold ${f.size}px "Trebuchet MS", sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(0,0,0,0.55)";
      ctx.strokeText(f.text, f.x, f.y);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;
  }

  reset() {
    this.particles.length = 0;
    this.floaters.length = 0;
    this.shakeT = 0;
    this.flashT = 0;
    this.hitStop = 0;
  }
}
