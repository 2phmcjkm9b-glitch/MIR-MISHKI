// ─── Data-driven chapter definitions ───────────────────────────────────────
// Adding a new chapter = add an entry here + (optionally) a new behavior id.
// The engine reads everything else from this config, so the structure
// scales toward 10 chapters / 100 levels.

export type EnemyBehavior = "lunger" | "shooter" | "blinker";
export type HazardKind = "current" | "mines" | "storm";
export type BossPattern = "macrophage" | "matriarch" | "overmind";

export interface ChapterDef {
  id: number;
  name: string;
  subtitle: string;
  briefing: string;
  // palette
  bgTop: string;
  bgBottom: string;
  membrane: string;
  accent: string;
  blobColors: string[];
  // objective
  killQuota: number;
  // enemies
  enemyName: string;
  enemyBehavior: EnemyBehavior;
  enemyHp: number;
  enemySpeed: number;
  enemyDmg: number;
  maxEnemies: number;
  spawnInterval: number;
  // hazard
  hazardName: string;
  hazardKind: HazardKind;
  hazardHint: string;
  // boss
  bossName: string;
  bossPattern: BossPattern;
  bossHp: number;
  bossDmg: number;
}

export const CHAPTERS: ChapterDef[] = [
  {
    id: 1,
    name: "THE BLOODSTREAM",
    subtitle: "Chapter I",
    briefing:
      "You awaken inside a host artery. Antibody drones patrol the plasma — they flash red before lunging. Beware the periodic PLASMA SURGE that sweeps everything downstream. Shred 8 drones to lure out the Macrophage.",
    bgTop: "#3d0a14",
    bgBottom: "#1a040a",
    membrane: "#ff5577",
    accent: "#ff8899",
    blobColors: ["rgba(205,55,75,0.35)", "rgba(165,35,60,0.3)", "rgba(230,90,105,0.22)"],
    killQuota: 8,
    enemyName: "Antibody Drone",
    enemyBehavior: "lunger",
    enemyHp: 30,
    enemySpeed: 95,
    enemyDmg: 12,
    maxEnemies: 5,
    spawnInterval: 2.2,
    hazardName: "Plasma Surge",
    hazardKind: "current",
    hazardHint: "Arrows warn of the surge direction — swim across it!",
    bossName: "THE MACROPHAGE",
    bossPattern: "macrophage",
    bossHp: 420,
    bossDmg: 20,
  },
  {
    id: 2,
    name: "THE LYMPH NODE",
    subtitle: "Chapter II",
    briefing:
      "You slip into the immune system's fortress. Killer T-Cells track you with aim-lines before firing bursts — strafe sideways! Drifting ANTIBODY MINES detonate when you linger close. Destroy 10 T-Cells to force the B-Cell Matriarch out of hiding.",
    bgTop: "#1f1040",
    bgBottom: "#0b0620",
    membrane: "#a070ff",
    accent: "#c49aff",
    blobColors: ["rgba(120,80,210,0.3)", "rgba(90,55,180,0.28)", "rgba(160,110,240,0.2)"],
    killQuota: 10,
    enemyName: "Killer T-Cell",
    enemyBehavior: "shooter",
    enemyHp: 42,
    enemySpeed: 80,
    enemyDmg: 10,
    maxEnemies: 5,
    spawnInterval: 2.4,
    hazardName: "Antibody Mines",
    hazardKind: "mines",
    hazardHint: "Mines pulse faster as they arm — back away before the blast!",
    bossName: "B-CELL MATRIARCH",
    bossPattern: "matriarch",
    bossHp: 560,
    bossDmg: 16,
  },
  {
    id: 3,
    name: "THE NEURAL NET",
    subtitle: "Chapter III",
    briefing:
      "The final barrier: living circuitry of the host's nervous system. Microglia Stalkers teleport beside you — watch the warning circle and dodge the slash. SYNAPSE STORMS electrify marked zones. Purge 12 stalkers to awaken the Overmind.",
    bgTop: "#042a33",
    bgBottom: "#01111a",
    membrane: "#33e0ff",
    accent: "#7ff0ff",
    blobColors: ["rgba(30,140,170,0.28)", "rgba(20,100,140,0.26)", "rgba(70,190,220,0.18)"],
    killQuota: 12,
    enemyName: "Microglia Stalker",
    enemyBehavior: "blinker",
    enemyHp: 55,
    enemySpeed: 110,
    enemyDmg: 14,
    maxEnemies: 6,
    spawnInterval: 2.0,
    hazardName: "Synapse Storm",
    hazardKind: "storm",
    hazardHint: "Electric zones flash before they zap — step out fast!",
    bossName: "THE OVERMIND",
    bossPattern: "overmind",
    bossHp: 700,
    bossDmg: 18,
  },
];
