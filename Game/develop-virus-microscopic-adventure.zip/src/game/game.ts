// ─── VIRUS — core game engine ──────────────────────────────────────────────
// Canvas-rendered action game. React only drives menu overlays; everything
// in-world (HUD included) renders here for consistent 60fps.

import { CHAPTERS, type ChapterDef } from "./chapters";
import { FX } from "./fx";
import { Input } from "./input";
import { baseStats, offerMutations, type MutationDef, type PlayerStats } from "./mutations";
import { angleTo, clamp, damp, dist, lerp, pointSegDist, rand, randInt, TAU } from "./utils";

export type Screen =
  | "menu"
  | "intro"
  | "playing"
  | "paused"
  | "mutation"
  | "gameover"
  | "victory";

export interface UIState {
  screen: Screen;
  score: number;
  dna: number;
  chapterIndex: number;
  chapter: ChapterDef;
  mutationOffer: MutationDef[];
  owned: string[];
  kills: number;
  runTime: number;
  reachedChapter: number;
}

// ── entity shapes ──────────────────────────────────────────────────────────

interface Bullet {
  x: number; y: number; vx: number; vy: number;
  r: number; dmg: number; life: number; color: string; friendly: boolean;
}

type EState = "wander" | "telegraph" | "attack" | "recover" | "fadeout" | "warn" | "slash";

interface Enemy {
  x: number; y: number; vx: number; vy: number; r: number;
  hp: number; maxHp: number; dmg: number;
  behavior: ChapterDef["enemyBehavior"];
  state: EState; stateT: number; cd: number;
  aimX: number; aimY: number; angle: number;
  flash: number; seed: number; alpha: number;
  shots: number;
}

interface Boss {
  x: number; y: number; vx: number; vy: number; r: number;
  hp: number; maxHp: number; dmg: number;
  pattern: ChapterDef["bossPattern"];
  state: string; stateT: number; attackCd: number;
  aimX: number; aimY: number; dirX: number; dirY: number;
  flash: number; seed: number; spin: number;
}

interface Warning {
  kind: "circle" | "line";
  x: number; y: number; x2: number; y2: number;
  r: number; t: number; dur: number; color: string; width: number;
}

interface Beam {
  x: number; y: number; x2: number; y2: number;
  t: number; dur: number; width: number; dmg: number; color: string;
}

interface PulseRing {
  x: number; y: number; r: number; speed: number; maxR: number; dmg: number; hit: boolean;
}

interface Mine {
  x: number; y: number; vx: number; vy: number; r: number;
  fuse: number; armed: boolean; seed: number; dead: boolean;
}

interface StormZone { x: number; y: number; r: number; t: number; zapT: number; }

interface Orb { x: number; y: number; vx: number; vy: number; seed: number; }

interface BgBlob { x: number; y: number; r: number; par: number; color: string; seed: number; }

// ── engine ─────────────────────────────────────────────────────────────────

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private input: Input;
  private fx = new FX();
  private raf = 0;
  private lastT = 0;
  private vignette: HTMLCanvasElement | null = null;

  viewW = 800; viewH = 600;
  worldW = 2300; worldH = 1650;
  camX = 0; camY = 0;
  time = 0;

  screen: Screen = "menu";
  score = 0; dna = 0; kills = 0; runTime = 0;
  chapterIndex = 0;
  reachedChapter = 1;
  stats: PlayerStats = baseStats();
  owned = new Set<string>();
  mutationOffer: MutationDef[] = [];

  // player
  px = 0; py = 0; pvx = 0; pvy = 0; pr = 16;
  hp = 100;
  fireCd = 0; dashCdT = 0; dashT = 0; invulnT = 0; hurtT = 0;
  aimA = 0; dying = false; deathT = 0; blink = 0;
  infectHold = 0;

  // world content
  enemies: Enemy[] = [];
  bullets: Bullet[] = [];
  orbs: Orb[] = [];
  warnings: Warning[] = [];
  beams: Beam[] = [];
  rings: PulseRing[] = [];
  mines: Mine[] = [];
  stormZones: StormZone[] = [];
  blobs: BgBlob[] = [];
  motes: { x: number; y: number; s: number }[] = [];
  boss: Boss | null = null;
  bossSpawned = false; bossDefeated = false; bossWarnT = 0;
  spawnT = 0; mineRespawnT = 0; stormT = 0;
  // plasma current hazard
  currentPhase: "idle" | "warn" | "active" = "idle";
  currentT = 5; currentA = 0;
  infectX = 0; infectY = 0; infectActive = false; infectProg = 0;
  banner = { text: "", sub: "", t: 0 };

  onUI: ((s: UIState) => void) | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas 2D not supported");
    this.ctx = ctx;
    this.input = new Input(canvas);
    this.resize();
    window.addEventListener("resize", this.resize);
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.resize);
    this.input.destroy();
  }

  private resize = () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.viewW = w; this.viewH = h;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // pre-render vignette
    const v = document.createElement("canvas");
    v.width = Math.max(2, Math.round(w / 2));
    v.height = Math.max(2, Math.round(h / 2));
    const vc = v.getContext("2d")!;
    const g = vc.createRadialGradient(
      v.width / 2, v.height / 2, Math.min(v.width, v.height) * 0.38,
      v.width / 2, v.height / 2, Math.max(v.width, v.height) * 0.72
    );
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.55)");
    vc.fillStyle = g;
    vc.fillRect(0, 0, v.width, v.height);
    this.vignette = v;
  };

  get chapter(): ChapterDef {
    return CHAPTERS[this.chapterIndex];
  }

  private pushUI() {
    this.onUI?.({
      screen: this.screen,
      score: this.score,
      dna: this.dna,
      chapterIndex: this.chapterIndex,
      chapter: this.chapter,
      mutationOffer: this.mutationOffer,
      owned: [...this.owned],
      kills: this.kills,
      runTime: this.runTime,
      reachedChapter: this.reachedChapter,
    });
  }

  // ── public control API (called from React) ───────────────────────────────

  startRun() {
    this.score = 0; this.dna = 0; this.runTime = 0;
    this.stats = baseStats();
    this.owned.clear();
    this.chapterIndex = 0;
    this.reachedChapter = 1;
    this.screen = "intro";
    this.pushUI();
  }

  beginChapter() {
    const c = this.chapter;
    this.reachedChapter = Math.max(this.reachedChapter, c.id);
    this.kills = 0;
    this.enemies = []; this.bullets = []; this.orbs = [];
    this.warnings = []; this.beams = []; this.rings = [];
    this.mines = []; this.stormZones = [];
    this.boss = null; this.bossSpawned = false; this.bossDefeated = false; this.bossWarnT = 0;
    this.infectActive = false; this.infectProg = 0; this.infectHold = 0;
    this.spawnT = 1.0; this.mineRespawnT = 0; this.stormT = 3.5;
    this.currentPhase = "idle"; this.currentT = 5;
    this.fx.reset();
    this.dying = false; this.deathT = 0;
    this.hp = this.stats.maxHp;
    this.px = this.worldW / 2; this.py = this.worldH / 2;
    this.pvx = 0; this.pvy = 0;
    this.fireCd = 0; this.dashCdT = 0; this.dashT = 0; this.invulnT = 1; this.hurtT = 0;
    this.camX = this.px - this.viewW / 2;
    this.camY = this.py - this.viewH / 2;
    // decorate world
    this.blobs = [];
    for (let i = 0; i < 26; i++) {
      this.blobs.push({
        x: rand(0, this.worldW), y: rand(0, this.worldH),
        r: rand(50, 170), par: rand(0.55, 0.9),
        color: c.blobColors[i % c.blobColors.length], seed: rand(0, 10),
      });
    }
    this.motes = [];
    for (let i = 0; i < 42; i++) {
      this.motes.push({ x: rand(0, this.worldW), y: rand(0, this.worldH), s: rand(1, 2.6) });
    }
    // ambient DNA
    for (let i = 0; i < 14; i++) {
      this.spawnDNA(rand(150, this.worldW - 150), rand(150, this.worldH - 150), 1);
    }
    if (c.hazardKind === "mines") {
      for (let i = 0; i < 6; i++) this.spawnMine();
    }
    this.banner = { text: c.name, sub: `Destroy ${c.killQuota} ${c.enemyName}s`, t: 3 };
    this.screen = "playing";
    this.pushUI();
  }

  togglePause() {
    if (this.screen === "playing") {
      this.screen = "paused";
      this.pushUI();
    } else if (this.screen === "paused") {
      this.screen = "playing";
      this.pushUI();
    }
  }

  restart() {
    this.startRun();
    this.beginChapter();
  }

  backToMenu() {
    this.screen = "menu";
    this.pushUI();
  }

  pickMutation(id: string) {
    const m = this.mutationOffer.find((x) => x.id === id);
    if (!m || this.owned.has(id) || this.dna < m.cost) return;
    this.dna -= m.cost;
    this.owned.add(id);
    m.apply(this.stats);
    if (id === "capsid") this.hp = this.stats.maxHp;
    this.hp = Math.min(this.hp, this.stats.maxHp);
    this.advanceAfterMutation();
  }

  skipMutation() {
    this.advanceAfterMutation();
  }

  private advanceAfterMutation() {
    this.chapterIndex++;
    this.screen = "intro";
    this.pushUI();
  }

  // ── spawning helpers ──────────────────────────────────────────────────────

  private spawnDNA(x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU);
      const sp = n > 1 ? rand(40, 160) : 0;
      this.orbs.push({
        x: clamp(x, 60, this.worldW - 60), y: clamp(y, 60, this.worldH - 60),
        vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, seed: rand(0, 10),
      });
    }
  }

  private spawnEnemy() {
    const c = this.chapter;
    // spawn on a ring around the player, inside the arena
    for (let tries = 0; tries < 12; tries++) {
      const a = rand(0, TAU);
      const d = rand(430, 680);
      const x = this.px + Math.cos(a) * d;
      const y = this.py + Math.sin(a) * d;
      if (x < 80 || y < 80 || x > this.worldW - 80 || y > this.worldH - 80) continue;
      this.enemies.push({
        x, y, vx: 0, vy: 0, r: c.enemyBehavior === "blinker" ? 17 : 15,
        hp: c.enemyHp, maxHp: c.enemyHp, dmg: c.enemyDmg,
        behavior: c.enemyBehavior, state: "wander", stateT: 0,
        cd: rand(0.6, 2), aimX: 0, aimY: 0, angle: rand(0, TAU),
        flash: 0, seed: rand(0, 10), alpha: 1, shots: 0,
      });
      this.fx.ring(x, y, c.accent, 18);
      return;
    }
  }

  private spawnMine() {
    const a = rand(0, TAU);
    this.mines.push({
      x: rand(200, this.worldW - 200), y: rand(200, this.worldH - 200),
      vx: Math.cos(a) * 22, vy: Math.sin(a) * 22, r: 13,
      fuse: -1, armed: false, seed: rand(0, 10), dead: false,
    });
  }

  private spawnBoss() {
    const c = this.chapter;
    const a = angleTo(this.px, this.py, this.worldW / 2, this.worldH / 2);
    const bx = clamp(this.px + Math.cos(a) * 420, 200, this.worldW - 200);
    const by = clamp(this.py + Math.sin(a) * 420, 200, this.worldH - 200);
    this.boss = {
      x: bx, y: by, vx: 0, vy: 0,
      r: c.bossPattern === "macrophage" ? 62 : c.bossPattern === "matriarch" ? 55 : 58,
      hp: c.bossHp, maxHp: c.bossHp, dmg: c.bossDmg,
      pattern: c.bossPattern, state: "idle", stateT: 1.2, attackCd: 2,
      aimX: 0, aimY: 0, dirX: 0, dirY: 0, flash: 0, seed: rand(0, 10), spin: 0,
    };
    this.fx.shake(14, 0.5);
    this.fx.burst(bx, by, 40, c.accent, { speed: 300, size: 5 });
    this.fx.ring(bx, by, "#ffffff", 60);
    this.banner = { text: c.bossName, sub: "Survive. Strike. Infect.", t: 2.6 };
  }

  // ── damage ────────────────────────────────────────────────────────────────

  private damagePlayer(amount: number, sx: number, sy: number) {
    if (this.dying || this.invulnT > 0 || this.dashT > 0) return;
    this.hp -= amount;
    this.invulnT = 0.9;
    this.hurtT = 0.3;
    const a = angleTo(sx, sy, this.px, this.py);
    this.pvx += Math.cos(a) * 320;
    this.pvy += Math.sin(a) * 320;
    this.fx.shake(10, 0.3);
    this.fx.flash("rgba(255,40,40,0.22)", 0.14);
    this.fx.burst(this.px, this.py, 14, "#8aff5a", { speed: 230, size: 4 });
    this.fx.float(this.px, this.py - 24, `-${Math.round(amount)}`, "#ff6666", 17);
    if (this.hp <= 0) {
      this.hp = 0;
      this.dying = true;
      this.deathT = 1.4;
      this.fx.freeze(0.25);
      this.fx.shake(22, 0.7);
      this.fx.flash("rgba(255,255,255,0.5)", 0.2);
      this.fx.burst(this.px, this.py, 70, "#8aff5a", { speed: 420, size: 6, life: 1.1 });
      this.fx.burst(this.px, this.py, 30, "#ffffff", { speed: 300, size: 3, shape: "spark" });
      this.fx.ring(this.px, this.py, "#8aff5a", 50);
    }
  }

  private hurtEnemy(e: Enemy, dmg: number, ax: number, ay: number) {
    e.hp -= dmg;
    e.flash = 0.12;
    const a = angleTo(ax, ay, e.x, e.y);
    e.vx += Math.cos(a) * 130;
    e.vy += Math.sin(a) * 130;
    this.fx.burst(e.x, e.y, 5, "#ffe9a0", { speed: 160, size: 3 });
    this.fx.float(e.x, e.y - e.r - 6, `${Math.round(dmg)}`, "#ffd34d", 13);
    if (e.hp <= 0) this.killEnemy(e);
  }

  private killEnemy(e: Enemy) {
    const c = this.chapter;
    this.kills++;
    this.score += 100;
    this.hp = Math.min(this.stats.maxHp, this.hp + this.stats.lifeSteal);
    this.fx.freeze(0.03);
    this.fx.shake(6, 0.2);
    this.fx.burst(e.x, e.y, 22, c.accent, { speed: 260, size: 5 });
    this.fx.burst(e.x, e.y, 10, "#ffffff", { speed: 320, size: 3, shape: "spark" });
    this.fx.ring(e.x, e.y, c.accent, 24);
    this.fx.float(e.x, e.y - 20, "+100", "#ffffff", 14);
    this.spawnDNA(e.x, e.y, randInt(3, 5));
  }

  private hurtBoss(dmg: number, ax: number, ay: number) {
    const b = this.boss;
    if (!b || b.state === "dead") return;
    b.hp -= dmg;
    b.flash = 0.1;
    this.fx.burst(ax, ay, 4, "#ffe9a0", { speed: 140, size: 3 });
    this.fx.float(ax, ay - 14, `${Math.round(dmg)}`, "#ffd34d", 13);
    if (b.hp <= 0) {
      b.hp = 0;
      b.state = "dead";
      b.stateT = 1.2;
      this.fx.freeze(0.3);
      this.fx.shake(24, 0.9);
      this.fx.flash("rgba(255,255,255,0.6)", 0.25);
      this.fx.burst(b.x, b.y, 90, this.chapter.accent, { speed: 460, size: 7, life: 1.2 });
      this.fx.burst(b.x, b.y, 40, "#ffffff", { speed: 380, size: 4, shape: "spark" });
      this.fx.ring(b.x, b.y, "#ffffff", 80);
      this.score += 1000;
      this.fx.float(b.x, b.y - 40, "+1000", "#ffd34d", 24);
      this.spawnDNA(b.x, b.y, 16);
      this.bossDefeated = true;
      this.bullets = this.bullets.filter((bl) => bl.friendly);
      this.beams = []; this.rings = [];
      // host cell appears
      this.infectX = this.worldW / 2;
      this.infectY = this.worldH / 2;
      this.infectActive = true;
      this.infectProg = 0;
      this.banner = { text: "HOST CELL EXPOSED", sub: "Reach it and hold position to INFECT", t: 3 };
    }
  }

  private chapterComplete() {
    this.score += 500;
    this.fx.flash("rgba(138,255,90,0.35)", 0.3);
    this.fx.shake(10, 0.4);
    if (this.chapterIndex >= CHAPTERS.length - 1) {
      this.score += Math.max(0, 2500 - Math.floor(this.runTime) * 6);
      this.screen = "victory";
    } else {
      this.mutationOffer = offerMutations(this.owned);
      this.screen = "mutation";
    }
    this.pushUI();
  }

  // ── main loop ─────────────────────────────────────────────────────────────

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let dt = Math.min((now - this.lastT) / 1000, 0.035);
    this.lastT = now;
    this.time += dt;

    if (this.input.consumePause() && (this.screen === "playing" || this.screen === "paused")) {
      this.togglePause();
    }
    if (this.screen === "gameover" && this.input.keys.has("r")) {
      this.input.keys.delete("r");
      this.restart();
    }

    if (this.screen === "playing") {
      const simDt = this.fx.hitStop > 0 ? dt * 0.1 : dt;
      this.runTime += simDt;
      this.update(simDt);
    }
    this.fx.update(dt);
    this.banner.t = Math.max(0, this.banner.t - dt);
    this.render();
  };

  // ── update ────────────────────────────────────────────────────────────────

  private update(dt: number) {
    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateBoss(dt);
    this.updateHazards(dt);
    this.updateBullets(dt);
    this.updateOrbs(dt);
    this.updateWarnBeams(dt);
    this.updateInfection(dt);
    this.updateSpawning(dt);
    this.updateCamera(dt);
  }

  private getAim(): number {
    if (this.input.mouseUsed && !this.input.touchMode) {
      return Math.atan2(
        this.input.mouseY + this.camY - this.py,
        this.input.mouseX + this.camX - this.px
      );
    }
    // nearest target
    let best = -1; let bd = 720 * 720;
    for (let i = 0; i < this.enemies.length; i++) {
      const e = this.enemies[i];
      if (e.alpha < 0.5) continue;
      const d = (e.x - this.px) ** 2 + (e.y - this.py) ** 2;
      if (d < bd) { bd = d; best = i; }
    }
    if (this.boss && this.boss.state !== "dead") {
      const d = (this.boss.x - this.px) ** 2 + (this.boss.y - this.py) ** 2;
      if (d < bd) return angleTo(this.px, this.py, this.boss.x, this.boss.y);
    }
    if (best >= 0) return angleTo(this.px, this.py, this.enemies[best].x, this.enemies[best].y);
    return this.aimA;
  }

  private updatePlayer(dt: number) {
    if (this.dying) {
      this.deathT -= dt;
      if (this.deathT <= 0) {
        this.screen = "gameover";
        this.pushUI();
      }
      return;
    }
    const s = this.stats;
    const mv = this.input.getMove();
    const accel = 1400;
    this.pvx = damp(this.pvx, mv.x * s.speed, accel / s.speed, dt);
    this.pvy = damp(this.pvy, mv.y * s.speed, accel / s.speed, dt);

    // dash
    this.dashCdT = Math.max(0, this.dashCdT - dt);
    this.dashT = Math.max(0, this.dashT - dt);
    if (this.input.consumeDash() && this.dashCdT <= 0) {
      this.dashCdT = s.dashCd;
      this.dashT = s.dashInvuln;
      let dx = mv.x; let dy = mv.y;
      if (dx === 0 && dy === 0) { dx = Math.cos(this.aimA); dy = Math.sin(this.aimA); }
      const len = Math.hypot(dx, dy) || 1;
      this.pvx += (dx / len) * 720;
      this.pvy += (dy / len) * 720;
      this.fx.shake(5, 0.15);
      this.fx.burst(this.px, this.py, 14, "#aaffee", {
        speed: 200, size: 4, angle: Math.atan2(-dy, -dx), spread: 1.4,
      });
      this.fx.ring(this.px, this.py, "#8affda", 20);
    }

    this.px += this.pvx * dt;
    this.py += this.pvy * dt;
    this.px = clamp(this.px, this.pr + 24, this.worldW - this.pr - 24);
    this.py = clamp(this.py, this.pr + 24, this.worldH - this.pr - 24);

    this.aimA = this.getAim();
    this.invulnT = Math.max(0, this.invulnT - dt);
    this.hurtT = Math.max(0, this.hurtT - dt);
    this.blink -= dt;
    if (this.blink < -3) this.blink = rand(0.1, 0.18);

    // fire spikes
    this.fireCd -= dt;
    if (this.input.firing() && this.fireCd <= 0) {
      this.fireCd = s.spikeCd;
      const n = s.spikeCount;
      const spread = 0.1 + n * 0.055;
      for (let i = 0; i < n; i++) {
        const a = this.aimA + (n > 1 ? (i / (n - 1) - 0.5) * spread : 0) + rand(-0.02, 0.02);
        this.bullets.push({
          x: this.px + Math.cos(a) * (this.pr + 6),
          y: this.py + Math.sin(a) * (this.pr + 6),
          vx: Math.cos(a) * 560, vy: Math.sin(a) * 560,
          r: 5, dmg: s.spikeDmg, life: 1.05, color: "#9dff5e", friendly: true,
        });
      }
      this.pvx -= Math.cos(this.aimA) * 48;
      this.pvy -= Math.sin(this.aimA) * 48;
      this.fx.shake(2, 0.08);
      this.fx.burst(
        this.px + Math.cos(this.aimA) * (this.pr + 8),
        this.py + Math.sin(this.aimA) * (this.pr + 8),
        4, "#d6ffb0", { speed: 160, size: 2.5, angle: this.aimA, spread: 0.8 }
      );
    }

    // dash contact damage
    if (this.dashT > 0) {
      for (const e of this.enemies) {
        if (e.alpha < 0.5) continue;
        if (dist(e.x, e.y, this.px, this.py) < e.r + this.pr + 4) {
          this.hurtEnemy(e, 26, this.px, this.py);
        }
      }
      if (this.boss && this.boss.state !== "dead") {
        const b = this.boss;
        if (dist(b.x, b.y, this.px, this.py) < b.r + this.pr) this.hurtBoss(14, this.px, this.py);
      }
    }
  }

  // ── enemies ───────────────────────────────────────────────────────────────

  private updateEnemies(dt: number) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.hp <= 0) { this.enemies.splice(i, 1); continue; }
      e.flash = Math.max(0, e.flash - dt);
      e.stateT -= dt;
      e.cd -= dt;
      switch (e.behavior) {
        case "lunger": this.updateLunger(e, dt); break;
        case "shooter": this.updateShooter(e, dt); break;
        case "blinker": this.updateBlinker(e, dt); break;
      }
      // separation
      for (let j = i + 1; j < this.enemies.length; j++) {
        const o = this.enemies[j];
        const d = dist(e.x, e.y, o.x, o.y);
        const min = e.r + o.r;
        if (d < min && d > 0.01) {
          const push = ((min - d) / d) * 0.5;
          const dx = (e.x - o.x) * push; const dy = (e.y - o.y) * push;
          e.x += dx; e.y += dy; o.x -= dx; o.y -= dy;
        }
      }
      e.x = clamp(e.x, e.r, this.worldW - e.r);
      e.y = clamp(e.y, e.r, this.worldH - e.r);
      // contact damage (visible enemies only)
      if (e.alpha > 0.6 && dist(e.x, e.y, this.px, this.py) < e.r + this.pr - 2) {
        this.damagePlayer(e.dmg, e.x, e.y);
      }
    }
  }

  private updateLunger(e: Enemy, dt: number) {
    const dp = dist(e.x, e.y, this.px, this.py);
    if (e.state === "wander") {
      e.angle += rand(-1.6, 1.6) * dt;
      const toward = angleTo(e.x, e.y, this.px, this.py);
      const a = dp > 300 ? toward : lerp(e.angle, toward, 0.35);
      e.vx = damp(e.vx, Math.cos(a) * this.chapter.enemySpeed, 4, dt);
      e.vy = damp(e.vy, Math.sin(a) * this.chapter.enemySpeed, 4, dt);
      if (dp < 250 && e.cd <= 0) {
        e.state = "telegraph"; e.stateT = 0.55;
        this.warnings.push({
          kind: "circle", x: e.x, y: e.y, x2: 0, y2: 0, r: e.r + 14,
          t: 0.55, dur: 0.55, color: "#ff4455", width: 3,
        });
      }
    } else if (e.state === "telegraph") {
      e.vx = damp(e.vx, 0, 6, dt);
      e.vy = damp(e.vy, 0, 6, dt);
      if (e.stateT <= 0) {
        const a = angleTo(e.x, e.y, this.px, this.py);
        e.vx = Math.cos(a) * 540; e.vy = Math.sin(a) * 540;
        e.state = "attack"; e.stateT = 0.42;
        this.fx.burst(e.x, e.y, 6, "#ffccaa", { speed: 120, size: 3, angle: a + Math.PI, spread: 1 });
      }
    } else if (e.state === "attack") {
      e.vx *= Math.exp(-1.6 * dt);
      e.vy *= Math.exp(-1.6 * dt);
      if (e.stateT <= 0) { e.state = "recover"; e.stateT = 0.7; e.cd = 1.7; }
    } else {
      e.vx = damp(e.vx, 0, 5, dt);
      e.vy = damp(e.vy, 0, 5, dt);
      if (e.stateT <= 0) e.state = "wander";
    }
    e.x += e.vx * dt; e.y += e.vy * dt;
  }

  private updateShooter(e: Enemy, dt: number) {
    const dp = dist(e.x, e.y, this.px, this.py);
    const toward = angleTo(e.x, e.y, this.px, this.py);
    if (e.state === "wander") {
      // maintain mid range, strafe
      let a = toward;
      if (dp < 240) a = toward + Math.PI;
      else if (dp < 360) a = toward + Math.PI / 2 * (e.seed > 5 ? 1 : -1);
      e.vx = damp(e.vx, Math.cos(a) * this.chapter.enemySpeed, 3.5, dt);
      e.vy = damp(e.vy, Math.sin(a) * this.chapter.enemySpeed, 3.5, dt);
      if (dp < 480 && e.cd <= 0) {
        e.state = "telegraph"; e.stateT = 0.65; e.shots = 0;
      }
    } else if (e.state === "telegraph") {
      e.vx = damp(e.vx, 0, 6, dt);
      e.vy = damp(e.vy, 0, 6, dt);
      // aim locks in the final 0.3s
      if (e.stateT > 0.3) { e.aimX = this.px; e.aimY = this.py; }
      if (e.stateT <= 0) { e.state = "attack"; e.stateT = 0; }
    } else if (e.state === "attack") {
      if (e.stateT <= 0 && e.shots < 3) {
        const a = angleTo(e.x, e.y, e.aimX, e.aimY) + rand(-0.06, 0.06);
        this.bullets.push({
          x: e.x + Math.cos(a) * (e.r + 4), y: e.y + Math.sin(a) * (e.r + 4),
          vx: Math.cos(a) * 310, vy: Math.sin(a) * 310,
          r: 6, dmg: e.dmg, life: 2.6, color: "#d08aff", friendly: false,
        });
        e.shots++;
        e.stateT = 0.13;
        this.fx.burst(e.x, e.y, 3, "#d08aff", { speed: 90, size: 2.5 });
      }
      if (e.shots >= 3) { e.state = "recover"; e.stateT = 0.6; e.cd = rand(2.1, 2.9); }
    } else {
      e.vx = damp(e.vx, 0, 4, dt);
      e.vy = damp(e.vy, 0, 4, dt);
      if (e.stateT <= 0) e.state = "wander";
    }
    e.angle = toward;
    e.x += e.vx * dt; e.y += e.vy * dt;
  }

  private updateBlinker(e: Enemy, dt: number) {
    const dp = dist(e.x, e.y, this.px, this.py);
    if (e.state === "wander") {
      e.alpha = Math.min(1, e.alpha + dt * 4);
      const toward = angleTo(e.x, e.y, this.px, this.py);
      const a = toward + Math.sin(this.time * 2 + e.seed) * 0.7;
      e.vx = damp(e.vx, Math.cos(a) * this.chapter.enemySpeed, 3.5, dt);
      e.vy = damp(e.vy, Math.sin(a) * this.chapter.enemySpeed, 3.5, dt);
      e.x += e.vx * dt; e.y += e.vy * dt;
      if (dp < 420 && e.cd <= 0) {
        e.state = "fadeout"; e.stateT = 0.35;
        this.fx.burst(e.x, e.y, 8, "#cc66ff", { speed: 120, size: 3 });
      }
    } else if (e.state === "fadeout") {
      e.alpha = Math.max(0, e.alpha - dt * 3.2);
      if (e.stateT <= 0) {
        // teleport next to the player, show warning at destination
        const a = rand(0, TAU);
        e.x = clamp(this.px + Math.cos(a) * 110, 60, this.worldW - 60);
        e.y = clamp(this.py + Math.sin(a) * 110, 60, this.worldH - 60);
        e.state = "warn"; e.stateT = 0.6; e.alpha = 0;
        this.warnings.push({
          kind: "circle", x: e.x, y: e.y, x2: 0, y2: 0, r: 80,
          t: 0.6, dur: 0.6, color: "#ff44aa", width: 3,
        });
      }
    } else if (e.state === "warn") {
      if (e.stateT <= 0) {
        e.state = "slash"; e.stateT = 0.22; e.alpha = 1;
        this.fx.burst(e.x, e.y, 16, "#ff66cc", { speed: 260, size: 4 });
        this.fx.ring(e.x, e.y, "#ff66cc", 36);
        this.fx.shake(4, 0.15);
        if (dist(e.x, e.y, this.px, this.py) < 80 + this.pr) {
          this.damagePlayer(e.dmg, e.x, e.y);
        }
      }
    } else if (e.state === "slash") {
      if (e.stateT <= 0) { e.state = "recover"; e.stateT = 0.9; e.cd = rand(2.6, 3.4); }
    } else {
      e.alpha = 1;
      e.vx = damp(e.vx, 0, 4, dt);
      e.vy = damp(e.vy, 0, 4, dt);
      e.x += e.vx * dt; e.y += e.vy * dt;
      if (e.stateT <= 0) e.state = "wander";
    }
  }

  // ── boss patterns ─────────────────────────────────────────────────────────

  private updateBoss(dt: number) {
    // boss intro warning timer
    if (this.bossWarnT > 0) {
      this.bossWarnT -= dt;
      if (this.bossWarnT <= 0) this.spawnBoss();
    }
    const b = this.boss;
    if (!b) return;
    b.flash = Math.max(0, b.flash - dt);
    b.stateT -= dt;
    b.spin += dt;
    if (b.state === "dead") {
      if (b.stateT <= 0) this.boss = null;
      return;
    }
    switch (b.pattern) {
      case "macrophage": this.bossMacrophage(b, dt); break;
      case "matriarch": this.bossMatriarch(b, dt); break;
      case "overmind": this.bossOvermind(b, dt); break;
    }
    b.x = clamp(b.x, b.r, this.worldW - b.r);
    b.y = clamp(b.y, b.r, this.worldH - b.r);
    // contact damage
    if (dist(b.x, b.y, this.px, this.py) < b.r + this.pr - 4) {
      this.damagePlayer(b.dmg, b.x, b.y);
    }
  }

  private bossMacrophage(b: Boss, dt: number) {
    const enraged = b.hp < b.maxHp * 0.45;
    if (b.state === "idle") {
      const a = angleTo(b.x, b.y, this.px, this.py);
      const sp = enraged ? 85 : 62;
      b.vx = damp(b.vx, Math.cos(a) * sp, 2.5, dt);
      b.vy = damp(b.vy, Math.sin(a) * sp, 2.5, dt);
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.stateT <= 0) {
        const roll = Math.random();
        if (roll < 0.42) {
          // telegraphed charge
          b.state = "chargeWarn"; b.stateT = 0.8;
          b.aimX = this.px; b.aimY = this.py;
          const a2 = angleTo(b.x, b.y, this.px, this.py);
          this.warnings.push({
            kind: "line", x: b.x, y: b.y,
            x2: b.x + Math.cos(a2) * 620, y2: b.y + Math.sin(a2) * 620,
            r: 0, t: 0.8, dur: 0.8, color: "#ff5544", width: 54,
          });
        } else if (roll < 0.78) {
          // engulf slam at the player's position
          b.state = "slamWarn"; b.stateT = 0.95;
          b.aimX = this.px; b.aimY = this.py;
          this.warnings.push({
            kind: "circle", x: this.px, y: this.py, x2: 0, y2: 0, r: 120,
            t: 0.95, dur: 0.95, color: "#ff5544", width: 4,
          });
        } else if (this.enemies.length < 3) {
          b.state = "summon"; b.stateT = 0.6;
        } else {
          b.stateT = 0.8;
        }
      }
    } else if (b.state === "chargeWarn") {
      b.vx = damp(b.vx, 0, 4, dt); b.vy = damp(b.vy, 0, 4, dt);
      if (b.stateT <= 0) {
        const a = angleTo(b.x, b.y, b.aimX, b.aimY);
        b.dirX = Math.cos(a); b.dirY = Math.sin(a);
        b.state = "charge"; b.stateT = 0.55;
        this.fx.shake(8, 0.3);
      }
    } else if (b.state === "charge") {
      b.x += b.dirX * 760 * dt;
      b.y += b.dirY * 760 * dt;
      if (Math.random() < 0.6) {
        this.fx.burst(b.x - b.dirX * b.r, b.y - b.dirY * b.r, 2, "#e8c9a0", { speed: 90, size: 4 });
      }
      if (b.stateT <= 0 || b.x < b.r + 8 || b.x > this.worldW - b.r - 8 || b.y < b.r + 8 || b.y > this.worldH - b.r - 8) {
        b.state = "idle"; b.stateT = enraged ? 1.6 : 2.4;
        this.fx.shake(10, 0.3);
        this.fx.burst(b.x, b.y, 16, "#e8c9a0", { speed: 220, size: 5 });
      }
    } else if (b.state === "slamWarn") {
      const a = angleTo(b.x, b.y, b.aimX, b.aimY);
      b.x += Math.cos(a) * 130 * dt;
      b.y += Math.sin(a) * 130 * dt;
      if (b.stateT <= 0) {
        // slam!
        this.fx.shake(14, 0.4);
        this.fx.burst(b.aimX, b.aimY, 34, "#ffaa77", { speed: 330, size: 5 });
        this.fx.ring(b.aimX, b.aimY, "#ff7755", 60);
        if (dist(this.px, this.py, b.aimX, b.aimY) < 120 + this.pr) {
          this.damagePlayer(b.dmg + 6, b.aimX, b.aimY);
        }
        b.state = "idle"; b.stateT = enraged ? 1.4 : 2.2;
      }
    } else if (b.state === "summon") {
      if (b.stateT <= 0) {
        for (let i = 0; i < 2; i++) this.spawnEnemy();
        this.fx.burst(b.x, b.y, 18, "#ffffff", { speed: 240, size: 4 });
        b.state = "idle"; b.stateT = 2.6;
      }
    }
  }

  private bossMatriarch(b: Boss, dt: number) {
    const enraged = b.hp < b.maxHp * 0.5;
    // slow drift toward mid-range of player
    const dp = dist(b.x, b.y, this.px, this.py);
    const a = angleTo(b.x, b.y, this.px, this.py);
    const want = dp > 340 ? 55 : dp < 220 ? -45 : 0;
    b.vx = damp(b.vx, Math.cos(a) * want, 2, dt);
    b.vy = damp(b.vy, Math.sin(a) * want, 2, dt);
    b.x += b.vx * dt; b.y += b.vy * dt;

    if (b.state === "idle") {
      if (b.stateT <= 0) {
        const roll = Math.random();
        if (roll < 0.45) {
          b.state = "ringWarn"; b.stateT = 0.7;
          this.warnings.push({
            kind: "circle", x: b.x, y: b.y, x2: 0, y2: 0, r: b.r + 30,
            t: 0.7, dur: 0.7, color: "#cc66ff", width: 4,
          });
        } else if (roll < 0.8) {
          b.state = "volleyWarn"; b.stateT = 0.6;
          b.aimX = this.px; b.aimY = this.py;
          const a2 = angleTo(b.x, b.y, this.px, this.py);
          this.warnings.push({
            kind: "line", x: b.x, y: b.y,
            x2: b.x + Math.cos(a2) * 520, y2: b.y + Math.sin(a2) * 520,
            r: 0, t: 0.6, dur: 0.6, color: "#cc66ff", width: 30,
          });
        } else if (this.mines.length < 7) {
          // drop a mine near the player
          this.mines.push({
            x: clamp(this.px + rand(-140, 140), 100, this.worldW - 100),
            y: clamp(this.py + rand(-140, 140), 100, this.worldH - 100),
            vx: 0, vy: 0, r: 13, fuse: -1, armed: false, seed: rand(0, 10), dead: false,
          });
          this.fx.ring(b.x, b.y, "#cc66ff", 30);
          b.stateT = 1.6;
        } else {
          b.stateT = 1.2;
        }
      }
    } else if (b.state === "ringWarn") {
      if (b.stateT <= 0) {
        const n = enraged ? 18 : 13;
        const off = rand(0, TAU);
        for (let i = 0; i < n; i++) {
          const ba = off + (i / n) * TAU;
          this.bullets.push({
            x: b.x + Math.cos(ba) * (b.r + 6), y: b.y + Math.sin(ba) * (b.r + 6),
            vx: Math.cos(ba) * 230, vy: Math.sin(ba) * 230,
            r: 6, dmg: b.dmg, life: 3, color: "#e09aff", friendly: false,
          });
        }
        this.fx.shake(6, 0.2);
        this.fx.ring(b.x, b.y, "#e09aff", b.r);
        b.state = "idle"; b.stateT = enraged ? 1.2 : 1.9;
      }
    } else if (b.state === "volleyWarn") {
      if (b.stateT > 0.25) { b.aimX = this.px; b.aimY = this.py; }
      if (b.stateT <= 0) {
        const aim = angleTo(b.x, b.y, b.aimX, b.aimY);
        for (let i = 0; i < 5; i++) {
          const ba = aim + (i - 2) * 0.14;
          this.bullets.push({
            x: b.x + Math.cos(ba) * (b.r + 6), y: b.y + Math.sin(ba) * (b.r + 6),
            vx: Math.cos(ba) * 330, vy: Math.sin(ba) * 330,
            r: 6, dmg: b.dmg, life: 2.6, color: "#e09aff", friendly: false,
          });
        }
        this.fx.shake(5, 0.2);
        b.state = "idle"; b.stateT = enraged ? 1.0 : 1.7;
      }
    }
  }

  private bossOvermind(b: Boss, dt: number) {
    const enraged = b.hp < b.maxHp * 0.5;
    if (b.state === "idle") {
      // hover with slight orbit around arena center
      const ca = angleTo(this.worldW / 2, this.worldH / 2, b.x, b.y) + 0.35;
      const tx = this.worldW / 2 + Math.cos(ca) * 330;
      const ty = this.worldH / 2 + Math.sin(ca) * 260;
      b.vx = damp(b.vx, (tx - b.x) * 0.5, 1.6, dt);
      b.vy = damp(b.vy, (ty - b.y) * 0.5, 1.6, dt);
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.stateT <= 0) {
        const roll = Math.random();
        if (roll < 0.4) {
          // cross laser through the player
          b.state = "laserWarn"; b.stateT = 1.0;
          const a1 = angleTo(b.x, b.y, this.px, this.py);
          const angles = enraged ? [a1, a1 + 0.5, a1 - 0.5] : [a1, a1 + 0.55];
          for (const la of angles) {
            this.warnings.push({
              kind: "line", x: b.x, y: b.y,
              x2: b.x + Math.cos(la) * 900, y2: b.y + Math.sin(la) * 900,
              r: la, t: 1.0, dur: 1.0, color: "#33e0ff", width: 26,
            });
          }
        } else if (roll < 0.72) {
          b.state = "pulseWarn"; b.stateT = 0.6;
          this.warnings.push({
            kind: "circle", x: b.x, y: b.y, x2: 0, y2: 0, r: b.r + 24,
            t: 0.6, dur: 0.6, color: "#33e0ff", width: 4,
          });
        } else {
          // blink to the player's flank + spark burst
          b.state = "blink"; b.stateT = 0.45;
          this.fx.burst(b.x, b.y, 20, "#66eaff", { speed: 240, size: 4 });
        }
      }
    } else if (b.state === "laserWarn") {
      b.vx = damp(b.vx, 0, 4, dt); b.vy = damp(b.vy, 0, 4, dt);
      if (b.stateT <= 0) {
        // fire beams along the warned directions
        for (const w of this.warnings) {
          if (w.kind === "line" && w.width === 26) {
            this.beams.push({
              x: b.x, y: b.y,
              x2: b.x + Math.cos(w.r) * 900, y2: b.y + Math.sin(w.r) * 900,
              t: 0.55, dur: 0.55, width: 24, dmg: b.dmg, color: "#66eaff",
            });
          }
        }
        this.fx.shake(10, 0.35);
        b.state = "idle"; b.stateT = enraged ? 1.5 : 2.3;
      }
    } else if (b.state === "pulseWarn") {
      if (b.stateT <= 0) {
        this.rings.push({ x: b.x, y: b.y, r: b.r + 10, speed: 300, maxR: 560, dmg: b.dmg, hit: false });
        if (enraged) {
          this.rings.push({ x: b.x, y: b.y, r: b.r - 20, speed: 240, maxR: 560, dmg: b.dmg, hit: false });
        }
        this.fx.shake(7, 0.25);
        this.fx.ring(b.x, b.y, "#66eaff", b.r + 10);
        b.state = "idle"; b.stateT = enraged ? 1.3 : 2.0;
      }
    } else if (b.state === "blink") {
      if (b.stateT <= 0) {
        const a = rand(0, TAU);
        b.x = clamp(this.px + Math.cos(a) * 260, b.r + 40, this.worldW - b.r - 40);
        b.y = clamp(this.py + Math.sin(a) * 260, b.r + 40, this.worldH - b.r - 40);
        this.fx.burst(b.x, b.y, 24, "#66eaff", { speed: 280, size: 4 });
        this.fx.ring(b.x, b.y, "#66eaff", 40);
        b.state = "idle"; b.stateT = 1.2;
      }
    }
  }

  // ── hazards ───────────────────────────────────────────────────────────────

  private updateHazards(dt: number) {
    const kind = this.chapter.hazardKind;
    if (kind === "current") this.updateCurrent(dt);
    else if (kind === "mines") this.updateMines(dt);
    else this.updateStorm(dt);

    // expanding pulse rings (overmind)
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const ring = this.rings[i];
      ring.r += ring.speed * dt;
      if (!ring.hit) {
        const d = dist(ring.x, ring.y, this.px, this.py);
        if (Math.abs(d - ring.r) < 14 + this.pr && this.dashT <= 0) {
          ring.hit = true;
          this.damagePlayer(ring.dmg, ring.x, ring.y);
        }
      }
      if (ring.r > ring.maxR) this.rings.splice(i, 1);
    }
  }

  private updateCurrent(dt: number) {
    this.currentT -= dt;
    if (this.currentPhase === "idle" && this.currentT <= 0) {
      this.currentPhase = "warn";
      this.currentT = 1.3;
      this.currentA = rand(0, TAU);
    } else if (this.currentPhase === "warn" && this.currentT <= 0) {
      this.currentPhase = "active";
      this.currentT = 2.2;
      this.fx.shake(4, 0.3);
    } else if (this.currentPhase === "active") {
      const fx2 = Math.cos(this.currentA) * 240;
      const fy2 = Math.sin(this.currentA) * 240;
      this.pvx += fx2 * dt * 1.25;
      this.pvy += fy2 * dt * 1.25;
      for (const e of this.enemies) { e.x += fx2 * dt * 0.5; e.y += fy2 * dt * 0.5; }
      if (Math.random() < 0.5) {
        this.fx.burst(
          this.camX + rand(0, this.viewW), this.camY + rand(0, this.viewH),
          1, "rgba(255,130,150,0.7)",
          { speed: 300, size: 2.5, angle: this.currentA, spread: 0.1, shape: "spark" }
        );
      }
      if (this.currentT <= 0) {
        this.currentPhase = "idle";
        this.currentT = rand(5.5, 8);
      }
    }
  }

  private updateMines(dt: number) {
    this.mineRespawnT -= dt;
    if (this.mines.filter((m) => !m.dead).length < 6 && this.mineRespawnT <= 0) {
      this.spawnMine();
      this.mineRespawnT = 4;
    }
    for (let i = this.mines.length - 1; i >= 0; i--) {
      const m = this.mines[i];
      if (m.dead) { this.mines.splice(i, 1); continue; }
      m.x += m.vx * dt; m.y += m.vy * dt;
      if (m.x < 100 || m.x > this.worldW - 100) m.vx *= -1;
      if (m.y < 100 || m.y > this.worldH - 100) m.vy *= -1;
      const dp = dist(m.x, m.y, this.px, this.py);
      if (!m.armed && dp < 120) {
        m.armed = true;
        m.fuse = 0.95;
        this.warnings.push({
          kind: "circle", x: m.x, y: m.y, x2: 0, y2: 0, r: 120,
          t: 0.95, dur: 0.95, color: "#ffaa33", width: 3,
        });
      }
      if (m.armed) {
        m.fuse -= dt;
        if (m.fuse <= 0) this.explodeMine(m);
      }
    }
  }

  private explodeMine(m: Mine) {
    m.dead = true;
    this.fx.shake(11, 0.35);
    this.fx.burst(m.x, m.y, 30, "#ffbb55", { speed: 340, size: 5 });
    this.fx.burst(m.x, m.y, 12, "#ffffff", { speed: 280, size: 3, shape: "spark" });
    this.fx.ring(m.x, m.y, "#ffaa33", 55);
    if (dist(m.x, m.y, this.px, this.py) < 120 + this.pr) {
      this.damagePlayer(18, m.x, m.y);
    }
    for (const e of this.enemies) {
      if (dist(m.x, m.y, e.x, e.y) < 130) this.hurtEnemy(e, 40, m.x, m.y);
    }
    if (this.boss && this.boss.state !== "dead" && dist(m.x, m.y, this.boss.x, this.boss.y) < 130 + this.boss.r) {
      this.hurtBoss(25, m.x, m.y);
    }
  }

  private updateStorm(dt: number) {
    this.stormT -= dt;
    if (this.stormT <= 0) {
      this.stormT = rand(4.2, 5.5);
      const mk = (x: number, y: number) => {
        const z: StormZone = {
          x: clamp(x, 120, this.worldW - 120), y: clamp(y, 120, this.worldH - 120),
          r: 95, t: 1.1, zapT: 0,
        };
        this.stormZones.push(z);
        this.warnings.push({
          kind: "circle", x: z.x, y: z.y, x2: 0, y2: 0, r: z.r,
          t: 1.1, dur: 1.1, color: "#55eeff", width: 3,
        });
      };
      mk(this.px + rand(-40, 40), this.py + rand(-40, 40));
      mk(this.px + rand(-350, 350), this.py + rand(-350, 350));
      mk(this.px + rand(-350, 350), this.py + rand(-350, 350));
    }
    for (let i = this.stormZones.length - 1; i >= 0; i--) {
      const z = this.stormZones[i];
      if (z.t > 0) {
        z.t -= dt;
        if (z.t <= 0) {
          z.zapT = 0.3;
          this.fx.shake(6, 0.2);
          this.fx.burst(z.x, z.y, 16, "#aef7ff", { speed: 280, size: 3, shape: "spark" });
          if (dist(z.x, z.y, this.px, this.py) < z.r + this.pr * 0.5) {
            this.damagePlayer(16, z.x, z.y);
          }
        }
      } else {
        z.zapT -= dt;
        if (z.zapT <= 0) this.stormZones.splice(i, 1);
      }
    }
  }

  // ── bullets / orbs / warnings ─────────────────────────────────────────────

  private updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const bl = this.bullets[i];
      bl.life -= dt;
      bl.x += bl.vx * dt;
      bl.y += bl.vy * dt;
      let dead = bl.life <= 0 || bl.x < 10 || bl.y < 10 || bl.x > this.worldW - 10 || bl.y > this.worldH - 10;
      if (!dead) {
        if (bl.friendly) {
          for (const e of this.enemies) {
            if (e.alpha < 0.5) continue;
            if (dist(bl.x, bl.y, e.x, e.y) < bl.r + e.r) {
              this.hurtEnemy(e, bl.dmg, bl.x, bl.y);
              dead = true;
              break;
            }
          }
          if (!dead && this.boss && this.boss.state !== "dead") {
            const b = this.boss;
            if (dist(bl.x, bl.y, b.x, b.y) < bl.r + b.r) {
              this.hurtBoss(bl.dmg, bl.x, bl.y);
              dead = true;
            }
          }
          if (!dead) {
            for (const m of this.mines) {
              if (!m.dead && dist(bl.x, bl.y, m.x, m.y) < bl.r + m.r) {
                this.explodeMine(m);
                dead = true;
                break;
              }
            }
          }
        } else if (!this.dying && dist(bl.x, bl.y, this.px, this.py) < bl.r + this.pr - 2) {
          this.damagePlayer(bl.dmg, bl.x, bl.y);
          dead = true;
        }
      }
      if (dead) {
        this.fx.burst(bl.x, bl.y, 3, bl.color, { speed: 90, size: 2 });
        this.bullets.splice(i, 1);
      }
    }
  }

  private updateOrbs(dt: number) {
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      o.vx *= Math.exp(-3 * dt);
      o.vy *= Math.exp(-3 * dt);
      const d = dist(o.x, o.y, this.px, this.py);
      if (d < this.stats.magnet && !this.dying) {
        const a = angleTo(o.x, o.y, this.px, this.py);
        const pull = 900 * (1 - d / this.stats.magnet) + 120;
        o.vx += Math.cos(a) * pull * dt * 4;
        o.vy += Math.sin(a) * pull * dt * 4;
      }
      o.x += o.vx * dt;
      o.y += o.vy * dt;
      if (d < this.pr + 12 && !this.dying) {
        this.orbs.splice(i, 1);
        this.dna++;
        this.score += 10;
        this.fx.burst(o.x, o.y, 5, "#7dff8a", { speed: 120, size: 2.5 });
        this.fx.float(this.px, this.py - this.pr - 12, "+1 DNA", "#7dff8a", 12);
      }
    }
  }

  private updateWarnBeams(dt: number) {
    for (let i = this.warnings.length - 1; i >= 0; i--) {
      this.warnings[i].t -= dt;
      if (this.warnings[i].t <= 0) this.warnings.splice(i, 1);
    }
    for (let i = this.beams.length - 1; i >= 0; i--) {
      const bm = this.beams[i];
      bm.t -= dt;
      if (bm.t > 0 && !this.dying && this.dashT <= 0) {
        if (pointSegDist(this.px, this.py, bm.x, bm.y, bm.x2, bm.y2) < bm.width / 2 + this.pr - 3) {
          this.damagePlayer(bm.dmg, bm.x, bm.y);
        }
      }
      if (bm.t <= 0) this.beams.splice(i, 1);
    }
  }

  private updateInfection(dt: number) {
    if (!this.infectActive || this.dying) return;
    const d = dist(this.px, this.py, this.infectX, this.infectY);
    if (d < 95) {
      this.infectProg = Math.min(1, this.infectProg + dt / 2.6);
      this.infectHold += dt;
      if (Math.random() < 0.3) {
        const a = rand(0, TAU);
        this.fx.burst(
          this.infectX + Math.cos(a) * 60, this.infectY + Math.sin(a) * 60,
          1, "#8aff5a", { speed: 60, size: 3 }
        );
      }
      if (this.infectProg >= 1) {
        this.infectActive = false;
        this.fx.burst(this.infectX, this.infectY, 60, "#8aff5a", { speed: 380, size: 6, life: 1 });
        this.fx.ring(this.infectX, this.infectY, "#8aff5a", 80);
        this.fx.shake(14, 0.5);
        this.fx.float(this.infectX, this.infectY - 60, "+500 INFECTED!", "#8aff5a", 22);
        this.chapterComplete();
      }
    } else {
      this.infectProg = Math.max(0, this.infectProg - dt * 0.25);
    }
  }

  private updateSpawning(dt: number) {
    const c = this.chapter;
    const quotaMet = this.kills >= c.killQuota;
    if (quotaMet && !this.bossSpawned) {
      this.bossSpawned = true;
      this.bossWarnT = 1.6;
      this.banner = { text: "⚠ IMMUNE RESPONSE DETECTED ⚠", sub: `${c.bossName} is coming…`, t: 1.8 };
      this.fx.shake(8, 0.4);
      this.fx.flash("rgba(255,60,60,0.18)", 0.3);
    }
    const cap = quotaMet ? (this.bossDefeated ? 0 : 2) : c.maxEnemies;
    this.spawnT -= dt;
    if (this.enemies.length < cap && this.spawnT <= 0) {
      this.spawnEnemy();
      this.spawnT = c.spawnInterval;
    }
  }

  private updateCamera(dt: number) {
    const lead = 70;
    const tx = this.px + Math.cos(this.aimA) * lead * 0.4 + this.pvx * 0.14 - this.viewW / 2;
    const ty = this.py + Math.sin(this.aimA) * lead * 0.4 + this.pvy * 0.14 - this.viewH / 2;
    this.camX = damp(this.camX, tx, 5, dt);
    this.camY = damp(this.camY, ty, 5, dt);
    this.camX = clamp(this.camX, -40, this.worldW - this.viewW + 40);
    this.camY = clamp(this.camY, -40, this.worldH - this.viewH + 40);
    if (this.worldW < this.viewW) this.camX = (this.worldW - this.viewW) / 2;
    if (this.worldH < this.viewH) this.camY = (this.worldH - this.viewH) / 2;
  }

  // ── render ────────────────────────────────────────────────────────────────

  private render() {
    const ctx = this.ctx;
    const c = this.chapter;
    const W = this.viewW;
    const H = this.viewH;

    // background gradient
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, c.bgTop);
    g.addColorStop(1, c.bgBottom);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    const shake = this.fx.getShakeOffset(this.time);
    ctx.save();
    ctx.translate(-this.camX + shake.x, -this.camY + shake.y);

    this.drawBackground(ctx);
    this.drawArena(ctx);
    this.drawHazards(ctx);
    this.drawWarnings(ctx);
    this.drawInfectionCell(ctx);
    this.drawOrbs(ctx);
    for (const e of this.enemies) this.drawEnemy(ctx, e);
    if (this.boss && this.boss.state !== "dead") this.drawBoss(ctx, this.boss);
    this.drawBullets(ctx);
    this.drawBeamsRings(ctx);
    if (!this.dying) this.drawPlayer(ctx);
    this.fx.drawWorld(ctx);
    ctx.restore();

    // screen-space effects + HUD
    if (this.fx.flashT > 0) {
      ctx.globalAlpha = Math.min(1, this.fx.flashT * 6);
      ctx.fillStyle = this.fx.flashColor;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }
    if (this.vignette) ctx.drawImage(this.vignette, 0, 0, W, H);

    if (this.screen === "playing" || this.screen === "paused") {
      this.drawHUD(ctx);
    }
    if (this.screen === "menu") this.drawMenuBackdrop(ctx);
  }

  private drawBackground(ctx: CanvasRenderingContext2D) {
    // parallax blobs (ambient cells)
    for (const b of this.blobs) {
      const px = b.x + (this.camX + this.viewW / 2 - this.worldW / 2) * (1 - b.par) * 0.4;
      const py = b.y + (this.camY + this.viewH / 2 - this.worldH / 2) * (1 - b.par) * 0.4;
      if (px + b.r < this.camX || px - b.r > this.camX + this.viewW) continue;
      if (py + b.r < this.camY || py - b.r > this.camY + this.viewH) continue;
      const wob = 1 + Math.sin(this.time * 0.8 + b.seed) * 0.04;
      ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.ellipse(px, py, b.r * wob, b.r * (2 - wob) * 0.9, b.seed, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(0,0,0,0.12)";
      ctx.beginPath();
      ctx.arc(px + b.r * 0.15, py + b.r * 0.1, b.r * 0.38, 0, TAU);
      ctx.fill();
    }
    // drifting motes
    ctx.fillStyle = "rgba(255,255,255,0.16)";
    for (const m of this.motes) {
      const mx = (m.x + this.time * 9 * m.s) % this.worldW;
      const my = (m.y + Math.sin(this.time * 0.6 + m.x) * 20 + this.worldH) % this.worldH;
      if (mx < this.camX - 10 || mx > this.camX + this.viewW + 10) continue;
      if (my < this.camY - 10 || my > this.camY + this.viewH + 10) continue;
      ctx.beginPath();
      ctx.arc(mx, my, m.s, 0, TAU);
      ctx.fill();
    }
  }

  private drawArena(ctx: CanvasRenderingContext2D) {
    const c = this.chapter;
    // membrane walls
    ctx.strokeStyle = c.membrane;
    ctx.globalAlpha = 0.5;
    ctx.lineWidth = 6;
    const wob = Math.sin(this.time * 2) * 2;
    ctx.strokeRect(14 - wob, 14 - wob, this.worldW - 28 + wob * 2, this.worldH - 28 + wob * 2);
    ctx.globalAlpha = 0.16;
    ctx.lineWidth = 22;
    ctx.strokeRect(14, 14, this.worldW - 28, this.worldH - 28);
    ctx.globalAlpha = 1;
  }

  private drawWarnings(ctx: CanvasRenderingContext2D) {
    for (const w of this.warnings) {
      const t = w.t / w.dur;
      const pulse = 0.45 + 0.4 * Math.sin(this.time * 16);
      ctx.globalAlpha = (0.32 + (1 - t) * 0.35) * pulse + 0.18;
      if (w.kind === "circle") {
        ctx.strokeStyle = w.color;
        ctx.lineWidth = w.width;
        ctx.beginPath();
        ctx.arc(w.x, w.y, w.r, 0, TAU);
        ctx.stroke();
        ctx.globalAlpha *= 0.3;
        ctx.fillStyle = w.color;
        ctx.beginPath();
        ctx.arc(w.x, w.y, w.r * (1 - t), 0, TAU);
        ctx.fill();
      } else {
        ctx.strokeStyle = w.color;
        ctx.lineWidth = w.width;
        ctx.beginPath();
        ctx.moveTo(w.x, w.y);
        ctx.lineTo(w.x2, w.y2);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawHazards(ctx: CanvasRenderingContext2D) {
    const kind = this.chapter.hazardKind;
    if (kind === "current" && this.currentPhase !== "idle") {
      // chevron arrows across the view
      const a = this.currentA;
      const warn = this.currentPhase === "warn";
      ctx.save();
      ctx.globalAlpha = warn ? 0.35 + 0.25 * Math.sin(this.time * 14) : 0.5;
      ctx.strokeStyle = warn ? "#ffcc44" : "#ff8899";
      ctx.lineWidth = 5;
      const sp = 170;
      const flow = (this.time * (warn ? 40 : 240)) % sp;
      for (let gx = -2; gx < this.viewW / sp + 2; gx++) {
        for (let gy = -2; gy < this.viewH / sp + 2; gy++) {
          const cx = this.camX + gx * sp + flow * Math.cos(a) + (gy % 2) * sp * 0.5;
          const cy = this.camY + gy * sp + flow * Math.sin(a);
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(a);
          ctx.beginPath();
          ctx.moveTo(-12, -10);
          ctx.lineTo(4, 0);
          ctx.lineTo(-12, 10);
          ctx.stroke();
          ctx.restore();
        }
      }
      ctx.restore();
    }
    if (kind === "mines") {
      for (const m of this.mines) {
        if (m.dead) continue;
        const blink = m.armed ? (Math.sin(this.time * (26 - m.fuse * 18)) > 0 ? 1 : 0.35) : 1;
        ctx.globalAlpha = blink;
        ctx.fillStyle = m.armed ? "#ffaa33" : "#c9b8ff";
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.r, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = m.armed ? "#ff6622" : "#8877cc";
        ctx.lineWidth = 2;
        for (let i = 0; i < 7; i++) {
          const sa = (i / 7) * TAU + m.seed;
          ctx.beginPath();
          ctx.moveTo(m.x + Math.cos(sa) * m.r, m.y + Math.sin(sa) * m.r);
          ctx.lineTo(m.x + Math.cos(sa) * (m.r + 6), m.y + Math.sin(sa) * (m.r + 6));
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    }
    if (kind === "storm") {
      for (const z of this.stormZones) {
        if (z.zapT > 0) {
          // lightning zap
          ctx.strokeStyle = "#bdf8ff";
          ctx.lineWidth = 3;
          ctx.globalAlpha = Math.min(1, z.zapT * 5);
          for (let i = 0; i < 5; i++) {
            const a = rand(0, TAU);
            ctx.beginPath();
            ctx.moveTo(z.x, z.y - 200);
            let lx = z.x; let ly = z.y - 120;
            for (let s = 0; s < 4; s++) {
              lx += rand(-34, 34);
              ly += 40;
              ctx.lineTo(lx, ly);
            }
            ctx.lineTo(z.x + Math.cos(a) * 20, z.y + Math.sin(a) * 20);
            ctx.stroke();
          }
          ctx.fillStyle = "rgba(170,240,255,0.35)";
          ctx.beginPath();
          ctx.arc(z.x, z.y, z.r, 0, TAU);
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      }
    }
  }

  private drawInfectionCell(ctx: CanvasRenderingContext2D) {
    if (!this.infectActive) return;
    const x = this.infectX; const y = this.infectY;
    const pulse = 1 + Math.sin(this.time * 3) * 0.05;
    const r = 70 * pulse;
    // outer membrane
    ctx.fillStyle = "rgba(255,230,160,0.2)";
    ctx.beginPath();
    ctx.arc(x, y, r + 16, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#e8d9a8";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#c9a96e";
    ctx.beginPath();
    ctx.arc(x + 10, y - 6, r * 0.45, 0, TAU);
    ctx.fill();
    // infection progress overlay
    if (this.infectProg > 0) {
      ctx.fillStyle = "rgba(110,230,80,0.55)";
      ctx.beginPath();
      ctx.arc(x, y, r * this.infectProg, 0, TAU);
      ctx.fill();
    }
    // progress ring
    ctx.strokeStyle = "#8aff5a";
    ctx.lineWidth = 7;
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.arc(x, y, r + 24, -Math.PI / 2, -Math.PI / 2 + TAU * this.infectProg);
    ctx.stroke();
    ctx.globalAlpha = 0.25;
    ctx.beginPath();
    ctx.arc(x, y, r + 24, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 1;
    // marker arrow if off screen handled in HUD
  }

  private drawOrbs(ctx: CanvasRenderingContext2D) {
    for (const o of this.orbs) {
      const sp = this.time * 4 + o.seed;
      const bob = Math.sin(sp) * 3;
      // tiny double-helix: two dots + bar
      const dx = Math.cos(sp) * 6;
      ctx.strokeStyle = "rgba(125,255,138,0.7)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(o.x - dx, o.y + bob - 4);
      ctx.lineTo(o.x + dx, o.y + bob + 4);
      ctx.stroke();
      ctx.fillStyle = "#7dff8a";
      ctx.beginPath();
      ctx.arc(o.x - dx, o.y + bob - 4, 3.4, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#b8ffc0";
      ctx.beginPath();
      ctx.arc(o.x + dx, o.y + bob + 4, 3.4, 0, TAU);
      ctx.fill();
    }
  }

  // ── entity drawing ────────────────────────────────────────────────────────

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    const x = this.px; const y = this.py;
    const r = this.pr;
    const speed = Math.hypot(this.pvx, this.pvy);
    const stretch = clamp(speed / 900, 0, 0.3);
    const moveA = Math.atan2(this.pvy, this.pvx);

    if (this.invulnT > 0 && this.dashT <= 0 && Math.sin(this.time * 40) > 0) {
      ctx.globalAlpha = 0.45;
    }
    ctx.save();
    ctx.translate(x, y);
    // glow
    const glow = ctx.createRadialGradient(0, 0, r * 0.4, 0, 0, r * 2.6);
    glow.addColorStop(0, "rgba(130,255,90,0.3)");
    glow.addColorStop(1, "rgba(130,255,90,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, r * 2.6, 0, TAU);
    ctx.fill();

    ctx.rotate(moveA);
    ctx.scale(1 + stretch, 1 - stretch * 0.6);
    ctx.rotate(-moveA);

    // spikes
    const spikes = 12;
    ctx.fillStyle = this.hurtT > 0 ? "#ff9a7a" : "#5ad142";
    for (let i = 0; i < spikes; i++) {
      const a = (i / spikes) * TAU + this.time * 0.5;
      const len = r * 0.72 * (1 + 0.18 * Math.sin(this.time * 6 + i * 1.9));
      ctx.save();
      ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(r - 2, -4.2);
      ctx.lineTo(r + len, 0);
      ctx.lineTo(r - 2, 4.2);
      ctx.closePath();
      ctx.fill();
      // spike tip knob
      ctx.beginPath();
      ctx.arc(r + len, 0, 2.6, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    // body
    const body = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.2, 0, 0, r * 1.15);
    body.addColorStop(0, this.hurtT > 0 ? "#ffd0c0" : "#b4ff7a");
    body.addColorStop(0.65, this.hurtT > 0 ? "#ff8866" : "#64d94a");
    body.addColorStop(1, this.hurtT > 0 ? "#cc4433" : "#2e8f28");
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = "rgba(20,70,20,0.8)";
    ctx.lineWidth = 2;
    ctx.stroke();
    // nucleus
    ctx.fillStyle = "rgba(30,110,30,0.5)";
    ctx.beginPath();
    ctx.arc(r * 0.12, r * 0.18, r * 0.42, 0, TAU);
    ctx.fill();
    // eyes aimed at target
    const ea = this.aimA;
    const eo = 4.6;
    const eyeW = this.blink > 0 ? 0.8 : 3.4;
    for (const side of [-1, 1]) {
      const ex = Math.cos(ea) * 5 + Math.cos(ea + Math.PI / 2) * eo * side;
      const ey = Math.sin(ea) * 5 + Math.sin(ea + Math.PI / 2) * eo * side;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.ellipse(ex, ey, 4.4, eyeW + 1, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#143014";
      ctx.beginPath();
      ctx.ellipse(ex + Math.cos(ea) * 1.6, ey + Math.sin(ea) * 1.6, 2.1, Math.min(eyeW, 2.1), 0, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    // dash trail
    if (this.dashT > 0) {
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = "#8affda";
      ctx.beginPath();
      ctx.arc(x - this.pvx * 0.03, y - this.pvy * 0.03, r * 1.1, 0, TAU);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  private drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy) {
    if (e.alpha <= 0.02) return;
    ctx.save();
    ctx.globalAlpha = e.alpha;
    ctx.translate(e.x, e.y);
    const flash = e.flash > 0;
    const tele = e.state === "telegraph";
    const telePulse = tele && Math.sin(this.time * 18) > 0;

    if (e.behavior === "lunger") {
      // Y-shaped antibody
      ctx.rotate(angleTo(0, 0, this.px - e.x, this.py - e.y) + Math.PI / 2);
      ctx.strokeStyle = flash || telePulse ? "#ffffff" : tele ? "#ff7766" : "#f3e9d0";
      ctx.lineWidth = 7;
      ctx.lineCap = "round";
      const w = Math.sin(this.time * 5 + e.seed) * 0.15;
      ctx.beginPath();
      ctx.moveTo(0, e.r);
      ctx.lineTo(0, 0);
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(-2.2 + w) * e.r, Math.sin(-2.2 + w) * e.r);
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(-0.94 - w) * e.r, Math.sin(-0.94 - w) * e.r);
      ctx.stroke();
      ctx.fillStyle = flash || telePulse ? "#ffffff" : "#e8d9b8";
      for (const [bx, by] of [
        [0, e.r], [Math.cos(-2.2 + w) * e.r, Math.sin(-2.2 + w) * e.r],
        [Math.cos(-0.94 - w) * e.r, Math.sin(-0.94 - w) * e.r],
      ]) {
        ctx.beginPath();
        ctx.arc(bx, by, 5, 0, TAU);
        ctx.fill();
      }
    } else if (e.behavior === "shooter") {
      // T-cell: purple orb + targeting nozzle
      ctx.fillStyle = flash || telePulse ? "#ffffff" : "#7a4fd0";
      ctx.beginPath();
      ctx.arc(0, 0, e.r, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = flash ? "#ffffff" : "#c9a7ff";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, e.r - 4, this.time * 2 + e.seed, this.time * 2 + e.seed + 4);
      ctx.stroke();
      ctx.save();
      ctx.rotate(e.angle);
      ctx.fillStyle = flash ? "#ffffff" : "#d8c2ff";
      ctx.fillRect(e.r - 4, -3.4, 12, 6.8);
      ctx.restore();
      // aim line while telegraphing
      if (tele) {
        const aa = angleTo(e.x, e.y, e.aimX, e.aimY);
        ctx.strokeStyle = `rgba(255,80,120,${0.35 + 0.3 * Math.sin(this.time * 16)})`;
        ctx.lineWidth = 3;
        ctx.setLineDash([8, 7]);
        ctx.beginPath();
        ctx.moveTo(Math.cos(aa) * (e.r + 4), Math.sin(aa) * (e.r + 4));
        ctx.lineTo(Math.cos(aa) * 460, Math.sin(aa) * 460);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      // eye
      ctx.fillStyle = "#2a1850";
      ctx.beginPath();
      ctx.arc(Math.cos(e.angle) * 5, Math.sin(e.angle) * 5, 4.4, 0, TAU);
      ctx.fill();
    } else {
      // microglia: spiky dark blob
      const spikes = 9;
      ctx.fillStyle = flash ? "#ffffff" : e.state === "slash" ? "#ff66cc" : "#9b2d84";
      ctx.beginPath();
      for (let i = 0; i <= spikes * 2; i++) {
        const a = (i / (spikes * 2)) * TAU;
        const rr = e.r * (i % 2 === 0 ? 1.25 : 0.72) * (1 + 0.1 * Math.sin(this.time * 7 + i + e.seed));
        const vx = Math.cos(a + this.time * 1.2) * rr;
        const vy = Math.sin(a + this.time * 1.2) * rr;
        if (i === 0) ctx.moveTo(vx, vy);
        else ctx.lineTo(vx, vy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = flash ? "#eeeeee" : "#50124a";
      ctx.beginPath();
      ctx.arc(0, 0, e.r * 0.5, 0, TAU);
      ctx.fill();
      // single eye
      const aa = angleTo(e.x, e.y, this.px, this.py);
      ctx.fillStyle = "#ffdd55";
      ctx.beginPath();
      ctx.arc(Math.cos(aa) * 4, Math.sin(aa) * 4, 3.8, 0, TAU);
      ctx.fill();
    }
    ctx.restore();

    // mini hp bar when damaged
    if (e.hp < e.maxHp && e.alpha > 0.5) {
      const w = 26;
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      ctx.fillRect(e.x - w / 2, e.y - e.r - 12, w, 4);
      ctx.fillStyle = "#ff6655";
      ctx.fillRect(e.x - w / 2, e.y - e.r - 12, w * clamp(e.hp / e.maxHp, 0, 1), 4);
    }
  }

  private drawBoss(ctx: CanvasRenderingContext2D, b: Boss) {
    ctx.save();
    ctx.translate(b.x, b.y);
    const flash = b.flash > 0;
    if (b.pattern === "macrophage") {
      // giant wobbling amoeba
      ctx.fillStyle = flash ? "#ffffff" : "rgba(226,196,152,0.95)";
      ctx.beginPath();
      const pts = 14;
      for (let i = 0; i <= pts; i++) {
        const a = (i / pts) * TAU;
        const rr = b.r * (1 + 0.14 * Math.sin(a * 3 + this.time * 2.4 + b.seed));
        if (i === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
        else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(120,90,50,0.6)";
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.fillStyle = flash ? "#eeeeee" : "#8a5a9e";
      ctx.beginPath();
      ctx.arc(b.r * 0.12, b.r * 0.1, b.r * 0.4, 0, TAU);
      ctx.fill();
      // angry eyes
      const aa = angleTo(b.x, b.y, this.px, this.py);
      for (const side of [-1, 1]) {
        const ex = Math.cos(aa) * 16 + Math.cos(aa + Math.PI / 2) * 13 * side;
        const ey = Math.sin(aa) * 16 + Math.sin(aa + Math.PI / 2) * 13 * side;
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(ex, ey, 7, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "#471515";
        ctx.beginPath();
        ctx.arc(ex + Math.cos(aa) * 2.5, ey + Math.sin(aa) * 2.5, 3.4, 0, TAU);
        ctx.fill();
      }
    } else if (b.pattern === "matriarch") {
      ctx.fillStyle = flash ? "#ffffff" : "#d46ab8";
      ctx.beginPath();
      ctx.arc(0, 0, b.r, 0, TAU);
      ctx.fill();
      ctx.fillStyle = flash ? "#eeeeee" : "#a3418c";
      ctx.beginPath();
      ctx.arc(0, 0, b.r * 0.72, 0, TAU);
      ctx.fill();
      ctx.fillStyle = flash ? "#dddddd" : "#6e2460";
      ctx.beginPath();
      ctx.arc(0, 0, b.r * 0.4, 0, TAU);
      ctx.fill();
      // orbiting antibody satellites
      ctx.strokeStyle = "#f0d9ff";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      for (let i = 0; i < 5; i++) {
        const a = b.spin * 1.4 + (i / 5) * TAU;
        const ox = Math.cos(a) * (b.r + 22);
        const oy = Math.sin(a) * (b.r + 22);
        ctx.beginPath();
        ctx.moveTo(ox, oy);
        ctx.lineTo(ox + Math.cos(a) * 10, oy + Math.sin(a) * 10);
        ctx.moveTo(ox, oy);
        ctx.lineTo(ox + Math.cos(a + 2.4) * 10, oy + Math.sin(a + 2.4) * 10);
        ctx.moveTo(ox, oy);
        ctx.lineTo(ox + Math.cos(a - 2.4) * 10, oy + Math.sin(a - 2.4) * 10);
        ctx.stroke();
      }
      const aa = angleTo(b.x, b.y, this.px, this.py);
      ctx.fillStyle = "#ffe9f8";
      ctx.beginPath();
      ctx.arc(Math.cos(aa) * 10, Math.sin(aa) * 10, 6, 0, TAU);
      ctx.fill();
    } else {
      // overmind: neuron core with dendrites
      ctx.strokeStyle = flash ? "#ffffff" : "#1899b8";
      ctx.lineWidth = 5;
      ctx.lineCap = "round";
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU + Math.sin(this.time + i) * 0.1;
        const len = b.r + 26 + Math.sin(this.time * 3 + i * 2) * 8;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * b.r * 0.7, Math.sin(a) * b.r * 0.7);
        ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len);
        ctx.stroke();
        ctx.fillStyle = "#66eaff";
        ctx.beginPath();
        ctx.arc(Math.cos(a) * len, Math.sin(a) * len, 5.5, 0, TAU);
        ctx.fill();
      }
      const pulse = 1 + Math.sin(this.time * 4) * 0.06;
      const core = ctx.createRadialGradient(0, 0, 4, 0, 0, b.r * pulse);
      core.addColorStop(0, flash ? "#ffffff" : "#bdf6ff");
      core.addColorStop(0.6, flash ? "#dddddd" : "#2fb9d8");
      core.addColorStop(1, "#0c4a60");
      ctx.fillStyle = core;
      ctx.beginPath();
      ctx.arc(0, 0, b.r * pulse, 0, TAU);
      ctx.fill();
      const aa = angleTo(b.x, b.y, this.px, this.py);
      ctx.fillStyle = "#06222e";
      ctx.beginPath();
      ctx.arc(Math.cos(aa) * 12, Math.sin(aa) * 12, 9, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#9df3ff";
      ctx.beginPath();
      ctx.arc(Math.cos(aa) * 14, Math.sin(aa) * 14, 3.6, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawBullets(ctx: CanvasRenderingContext2D) {
    for (const bl of this.bullets) {
      if (bl.friendly) {
        // spike dart
        const a = Math.atan2(bl.vy, bl.vx);
        ctx.save();
        ctx.translate(bl.x, bl.y);
        ctx.rotate(a);
        ctx.fillStyle = bl.color;
        ctx.beginPath();
        ctx.moveTo(8, 0);
        ctx.lineTo(-6, -3.6);
        ctx.lineTo(-6, 3.6);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      } else {
        ctx.fillStyle = bl.color;
        ctx.beginPath();
        ctx.arc(bl.x, bl.y, bl.r, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.7)";
        ctx.beginPath();
        ctx.arc(bl.x, bl.y, bl.r * 0.45, 0, TAU);
        ctx.fill();
      }
    }
  }

  private drawBeamsRings(ctx: CanvasRenderingContext2D) {
    for (const bm of this.beams) {
      const t = bm.t / bm.dur;
      ctx.globalAlpha = Math.min(1, t * 2.5);
      ctx.strokeStyle = bm.color;
      ctx.lineWidth = bm.width * (0.6 + t * 0.4);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(bm.x, bm.y);
      ctx.lineTo(bm.x2, bm.y2);
      ctx.stroke();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = bm.width * 0.3 * t;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
    for (const ring of this.rings) {
      ctx.strokeStyle = "#66eaff";
      ctx.lineWidth = 10;
      ctx.globalAlpha = 0.8 * (1 - ring.r / ring.maxR) + 0.2;
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.r, 0, TAU);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  // ── HUD ───────────────────────────────────────────────────────────────────

  private drawHUD(ctx: CanvasRenderingContext2D) {
    const W = this.viewW;
    const pad = 14;
    const touch = this.input.touchMode;

    // HP bar
    const hpw = Math.min(210, W * 0.3);
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    this.rrect(ctx, pad, pad, hpw + 6, 20, 10);
    const hpFrac = clamp(this.hp / this.stats.maxHp, 0, 1);
    const hpColor = hpFrac > 0.5 ? "#6ee657" : hpFrac > 0.25 ? "#ffcc44" : "#ff5544";
    ctx.fillStyle = hpColor;
    this.rrect(ctx, pad + 3, pad + 3, hpw * hpFrac, 14, 7);
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "bold 11px 'Trebuchet MS', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`HP ${Math.ceil(this.hp)}/${this.stats.maxHp}`, pad + 8, pad + 14.5);

    // DNA
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    this.rrect(ctx, pad, pad + 26, 92, 22, 11);
    ctx.fillStyle = "#7dff8a";
    ctx.font = "bold 14px 'Trebuchet MS', sans-serif";
    ctx.fillText(`🧬 ${this.dna}`, pad + 10, pad + 42);

    // Score (top right, leaving space for pause button)
    ctx.textAlign = "right";
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    this.rrect(ctx, W - 62 - 140, pad, 140, 24, 12);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 15px 'Trebuchet MS', sans-serif";
    ctx.fillText(this.score.toLocaleString("en-US"), W - 62 - 10, pad + 17.5);

    // objective / boss bar (top center)
    const c = this.chapter;
    ctx.textAlign = "center";
    if (this.boss && this.boss.state !== "dead") {
      const bw = Math.min(380, W * 0.5);
      const bx = W / 2 - bw / 2;
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      this.rrect(ctx, bx - 4, pad + 18, bw + 8, 16, 8);
      ctx.fillStyle = "#ff4466";
      this.rrect(ctx, bx, pad + 21, bw * clamp(this.boss.hp / this.boss.maxHp, 0, 1), 10, 5);
      ctx.fillStyle = "#ffb3c0";
      ctx.font = "bold 12px 'Trebuchet MS', sans-serif";
      ctx.fillText(c.bossName, W / 2, pad + 12);
    } else {
      let obj: string;
      if (this.infectActive) obj = "☣ INFECT THE HOST CELL";
      else if (this.bossSpawned && !this.bossDefeated) obj = `DEFEAT ${c.bossName}`;
      else if (this.bossDefeated) obj = "CHAPTER SECURE";
      else obj = `${c.enemyName}s destroyed: ${this.kills}/${c.killQuota}`;
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      ctx.font = "bold 13px 'Trebuchet MS', sans-serif";
      ctx.fillText(obj, W / 2, pad + 14);
      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.font = "11px 'Trebuchet MS', sans-serif";
      ctx.fillText(`${c.hazardName} active — ${c.hazardHint}`, W / 2, pad + 30);
    }

    // off-screen host-cell arrow
    if (this.infectActive) {
      const sx = this.infectX - this.camX;
      const sy = this.infectY - this.camY;
      if (sx < 0 || sy < 0 || sx > W || sy > this.viewH) {
        const cxm = W / 2; const cym = this.viewH / 2;
        const a = Math.atan2(sy - cym, sx - cxm);
        const ax = cxm + Math.cos(a) * (Math.min(W, this.viewH) * 0.38);
        const ay = cym + Math.sin(a) * (Math.min(W, this.viewH) * 0.38);
        ctx.save();
        ctx.translate(ax, ay);
        ctx.rotate(a);
        ctx.fillStyle = `rgba(138,255,90,${0.6 + 0.3 * Math.sin(this.time * 6)})`;
        ctx.beginPath();
        ctx.moveTo(14, 0);
        ctx.lineTo(-8, -9);
        ctx.lineTo(-8, 9);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }

    // ability cooldowns
    if (!touch) {
      this.drawCooldown(ctx, pad + 26, this.viewH - pad - 26, 20, this.fireCd / this.stats.spikeCd, "#9dff5e", "SPIKE · hold LMB/Space");
      this.drawCooldown(ctx, pad + 26, this.viewH - pad - 78, 20, this.dashCdT / this.stats.dashCd, "#8affda", "DASH · Shift/RMB");
    } else {
      // virtual controls — joystick
      const jr = 52;
      if (this.input.joyActive) {
        ctx.globalAlpha = 0.3;
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(this.input.joyBaseX, this.input.joyBaseY, jr, 0, TAU);
        ctx.stroke();
        ctx.globalAlpha = 0.5;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(
          this.input.joyBaseX + this.input.joyX * jr,
          this.input.joyBaseY + this.input.joyY * jr,
          20, 0, TAU
        );
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      // action buttons (positions updated for layout)
      this.input.burstBtn.x = W - 64;
      this.input.burstBtn.y = this.viewH - 76;
      this.input.dashBtn.x = W - 142;
      this.input.dashBtn.y = this.viewH - 52;
      this.drawTouchBtn(ctx, this.input.burstBtn, this.fireCd / this.stats.spikeCd, "#9dff5e");
      this.drawTouchBtn(ctx, this.input.dashBtn, this.dashCdT / this.stats.dashCd, "#8affda");
    }

    // banner
    if (this.banner.t > 0) {
      const a = Math.min(1, this.banner.t * 2) * Math.min(1, (3 - this.banner.t) * 3 + 0.2);
      ctx.globalAlpha = clamp(a, 0, 1);
      ctx.textAlign = "center";
      ctx.font = `900 ${Math.min(44, W * 0.055)}px 'Trebuchet MS', sans-serif`;
      ctx.lineWidth = 6;
      ctx.strokeStyle = "rgba(0,0,0,0.6)";
      ctx.strokeText(this.banner.text, W / 2, this.viewH * 0.32);
      ctx.fillStyle = this.chapter.accent;
      ctx.fillText(this.banner.text, W / 2, this.viewH * 0.32);
      if (this.banner.sub) {
        ctx.font = `bold ${Math.min(17, W * 0.026)}px 'Trebuchet MS', sans-serif`;
        ctx.lineWidth = 4;
        ctx.strokeText(this.banner.sub, W / 2, this.viewH * 0.32 + 32);
        ctx.fillStyle = "#ffffff";
        ctx.fillText(this.banner.sub, W / 2, this.viewH * 0.32 + 32);
      }
      ctx.globalAlpha = 1;
    }
  }

  private drawCooldown(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, frac: number, color: string, label: string) {
    const f = clamp(frac, 0, 1);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.globalAlpha = f > 0 ? 0.35 : 1;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(x, y, r - 3, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 1;
    if (f > 0) {
      ctx.strokeStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, r - 3, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - f));
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(255,255,255,0.65)";
    ctx.font = "10px 'Trebuchet MS', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(label, x + r + 8, y + 3);
  }

  private drawTouchBtn(ctx: CanvasRenderingContext2D, b: { x: number; y: number; r: number; pressed: boolean; label: string }, frac: number, color: string) {
    const f = clamp(frac, 0, 1);
    ctx.globalAlpha = b.pressed ? 0.75 : 0.42;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.globalAlpha = b.pressed ? 1 : 0.7;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r - 3, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - f));
    ctx.stroke();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 12px 'Trebuchet MS', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(b.label, b.x, b.y + 4);
    ctx.globalAlpha = 1;
  }

  private drawMenuBackdrop(ctx: CanvasRenderingContext2D) {
    // slowly animated spores drifting behind the menu
    ctx.fillStyle = "rgba(125,255,138,0.1)";
    for (let i = 0; i < 16; i++) {
      const x = ((i * 193.7 + this.time * (12 + (i % 5) * 6)) % (this.viewW + 160)) - 80;
      const y = (i * 131.3) % this.viewH + Math.sin(this.time * 0.8 + i) * 24;
      ctx.beginPath();
      ctx.arc(x, y, 18 + (i % 4) * 9, 0, TAU);
      ctx.fill();
    }
  }

  private rrect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    if (w <= 0) return;
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
    ctx.fill();
  }
}

