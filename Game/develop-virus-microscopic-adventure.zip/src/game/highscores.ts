// ─── Local high-score table (localStorage) ─────────────────────────────────

export interface ScoreEntry {
  name: string;
  score: number;
  chapter: number; // highest chapter reached (1-based)
  date: string;
}

const KEY = "virus-game-highscores-v1";
const MAX = 8;

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (e) =>
          e && typeof e.score === "number" && typeof e.name === "string"
      )
      .slice(0, MAX);
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const scores = loadScores();
  scores.push(entry);
  scores.sort((a, b) => b.score - a.score);
  const top = scores.slice(0, MAX);
  try {
    localStorage.setItem(KEY, JSON.stringify(top));
  } catch {
    /* storage unavailable – ignore */
  }
  return top;
}

export function isHighScore(score: number): boolean {
  const scores = loadScores();
  if (score <= 0) return false;
  if (scores.length < MAX) return true;
  return score > scores[scores.length - 1].score;
}
