export type GamePhase = "ready" | "playing" | "paused" | "infecting" | "won" | "gameover";

export interface InputState {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
}

export interface Player {
  x: number;
  y: number;
  radius: number;
  targetX: number;
  targetY: number;
  vx: number;
  vy: number;
  facing: number;
  invulnerable: number;
}

export interface DnaParticle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  phase: number;
  active: boolean;
  respawnAt: number;
}

export interface Medicine {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  phase: number;
  kind: number;
}

export interface BurstParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  duration: number;
  radius: number;
  color: string;
}

export interface GameWorld {
  width: number;
  height: number;
  time: number;
  phase: GamePhase;
  resumePhase: "playing" | "infecting" | null;
  player: Player;
  cell: { x: number; y: number; radius: number };
  dna: DnaParticle[];
  medicines: Medicine[];
  effects: BurstParticle[];
  energy: number;
  health: number;
  infectionProgress: number;
  toast: string;
  toastKind: "info" | "warning" | "success";
  toastUntil: number;
  toastId: number;
  shake: number;
}

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const distanceSquared = (ax: number, ay: number, bx: number, by: number) => (ax - bx) ** 2 + (ay - by) ** 2;

function createDna(id: number, x: number, y: number): DnaParticle {
  const angle = Math.random() * Math.PI * 2;
  const speed = 18 + Math.random() * 24;
  return {
    id,
    x,
    y,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    phase: Math.random() * Math.PI * 2,
    active: true,
    respawnAt: 0,
  };
}

export function createWorld(width = 1120, height = 700, phase: GamePhase = "ready"): GameWorld {
  const cell = { x: width * 0.75, y: height * 0.5, radius: 87 };
  const dnaSpots = [
    [0.38, 0.22], [0.55, 0.2], [0.41, 0.54], [0.62, 0.38],
    [0.34, 0.77], [0.65, 0.76], [0.85, 0.61], [0.8, 0.18],
  ];

  return {
    width,
    height,
    time: 0,
    phase,
    resumePhase: null,
    player: {
      x: width * 0.22,
      y: height * 0.51,
      radius: 25,
      targetX: width * 0.22,
      targetY: height * 0.51,
      vx: 0,
      vy: 0,
      facing: 0,
      invulnerable: 0,
    },
    cell,
    dna: dnaSpots.map(([x, y], id) => createDna(id, width * x, height * y)),
    medicines: [
      { id: 0, x: width * 0.46, y: height * 0.31, vx: 77, vy: 29, radius: 25, phase: 0.5, kind: 0 },
      { id: 1, x: width * 0.59, y: height * 0.73, vx: -65, vy: -24, radius: 27, phase: 2.6, kind: 1 },
      { id: 2, x: width * 0.88, y: height * 0.28, vx: 30, vy: 61, radius: 24, phase: 4.3, kind: 2 },
    ],
    effects: [],
    energy: 0,
    health: 3,
    infectionProgress: 0,
    toast: "",
    toastKind: "info",
    toastUntil: 0,
    toastId: 0,
    shake: 0,
  };
}

export function resizeWorld(world: GameWorld, width: number, height: number) {
  const scaleX = width / world.width;
  const scaleY = height / world.height;

  world.width = width;
  world.height = height;
  world.player.x *= scaleX;
  world.player.targetX *= scaleX;
  world.player.vx *= scaleX;
  world.player.y *= scaleY;
  world.player.targetY *= scaleY;
  world.player.vy *= scaleY;
  world.cell.x *= scaleX;
  world.cell.y *= scaleY;

  for (const particle of world.dna) {
    particle.x *= scaleX;
    particle.y *= scaleY;
    particle.vx *= scaleX;
    particle.vy *= scaleY;
  }
  for (const medicine of world.medicines) {
    medicine.x *= scaleX;
    medicine.y *= scaleY;
    medicine.vx *= scaleX;
    medicine.vy *= scaleY;
  }
  for (const effect of world.effects) {
    effect.x *= scaleX;
    effect.y *= scaleY;
    effect.vx *= scaleX;
    effect.vy *= scaleY;
  }
}

function addBurst(world: GameWorld, x: number, y: number, color: string, count: number, speed: number) {
  for (let i = 0; i < count; i += 1) {
    const angle = (Math.PI * 2 * i) / count + Math.random() * 0.22;
    const velocity = speed * (0.45 + Math.random() * 0.75);
    const duration = 0.45 + Math.random() * 0.6;
    world.effects.push({
      x,
      y,
      vx: Math.cos(angle) * velocity,
      vy: Math.sin(angle) * velocity,
      life: duration,
      duration,
      radius: 2 + Math.random() * 4,
      color,
    });
  }
}

function setToast(world: GameWorld, text: string, kind: GameWorld["toastKind"], duration = 1.5) {
  world.toast = text;
  world.toastKind = kind;
  world.toastUntil = world.time + duration;
  world.toastId += 1;
}

function moveDna(world: GameWorld, particle: DnaParticle, delta: number, canRespawn: boolean) {
  if (!particle.active) {
    if (canRespawn) {
      particle.respawnAt -= delta;
      if (particle.respawnAt <= 0) {
        const bounds = { minX: 42, maxX: world.width - 42, minY: 52, maxY: world.height - 52 };
        for (let attempt = 0; attempt < 12; attempt += 1) {
          const x = bounds.minX + Math.random() * (bounds.maxX - bounds.minX);
          const y = bounds.minY + Math.random() * (bounds.maxY - bounds.minY);
          const awayFromCell = distanceSquared(x, y, world.cell.x, world.cell.y) > (world.cell.radius + 45) ** 2;
          const awayFromPlayer = distanceSquared(x, y, world.player.x, world.player.y) > 115 ** 2;
          if (awayFromCell && awayFromPlayer) {
            particle.x = x;
            particle.y = y;
            break;
          }
          particle.x = bounds.minX + Math.random() * (bounds.maxX - bounds.minX);
          particle.y = bounds.minY + Math.random() * (bounds.maxY - bounds.minY);
        }
        const angle = Math.random() * Math.PI * 2;
        particle.vx = Math.cos(angle) * 28;
        particle.vy = Math.sin(angle) * 28;
        particle.active = true;
      }
    }
    return;
  }

  const driftX = Math.sin(world.time * 0.72 + particle.phase) * 13;
  const driftY = Math.cos(world.time * 0.64 + particle.phase * 1.3) * 13;
  particle.vx += driftX * delta;
  particle.vy += driftY * delta;
  const speed = Math.hypot(particle.vx, particle.vy);
  if (speed > 48) {
    particle.vx = (particle.vx / speed) * 48;
    particle.vy = (particle.vy / speed) * 48;
  }
  particle.x += particle.vx * delta;
  particle.y += particle.vy * delta;

  if (particle.x < 38 || particle.x > world.width - 38) particle.vx *= -1;
  if (particle.y < 44 || particle.y > world.height - 44) particle.vy *= -1;
  particle.x = clamp(particle.x, 38, world.width - 38);
  particle.y = clamp(particle.y, 44, world.height - 44);
}

function moveMedicines(world: GameWorld, delta: number) {
  for (const medicine of world.medicines) {
    const sway = Math.sin(world.time * 0.85 + medicine.phase) * 18;
    medicine.x += (medicine.vx + sway) * delta;
    medicine.y += (medicine.vy + Math.cos(world.time * 0.92 + medicine.phase) * 14) * delta;

    const minX = 54;
    const maxX = world.width - 54;
    const minY = 68;
    const maxY = world.height - 58;
    if (medicine.x < minX || medicine.x > maxX) medicine.vx *= -1;
    if (medicine.y < minY || medicine.y > maxY) medicine.vy *= -1;
    medicine.x = clamp(medicine.x, minX, maxX);
    medicine.y = clamp(medicine.y, minY, maxY);
  }
}

function infectCell(world: GameWorld) {
  world.phase = "infecting";
  world.infectionProgress = 0;
  world.shake = 7;
  setToast(world, "ЗАРАЖЕНИЕ НАЧАЛОСЬ!", "success", 2.3);
  addBurst(world, world.cell.x, world.cell.y, "#d5ff68", 28, 110);
}

export function updateWorld(world: GameWorld, rawDelta: number, input?: InputState) {
  const delta = clamp(rawDelta, 0, 0.04);
  world.time += delta;
  world.shake = Math.max(0, world.shake - delta * 18);

  for (const particle of world.dna) {
    moveDna(world, particle, delta, world.phase !== "paused" && world.phase !== "won" && world.phase !== "gameover");
  }
  for (const effect of world.effects) {
    effect.life -= delta;
    effect.x += effect.vx * delta;
    effect.y += effect.vy * delta;
    effect.vx *= Math.max(0, 1 - delta * 2.8);
    effect.vy *= Math.max(0, 1 - delta * 2.8);
  }
  world.effects = world.effects.filter((effect) => effect.life > 0);

  if (world.toast && world.time >= world.toastUntil) world.toast = "";

  if (world.phase === "infecting") {
    world.infectionProgress = clamp(world.infectionProgress + delta / 2.45, 0, 1);
    if (world.infectionProgress >= 1) {
      world.phase = "won";
      world.shake = 3;
      setToast(world, "КЛЕТКА ЗАРАЖЕНА!", "success", 4);
      addBurst(world, world.cell.x, world.cell.y, "#c5ff55", 48, 185);
    }
    return;
  }

  if (world.phase !== "playing") return;

  const horizontal = Number(Boolean(input?.right)) - Number(Boolean(input?.left));
  const vertical = Number(Boolean(input?.down)) - Number(Boolean(input?.up));
  let desiredX = 0;
  let desiredY = 0;

  if (horizontal || vertical) {
    const length = Math.hypot(horizontal, vertical) || 1;
    desiredX = (horizontal / length) * 300;
    desiredY = (vertical / length) * 300;
    world.player.targetX = world.player.x + horizontal * 80;
    world.player.targetY = world.player.y + vertical * 80;
  } else {
    const toX = world.player.targetX - world.player.x;
    const toY = world.player.targetY - world.player.y;
    const distance = Math.hypot(toX, toY);
    const speed = Math.min(300, distance * 3.8);
    if (distance > 1) {
      desiredX = (toX / distance) * speed;
      desiredY = (toY / distance) * speed;
    }
  }

  const response = Math.min(1, delta * 7.5);
  world.player.vx += (desiredX - world.player.vx) * response;
  world.player.vy += (desiredY - world.player.vy) * response;
  world.player.x += world.player.vx * delta;
  world.player.y += world.player.vy * delta;
  world.player.x = clamp(world.player.x, 34, world.width - 34);
  world.player.y = clamp(world.player.y, 42, world.height - 42);
  if (Math.hypot(world.player.vx, world.player.vy) > 5) {
    world.player.facing = Math.atan2(world.player.vy, world.player.vx);
  }
  world.player.invulnerable = Math.max(0, world.player.invulnerable - delta);

  moveMedicines(world, delta);

  // Only direct player-cell overlap can begin the infection sequence.
  if (distanceSquared(world.player.x, world.player.y, world.cell.x, world.cell.y) < (world.cell.radius + world.player.radius * 0.62) ** 2) {
    infectCell(world);
    return;
  }

  for (const particle of world.dna) {
    if (!particle.active) continue;
    if (distanceSquared(world.player.x, world.player.y, particle.x, particle.y) < (world.player.radius + 15) ** 2) {
      particle.active = false;
      particle.respawnAt = 1.25;
      world.energy += 12;
      setToast(world, "Энергия +12 · ДНК собрана", "success", 1.45);
      world.shake = Math.max(world.shake, 1.5);
      addBurst(world, particle.x, particle.y, "#a5ffed", 12, 75);
    }
  }

  if (world.player.invulnerable > 0) return;

  for (const medicine of world.medicines) {
    if (distanceSquared(world.player.x, world.player.y, medicine.x, medicine.y) < (world.player.radius + medicine.radius * 0.8) ** 2) {
      world.health = Math.max(0, world.health - 1);
      world.energy = Math.max(0, world.energy - 8);
      world.player.invulnerable = 1.35;
      const awayX = world.player.x - medicine.x;
      const awayY = world.player.y - medicine.y;
      const length = Math.hypot(awayX, awayY) || 1;
      world.player.vx = (awayX / length) * 190;
      world.player.vy = (awayY / length) * 190;
      world.player.targetX = clamp(world.player.x + (awayX / length) * 120, 34, world.width - 34);
      world.player.targetY = clamp(world.player.y + (awayY / length) * 120, 42, world.height - 42);
      world.shake = 8;
      addBurst(world, world.player.x, world.player.y, "#ffb18e", 16, 95);
      if (world.health === 0) {
        world.phase = "gameover";
        setToast(world, "Лекарства остановили вирус", "warning", 4);
      } else {
        setToast(world, "Осторожно! Аптечка отняла жизнь", "warning", 1.8);
      }
      break;
    }
  }
}