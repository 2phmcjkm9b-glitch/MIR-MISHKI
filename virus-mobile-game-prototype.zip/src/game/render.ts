import type { BurstParticle, DnaParticle, GameWorld, Medicine } from "./model";

const TAU = Math.PI * 2;
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

function roundedRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawArena(ctx: CanvasRenderingContext2D, world: GameWorld) {
  const { width, height, time } = world;
  const background = ctx.createLinearGradient(0, 0, width * 0.92, height);
  background.addColorStop(0, "#061a27");
  background.addColorStop(0.52, "#0b2934");
  background.addColorStop(1, "#0a1c31");
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, width, height);

  const glow = ctx.createRadialGradient(width * 0.29, height * 0.4, 15, width * 0.29, height * 0.4, width * 0.63);
  glow.addColorStop(0, "rgba(48, 155, 145, 0.14)");
  glow.addColorStop(1, "rgba(8, 23, 39, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.lineWidth = 1;
  for (let x = 28; x < width; x += 42) {
    for (let y = 26; y < height; y += 42) {
      const shimmer = 0.12 + (Math.sin(x * 0.06 + y * 0.04 + time * 0.65) + 1) * 0.08;
      ctx.fillStyle = `rgba(145, 225, 207, ${shimmer})`;
      ctx.beginPath();
      ctx.arc(x, y, (x + y) % 4 < 1 ? 1.25 : 0.8, 0, TAU);
      ctx.fill();
    }
  }

  ctx.setLineDash([2, 12]);
  ctx.strokeStyle = "rgba(126, 214, 193, 0.075)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(width * 0.51, height * 0.5, width * 0.41, height * 0.39, -0.17, 0, TAU);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(width * 0.51, height * 0.5, width * 0.33, height * 0.29, 0.12, 0, TAU);
  ctx.stroke();
  ctx.setLineDash([]);

  const edge = ctx.createLinearGradient(18, 22, width - 20, height - 18);
  edge.addColorStop(0, "rgba(128, 222, 205, 0.18)");
  edge.addColorStop(0.55, "rgba(119, 198, 178, 0.055)");
  edge.addColorStop(1, "rgba(172, 178, 255, 0.18)");
  ctx.strokeStyle = edge;
  ctx.lineWidth = 1.25;
  roundedRectPath(ctx, 15, 15, width - 30, height - 30, 24);
  ctx.stroke();

  ctx.fillStyle = "rgba(160, 249, 223, 0.56)";
  const corners = [
    [31, 31, 1, 1], [width - 31, 31, -1, 1],
    [31, height - 31, 1, -1], [width - 31, height - 31, -1, -1],
  ];
  for (const [x, y, dx, dy] of corners) {
    ctx.fillRect(x, y, dx * 10, dy * 1.5);
    ctx.fillRect(x, y, dx * 1.5, dy * 10);
  }
  ctx.restore();
}

function traceCell(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, time: number, infection: number, expansion = 0) {
  const steps = 48;
  ctx.beginPath();
  for (let i = 0; i <= steps; i += 1) {
    const angle = (i / steps) * TAU;
    const wave = Math.sin(angle * 3 + time * 1.1) * 0.035 + Math.sin(angle * 5 - time * 0.78) * 0.022;
    const infectionWobble = infection > 0 ? Math.sin(angle * 7 + time * 8) * infection * 0.035 : 0;
    const r = radius * (1 + wave + infectionWobble) + expansion;
    const px = x + Math.cos(angle) * r;
    const py = y + Math.sin(angle) * r * 0.94;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function drawCell(ctx: CanvasRenderingContext2D, world: GameWorld) {
  const { x, y, radius } = world.cell;
  const { time, infectionProgress: progress, phase } = world;
  const pulse = Math.sin(time * 2.1) * 2.4;
  const isInfected = phase === "infecting" || phase === "won";
  const infection = isInfected ? Math.max(progress, phase === "won" ? 1 : 0.04) : 0;

  ctx.save();
  const halo = ctx.createRadialGradient(x, y, radius * 0.25, x, y, radius * 2.05);
  halo.addColorStop(0, `rgba(214, 106, 239, ${0.2 - infection * 0.08})`);
  halo.addColorStop(0.55, `rgba(169, 79, 220, ${0.1 - infection * 0.035})`);
  halo.addColorStop(1, "rgba(170, 81, 227, 0)");
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(x, y, radius * 2.05, 0, TAU);
  ctx.fill();

  if (infection > 0) {
    const ringRadius = radius + 14 + ((time * 54) % 38);
    ctx.beginPath();
    ctx.arc(x, y, ringRadius, 0, TAU);
    ctx.strokeStyle = `rgba(192, 255, 92, ${(1 - ((time * 54) % 38) / 38) * 0.58})`;
    ctx.lineWidth = 2.3;
    ctx.stroke();
  }

  traceCell(ctx, x, y, radius + pulse, time, infection);
  ctx.shadowColor = infection > 0 ? "rgba(161, 255, 101, 0.45)" : "rgba(205, 90, 238, 0.35)";
  ctx.shadowBlur = 26;
  const membrane = ctx.createLinearGradient(x - radius, y - radius, x + radius, y + radius);
  membrane.addColorStop(0, infection > 0.5 ? "#ffc5ee" : "#f3a9ef");
  membrane.addColorStop(0.45, infection > 0.6 ? "#e895d8" : "#d36adf");
  membrane.addColorStop(1, infection > 0.75 ? "#b6e988" : "#9457d7");
  ctx.fillStyle = membrane;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = 4.5;
  ctx.strokeStyle = infection > 0.65 ? "rgba(211, 255, 142, 0.92)" : "rgba(255, 207, 249, 0.84)";
  ctx.stroke();

  traceCell(ctx, x, y, radius - 9 + pulse * 0.35, time + 1.2, infection * 0.5);
  ctx.strokeStyle = "rgba(255, 236, 255, 0.35)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.save();
  traceCell(ctx, x, y, radius + pulse, time, infection);
  ctx.clip();

  const contents = ctx.createRadialGradient(x - 26, y - 35, 2, x, y, radius * 1.15);
  contents.addColorStop(0, "rgba(255, 226, 255, 0.64)");
  contents.addColorStop(0.46, "rgba(239, 163, 245, 0.23)");
  contents.addColorStop(1, "rgba(113, 57, 187, 0.23)");
  ctx.fillStyle = contents;
  ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);

  const organelles = [
    [-0.59, -0.19, 7], [0.59, -0.3, 5], [0.48, 0.49, 6], [-0.4, 0.55, 4.5],
    [0.1, -0.68, 4], [-0.68, 0.25, 3.5], [0.22, 0.69, 4], [0.72, 0.1, 3.5],
  ];
  for (let i = 0; i < organelles.length; i += 1) {
    const [ox, oy, size] = organelles[i];
    const drift = Math.sin(time * 1.5 + i) * 2;
    ctx.beginPath();
    ctx.ellipse(x + ox * radius + drift, y + oy * radius, size * 1.4, size * 0.78, i * 0.7, 0, TAU);
    ctx.fillStyle = i % 2 ? "rgba(255, 229, 255, 0.78)" : "rgba(172, 82, 204, 0.46)";
    ctx.fill();
  }

  const nucleusX = x - radius * 0.12;
  const nucleusY = y + radius * 0.02;
  const nucleusRadius = radius * 0.38;
  const nucleus = ctx.createRadialGradient(nucleusX - 10, nucleusY - 12, 3, nucleusX, nucleusY, nucleusRadius);
  nucleus.addColorStop(0, "#fce5ff");
  nucleus.addColorStop(0.37, "#cf8af0");
  nucleus.addColorStop(1, "#7950ca");
  ctx.beginPath();
  ctx.ellipse(nucleusX, nucleusY, nucleusRadius * (1 + infection * 0.11), nucleusRadius * 0.91, -0.25 + Math.sin(time) * 0.025, 0, TAU);
  ctx.fillStyle = nucleus;
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = "rgba(255, 226, 255, 0.9)";
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(nucleusX + 7, nucleusY - 4, nucleusRadius * 0.23, 0, TAU);
  ctx.fillStyle = infection > 0.5 ? "#b5ff7d" : "#fae1ff";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(nucleusX - 9, nucleusY + 11, 3, 0, TAU);
  ctx.fillStyle = "rgba(90, 47, 159, 0.68)";
  ctx.fill();

  if (infection > 0.12) {
    ctx.globalAlpha = infection * 0.72;
    ctx.strokeStyle = "#bcff66";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    for (let i = 0; i < 5; i += 1) {
      const angle = i * (TAU / 5) + time * 0.34;
      const inner = radius * 0.26;
      const outer = radius * (0.52 + 0.2 * infection);
      ctx.beginPath();
      ctx.moveTo(nucleusX + Math.cos(angle) * inner, nucleusY + Math.sin(angle) * inner);
      ctx.quadraticCurveTo(x + Math.cos(angle + 0.22) * radius * 0.38, y + Math.sin(angle + 0.22) * radius * 0.38, x + Math.cos(angle) * outer, y + Math.sin(angle) * outer);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  ctx.restore();

  ctx.beginPath();
  ctx.ellipse(x - radius * 0.38, y - radius * 0.52, radius * 0.2, radius * 0.08, -0.55, 0, TAU);
  ctx.fillStyle = "rgba(255, 255, 255, 0.38)";
  ctx.fill();
  ctx.restore();
}

function drawDna(ctx: CanvasRenderingContext2D, particle: DnaParticle, time: number) {
  if (!particle.active) return;
  const bob = Math.sin(time * 2.1 + particle.phase) * 3;
  const spin = Math.sin(time * 1.1 + particle.phase) * 0.18;
  ctx.save();
  ctx.translate(particle.x, particle.y + bob);
  ctx.rotate(spin);

  ctx.shadowColor = "rgba(93, 255, 222, 0.8)";
  ctx.shadowBlur = 17;
  const halo = ctx.createRadialGradient(0, 0, 1, 0, 0, 24);
  halo.addColorStop(0, "rgba(167, 255, 233, 0.34)");
  halo.addColorStop(1, "rgba(77, 255, 217, 0)");
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(0, 0, 24, 0, TAU);
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.strokeStyle = "rgba(157, 255, 229, 0.31)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(0, 0, 17 + Math.sin(time * 1.5 + particle.phase) * 1.8, 8, 0, 0, TAU);
  ctx.stroke();

  const y1 = -12;
  const y2 = 12;
  ctx.lineCap = "round";
  ctx.lineWidth = 3;
  for (let strand = 0; strand < 2; strand += 1) {
    ctx.beginPath();
    for (let i = 0; i <= 14; i += 1) {
      const progress = i / 14;
      const py = y1 + (y2 - y1) * progress;
      const px = Math.sin(progress * Math.PI * 2 + particle.phase + strand * Math.PI) * 7;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.strokeStyle = strand === 0 ? "#baff61" : "#63f7df";
    ctx.shadowColor = strand === 0 ? "#baff61" : "#63f7df";
    ctx.shadowBlur = 7;
    ctx.stroke();
  }
  ctx.shadowBlur = 0;
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 5; i += 1) {
    const progress = (i + 0.5) / 5;
    const py = y1 + (y2 - y1) * progress;
    const px = Math.sin(progress * Math.PI * 2 + particle.phase) * 7;
    const other = Math.sin(progress * Math.PI * 2 + particle.phase + Math.PI) * 7;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(other, py);
    ctx.strokeStyle = "rgba(222, 255, 239, 0.8)";
    ctx.stroke();
  }
  ctx.restore();
}

function drawMedicine(ctx: CanvasRenderingContext2D, medicine: Medicine, time: number) {
  const palette = [
    ["#ff806e", "#f34776", "#ffe0b7"],
    ["#60d8e9", "#387be4", "#d9fcff"],
    ["#c47dfa", "#7252df", "#f5ddff"],
  ][medicine.kind];
  const angle = Math.atan2(medicine.vy + Math.sin(time + medicine.phase) * 13, medicine.vx + Math.cos(time + medicine.phase) * 14);

  ctx.save();
  ctx.translate(medicine.x, medicine.y);
  ctx.beginPath();
  ctx.ellipse(0, 17, 33, 8, 0, 0, TAU);
  ctx.fillStyle = "rgba(0, 5, 15, 0.3)";
  ctx.fill();

  ctx.rotate(angle);
  ctx.beginPath();
  ctx.arc(0, 0, 36 + Math.sin(time * 2.8 + medicine.phase) * 2, 0, TAU);
  ctx.strokeStyle = `${palette[0]}30`;
  ctx.lineWidth = 1.5;
  ctx.setLineDash([3, 8]);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.shadowColor = `${palette[0]}99`;
  ctx.shadowBlur = 17;
  roundedRectPath(ctx, -30, -15, 60, 30, 15);
  const shell = ctx.createLinearGradient(0, -17, 0, 18);
  shell.addColorStop(0, "#fffefa");
  shell.addColorStop(0.56, "#f6f2f4");
  shell.addColorStop(1, "#c7cbd5");
  ctx.fillStyle = shell;
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.save();
  roundedRectPath(ctx, -30, -15, 60, 30, 15);
  ctx.clip();
  const medicineColor = ctx.createLinearGradient(-4, -15, 8, 15);
  medicineColor.addColorStop(0, palette[0]);
  medicineColor.addColorStop(1, palette[1]);
  ctx.fillStyle = medicineColor;
  ctx.fillRect(-2, -17, 34, 34);
  ctx.fillStyle = "rgba(255, 255, 255, 0.56)";
  ctx.fillRect(-2.5, -15, 3, 30);
  ctx.beginPath();
  ctx.ellipse(-12, -8, 9, 2.5, -0.18, 0, TAU);
  ctx.fillStyle = "rgba(255, 255, 255, 0.78)";
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(-14, 0);
  ctx.strokeStyle = palette[1];
  ctx.lineWidth = 2.6;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-4, 0);
  ctx.lineTo(4, 0);
  ctx.moveTo(0, -4);
  ctx.lineTo(0, 4);
  ctx.stroke();
  ctx.restore();

  ctx.lineWidth = 1.7;
  ctx.strokeStyle = "rgba(255, 255, 255, 0.78)";
  roundedRectPath(ctx, -30, -15, 60, 30, 15);
  ctx.stroke();
  ctx.restore();
}

function drawVirus(ctx: CanvasRenderingContext2D, world: GameWorld) {
  const player = world.player;
  const bob = Math.sin(world.time * 4.2) * 1.8;
  const blink = Math.sin(world.time * 0.77 + 1) > 0.995;
  const damageBlink = player.invulnerable > 0 && Math.floor(world.time * 15) % 2 === 0;
  if (damageBlink) return;

  ctx.save();
  ctx.translate(player.x, player.y + bob);

  const shadow = ctx.createRadialGradient(2, 20, 2, 2, 20, 38);
  shadow.addColorStop(0, "rgba(0, 0, 0, 0.36)");
  shadow.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = shadow;
  ctx.beginPath();
  ctx.ellipse(2, 20, 37, 20, 0, 0, TAU);
  ctx.fill();

  const glow = ctx.createRadialGradient(0, 0, 12, 0, 0, 52);
  glow.addColorStop(0, "rgba(163, 255, 66, 0.28)");
  glow.addColorStop(1, "rgba(113, 252, 62, 0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, 52, 0, TAU);
  ctx.fill();

  ctx.save();
  ctx.rotate(player.facing * 0.06);
  const points = 36;
  ctx.beginPath();
  for (let i = 0; i <= points; i += 1) {
    const angle = (i / points) * TAU;
    const spike = i % 3 === 0;
    const radius = (spike ? 39 : 31.5) + Math.sin(i * 4.1 + world.time * 4) * (spike ? 1.4 : 0.6);
    const px = Math.cos(angle) * radius;
    const py = Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  const body = ctx.createRadialGradient(-11, -15, 4, 4, 3, 43);
  body.addColorStop(0, "#e0ff84");
  body.addColorStop(0.34, "#91f246");
  body.addColorStop(0.75, "#54cf47");
  body.addColorStop(1, "#24995a");
  ctx.fillStyle = body;
  ctx.shadowColor = "rgba(130, 255, 84, 0.72)";
  ctx.shadowBlur = 17;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = 3.3;
  ctx.strokeStyle = "#164f49";
  ctx.lineJoin = "round";
  ctx.stroke();
  ctx.restore();

  ctx.beginPath();
  ctx.arc(-8, -14, 19, 3.5, 5.35);
  ctx.strokeStyle = "rgba(244, 255, 191, 0.65)";
  ctx.lineWidth = 2.4;
  ctx.lineCap = "round";
  ctx.stroke();

  const lookX = Math.cos(player.facing) * 2.3;
  const lookY = Math.sin(player.facing) * 1.8;
  const eyeHeight = blink ? 2.5 : 12;
  for (const eye of [{ x: -10, y: -5, rx: 7.3 }, { x: 10, y: -5, rx: 6.8 }]) {
    ctx.beginPath();
    ctx.ellipse(eye.x, eye.y, eye.rx, eyeHeight, 0, 0, TAU);
    ctx.fillStyle = "#fffdf1";
    ctx.fill();
    if (!blink) {
      ctx.beginPath();
      ctx.ellipse(eye.x + lookX, eye.y + 1.2 + lookY, 3.05, 4.2, 0, 0, TAU);
      ctx.fillStyle = "#173c3c";
      ctx.fill();
      ctx.beginPath();
      ctx.arc(eye.x + lookX - 0.75, eye.y - 0.2 + lookY, 1.15, 0, TAU);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
    }
  }

  ctx.strokeStyle = "#174d42";
  ctx.lineWidth = 2.2;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-17, -18);
  ctx.quadraticCurveTo(-12, -21, -7, -18);
  ctx.moveTo(6, -18);
  ctx.quadraticCurveTo(11, -21, 16, -17);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(-8, 11);
  ctx.quadraticCurveTo(1, 19 + Math.sin(world.time * 3) * 1.5, 10, 10);
  ctx.strokeStyle = "#19493e";
  ctx.lineWidth = 2.6;
  ctx.stroke();

  ctx.beginPath();
  ctx.ellipse(-20, 4, 3.2, 2.1, -0.25, 0, TAU);
  ctx.ellipse(20, 4, 3.2, 2.1, 0.25, 0, TAU);
  ctx.fillStyle = "rgba(255, 150, 144, 0.66)";
  ctx.fill();

  for (let i = 0; i < 4; i += 1) {
    const angle = i * 1.58 + world.time * 0.7;
    ctx.beginPath();
    ctx.arc(Math.cos(angle) * 48, Math.sin(angle) * 43, 1.7, 0, TAU);
    ctx.fillStyle = "rgba(204, 255, 143, 0.75)";
    ctx.fill();
  }
  ctx.restore();
}

function drawEffects(ctx: CanvasRenderingContext2D, effects: BurstParticle[]) {
  for (const effect of effects) {
    const progress = 1 - effect.life / effect.duration;
    const alpha = clamp(effect.life / effect.duration, 0, 1);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.shadowColor = effect.color;
    ctx.shadowBlur = 9;
    ctx.fillStyle = effect.color;
    ctx.beginPath();
    ctx.arc(effect.x, effect.y, effect.radius * (0.55 + progress * 0.45), 0, TAU);
    ctx.fill();
    ctx.restore();
  }
}

function drawVignette(ctx: CanvasRenderingContext2D, world: GameWorld) {
  const { width, height } = world;
  const vignette = ctx.createRadialGradient(width * 0.52, height * 0.47, height * 0.2, width * 0.52, height * 0.47, width * 0.76);
  vignette.addColorStop(0, "rgba(0, 0, 0, 0)");
  vignette.addColorStop(1, "rgba(2, 7, 18, 0.38)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);
}

export function drawWorld(ctx: CanvasRenderingContext2D, world: GameWorld) {
  ctx.clearRect(0, 0, world.width, world.height);
  drawArena(ctx, world);

  ctx.save();
  if (world.shake > 0.1) {
    const strength = world.shake;
    ctx.translate(Math.sin(world.time * 62) * strength, Math.cos(world.time * 51) * strength * 0.55);
  }

  drawCell(ctx, world);
  for (const particle of world.dna) drawDna(ctx, particle, world.time);
  for (const medicine of world.medicines) drawMedicine(ctx, medicine, world.time);
  drawEffects(ctx, world.effects);
  drawVirus(ctx, world);
  ctx.restore();
  drawVignette(ctx, world);
}