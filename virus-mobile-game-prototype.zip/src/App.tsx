import { useCallback, useEffect, useRef, useState, type PointerEvent } from "react";
import { createWorld, resizeWorld, updateWorld, type GamePhase, type GameWorld, type InputState } from "./game/model";
import { drawWorld } from "./game/render";

interface HudState {
  phase: GamePhase;
  energy: number;
  health: number;
  infectionProgress: number;
  toast: string;
  toastKind: "info" | "warning" | "success";
  toastId: number;
}

const initialHud: HudState = {
  phase: "ready",
  energy: 0,
  health: 3,
  infectionProgress: 0,
  toast: "",
  toastKind: "info",
  toastId: 0,
};

function VirusMark({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 52 52" fill="none" aria-hidden="true">
      <path d="M25.9 4.4 30 10.7 37.2 7.8 38.2 15.5 46 17.5 42.2 24.3 47.1 30.3 39.8 33.2 40.3 41 32.5 40.2 28.2 47 22.8 41.4 15.5 44.2 14.5 36.5 6.9 34.6 10.6 27.7 5.7 21.7 13 18.8 12.5 11 20.3 11.8Z" fill="url(#mark-fill)" stroke="#234c37" strokeWidth="2.2" strokeLinejoin="round" />
      <ellipse cx="21" cy="24" rx="3.1" ry="4.2" fill="#fffef2" />
      <ellipse cx="31.7" cy="23.5" rx="3" ry="4" fill="#fffef2" />
      <circle cx="21.7" cy="25.3" r="1.45" fill="#173c3c" />
      <circle cx="32.2" cy="24.8" r="1.4" fill="#173c3c" />
      <path d="M22.5 32.2c2.5 2.1 5 2.1 7.7-.2" stroke="#17483d" strokeWidth="2.2" strokeLinecap="round" />
      <defs>
        <linearGradient id="mark-fill" x1="13" y1="9" x2="39" y2="43" gradientUnits="userSpaceOnUse">
          <stop stopColor="#D8FF7D" />
          <stop offset=".54" stopColor="#82E84D" />
          <stop offset="1" stopColor="#37B66A" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function DnaIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M7 3c10 5 10 13 0 18M17 3C7 8 7 16 17 21M8 6h8M7.3 10h9.4M7.3 14h9.4M8 18h8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="7" cy="3.5" r="1.3" fill="currentColor" />
      <circle cx="17" cy="20.5" r="1.3" fill="currentColor" />
    </svg>
  );
}

function CellIcon() {
  return (
    <svg viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <path d="M24 4.8c3.4 1.4 5.2-.7 8.2.6 3 1.2 3.1 4.5 5.5 6.4 2.4 1.9 5.6 2 6.5 5.1.9 3.1-1.5 5-1.2 8.1.3 3.2 2.6 5.8.8 8.5-1.8 2.7-4.9 2.2-7.3 4.4-2.4 2.2-3 5-6.2 5.5-3.1.5-4.6-2.3-7.9-2.5-3.2-.2-6.2 1.6-8.7-.5-2.4-2.1-1.1-5.1-2.8-8-1.7-2.8-4.6-4.2-4.3-7.4.2-3.1 3.1-4.5 3.9-7.6.8-3.1-.1-6.2 2.6-8.1 2.7-1.9 5.3-.3 8.3-1.2C20.5 7.3 21.1 3.6 24 4.8Z" fill="url(#cell-icon-fill)" stroke="#b26fe0" strokeWidth="1.4" />
      <circle cx="25" cy="24" r="8.6" fill="url(#nucleus-icon-fill)" stroke="#fff0ff" strokeWidth="1.4" />
      <circle cx="27.8" cy="22.3" r="2.4" fill="#f2d9ff" />
      <circle cx="15.5" cy="20.5" r="1.5" fill="#fff1ff" />
      <circle cx="34.5" cy="30.7" r="1.7" fill="#fff1ff" />
      <defs>
        <linearGradient id="cell-icon-fill" x1="10" y1="7" x2="37" y2="41" gradientUnits="userSpaceOnUse">
          <stop stopColor="#f6c1f1" />
          <stop offset="1" stopColor="#aa68d7" />
        </linearGradient>
        <radialGradient id="nucleus-icon-fill" cx="0" cy="0" r="1" gradientTransform="matrix(12 13 -13 12 20 17)" gradientUnits="userSpaceOnUse">
          <stop stopColor="#f4ddff" />
          <stop offset="1" stopColor="#8b5bd2" />
        </radialGradient>
      </defs>
    </svg>
  );
}

function Heart({ filled }: { filled: boolean }) {
  return (
    <svg className={`heart-icon${filled ? " is-filled" : ""}`} viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} aria-hidden="true">
      <path d="M20.5 8.7c0 5.2-8.5 11-8.5 11s-8.5-5.8-8.5-11a4.4 4.4 0 0 1 8.5-1.5 4.4 4.4 0 0 1 8.5 1.5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

function PauseIcon({ paused }: { paused: boolean }) {
  return paused ? (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m7 4.8 8 5.2-8 5.2V4.8Z" fill="currentColor" /></svg>
  ) : (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M6.5 5.2v9.6M13.5 5.2v9.6" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" /></svg>
  );
}

function RestartIcon() {
  return <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4.2 8.1a6.1 6.1 0 1 1 .7 5.5M4.2 4.9v3.7h3.7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function ArrowIcon() {
  return <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M3.5 10h12m-5-5 5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function phaseTitle(phase: GamePhase) {
  if (phase === "ready") return "Клетка здорова";
  if (phase === "playing") return "Клетка здорова";
  if (phase === "paused") return "На паузе";
  if (phase === "infecting") return "Идет заражение";
  if (phase === "won") return "Клетка заражена";
  return "Попытка окончена";
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<GameWorld>(createWorld());
  const keysRef = useRef<InputState>({ up: false, down: false, left: false, right: false });
  const [hud, setHud] = useState<HudState>(initialHud);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !context) return;

    let frameId = 0;
    let previousTime = performance.now();
    let hudClock = 0;
    let disposed = false;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const nextHeight = 700;
      const nextWidth = (rect.width / rect.height) * nextHeight;
      resizeWorld(worldRef.current, nextWidth, nextHeight);
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(rect.width * pixelRatio);
      canvas.height = Math.round(rect.height * pixelRatio);
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(canvas);
    resize();

    const animate = (now: number) => {
      if (disposed) return;
      const delta = Math.min((now - previousTime) / 1000, 0.04);
      previousTime = now;
      const world = worldRef.current;
      updateWorld(world, delta, keysRef.current);

      const scaleX = canvas.width / world.width;
      const scaleY = canvas.height / world.height;
      context.setTransform(scaleX, 0, 0, scaleY, 0, 0);
      drawWorld(context, world);

      hudClock += delta;
      if (hudClock >= 0.08) {
        hudClock = 0;
        const next: HudState = {
          phase: world.phase,
          energy: world.energy,
          health: world.health,
          infectionProgress: Math.round(world.infectionProgress * 50) / 50,
          toast: world.toast,
          toastKind: world.toastKind,
          toastId: world.toastId,
        };
        setHud((current) => {
          if (
            current.phase === next.phase && current.energy === next.energy && current.health === next.health &&
            current.infectionProgress === next.infectionProgress && current.toast === next.toast && current.toastId === next.toastId
          ) return current;
          return next;
        });
      }
      frameId = window.requestAnimationFrame(animate);
    };

    frameId = window.requestAnimationFrame(animate);
    return () => {
      disposed = true;
      window.cancelAnimationFrame(frameId);
      resizeObserver.disconnect();
    };
  }, []);

  useEffect(() => {
    const keyMap: Record<string, keyof InputState> = {
      ArrowUp: "up", w: "up", W: "up",
      ArrowDown: "down", s: "down", S: "down",
      ArrowLeft: "left", a: "left", A: "left",
      ArrowRight: "right", d: "right", D: "right",
    };

    const onKeyDown = (event: KeyboardEvent) => {
      const key = keyMap[event.key];
      if (key) {
        keysRef.current[key] = true;
        if (event.key.startsWith("Arrow")) event.preventDefault();
      }
      if (event.key === "Escape" && !event.repeat) {
        const world = worldRef.current;
        if (world.phase === "playing" || world.phase === "infecting") {
          world.resumePhase = world.phase;
          world.phase = "paused";
        } else if (world.phase === "paused") {
          world.phase = world.resumePhase ?? "playing";
          world.resumePhase = null;
        }
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const key = keyMap[event.key];
      if (key) keysRef.current[key] = false;
    };
    const clearKeys = () => {
      keysRef.current = { up: false, down: false, left: false, right: false };
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", clearKeys);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clearKeys);
    };
  }, []);

  const moveTarget = useCallback((event: PointerEvent<HTMLCanvasElement>) => {
    const world = worldRef.current;
    if (world.phase !== "playing") return;
    const rect = event.currentTarget.getBoundingClientRect();
    world.player.targetX = Math.max(34, Math.min(world.width - 34, ((event.clientX - rect.left) / rect.width) * world.width));
    world.player.targetY = Math.max(42, Math.min(world.height - 42, ((event.clientY - rect.top) / rect.height) * world.height));
  }, []);

  const startGame = useCallback(() => {
    const current = worldRef.current;
    const fresh = createWorld(current.width, current.height, "playing");
    worldRef.current = fresh;
    keysRef.current = { up: false, down: false, left: false, right: false };
    setHud({ ...initialHud, phase: "playing" });
  }, []);

  const showMenu = useCallback(() => {
    const current = worldRef.current;
    worldRef.current = createWorld(current.width, current.height, "ready");
    keysRef.current = { up: false, down: false, left: false, right: false };
    setHud(initialHud);
  }, []);

  const togglePause = useCallback(() => {
    const world = worldRef.current;
    if (world.phase === "playing" || world.phase === "infecting") {
      world.resumePhase = world.phase;
      world.phase = "paused";
    } else if (world.phase === "paused") {
      world.phase = world.resumePhase ?? "playing";
      world.resumePhase = null;
    }
  }, []);

  const pointDown = (event: PointerEvent<HTMLCanvasElement>) => {
    if (event.pointerType === "touch") event.preventDefault();
    if (event.currentTarget.hasPointerCapture(event.pointerId)) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    moveTarget(event);
  };

  const paused = hud.phase === "paused";
  const energyProgress = Math.min(100, (hud.energy / 72) * 100);
  const goalProgress = hud.phase === "won" ? 100 : hud.phase === "infecting" ? hud.infectionProgress * 100 : 0;
  const feedback = hud.toast || (hud.phase === "ready"
    ? "Собирай спирали ДНК и избегай аптечек."
    : hud.phase === "paused"
      ? "Время остановлено. Можно перевести дух."
      : "Веди вирус к клетке, не касаясь лекарств.");

  let overlayTitle = "Побег из чашки";
  let overlayText = "Собирай энергию, уворачивайся от лекарств и найди розовую клетку.";
  let overlayAction = "Начать заражение";
  let overlayActionHandler = startGame;
  if (hud.phase === "paused") {
    overlayTitle = "Передышка";
    overlayText = "Арена замерла. Вирус готов продолжить охоту за клеткой.";
    overlayAction = "Продолжить";
    overlayActionHandler = togglePause;
  } else if (hud.phase === "won") {
    overlayTitle = "Клетка заражена!";
    overlayText = `Отличный побег. За эту попытку собрано ${hud.energy} единиц энергии.`;
    overlayAction = "Играть еще раз";
    overlayActionHandler = startGame;
  } else if (hud.phase === "gameover") {
    overlayTitle = "Лекарства победили";
    overlayText = "Ничего страшного: маршрут тот же, а аптечки снова будут двигаться.";
    overlayAction = "Попробовать снова";
    overlayActionHandler = startGame;
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark-wrap"><VirusMark className="brand-mark" /></div>
          <div className="brand-type">
            <div className="brand-word">VIRUS<span className="brand-period">.</span></div>
            <div className="brand-subtitle">МИКРОМИР В ТВОИХ РУКАХ</div>
          </div>
        </div>
        <div className="topbar-meta">
          <span className="meta-index">АРЕНА <b>01</b></span>
          <span className="meta-divider" />
          <span className="prototype-indicator"><i /> ПРОТОТИП</span>
        </div>
      </header>

      <main className="game-layout">
        <section className="stage-section" aria-label="Игровая арена">
          <div className={`game-stage phase-${hud.phase}`}>
            <canvas
              ref={canvasRef}
              className="game-canvas"
              aria-label="Игра VIRUS. Управляйте вирусом курсором, касанием или стрелками."
              onPointerMove={moveTarget}
              onPointerDown={pointDown}
            />

            <div className="stage-topline" aria-hidden="true">
              <span className="stage-label"><i /> БИОЛОГИЧЕСКИЙ КОНТУР <b>01</b></span>
              <span className="stage-objective"><span className="objective-dot" /> ЦЕЛЬ: РОЗОВАЯ КЛЕТКА</span>
            </div>

            {hud.phase === "infecting" && (
              <div className="infection-callout" aria-live="polite">
                <span className="infection-spark" /> ЗАРАЖЕНИЕ <b>{Math.round(hud.infectionProgress * 100)}%</b>
              </div>
            )}

            {hud.phase !== "playing" && hud.phase !== "infecting" && (
              <div className={`game-overlay overlay-${hud.phase}`}>
                <div className="overlay-panel" role="dialog" aria-modal="true" aria-labelledby="overlay-title">
                  <div className="overlay-emblem"><VirusMark className="overlay-virus-mark" /></div>
                  <div className="overlay-kicker"><span /> МИССИЯ 01 <span /></div>
                  <h1 id="overlay-title">{overlayTitle}</h1>
                  <p>{overlayText}</p>
                  <button className="primary-button" onClick={overlayActionHandler}>
                    <span>{overlayAction}</span>
                    <span className="button-arrow"><ArrowIcon /></span>
                  </button>
                  {hud.phase === "ready" ? (
                    <div className="overlay-controls"><span>МЫШЬ</span><i /> КУРСОР / КАСАНИЕ <i /> WASD</div>
                  ) : hud.phase === "won" ? (
                    <button className="text-button" onClick={showMenu}>Вернуться в меню</button>
                  ) : null}
                </div>
              </div>
            )}

            <div className="stage-bottomline" aria-hidden="true">
              <span><span className="coordinates-dot" /> КАМЕРА / ВИД СВЕРХУ</span>
              <span>АВТОМАСШТАБ <i>/ 01</i></span>
            </div>
          </div>
          <div className="stage-footnote">
            <span>СИМБИОЗ: ЭТО НЕ ВАРИАНТ.</span>
            <span className="footnote-rule" />
            <span>НАЙДИ ЦЕЛЬ. СТАНЬ ШТАММОМ.</span>
          </div>
        </section>

        <aside className="control-panel" aria-label="Игровые показатели и управление">
          <div className="panel-heading">
            <span>ПАНЕЛЬ ВИРУСА</span>
            <span className="panel-heading-code">V-01</span>
          </div>

          <section className="energy-section" aria-label="Энергия">
            <div className="section-label-row">
              <span className="section-label"><DnaIcon className="section-dna-icon" /> ЭНЕРГИЯ</span>
              <span className="energy-counter"><b>{String(hud.energy).padStart(2, "0")}</b><i>ЕД</i></span>
            </div>
            <div className="energy-meter" role="progressbar" aria-label="Накопленная энергия" aria-valuemin={0} aria-valuemax={72} aria-valuenow={Math.min(hud.energy, 72)}>
              <span style={{ width: `${energyProgress}%` }} />
            </div>
            <div className="energy-caption"><span>СПИРАЛИ ДНК</span><span>+12 ЗА ШТУКУ</span></div>
          </section>

          <section className="goal-section" aria-label="Состояние цели">
            <div className="goal-row">
              <div className="cell-icon-wrap"><CellIcon /></div>
              <div className="goal-copy">
                <span className="section-label">ЦЕЛЬ</span>
                <strong>{phaseTitle(hud.phase)}</strong>
              </div>
              <span className={`goal-live${hud.phase === "won" ? " is-infected" : hud.phase === "infecting" ? " is-infection" : ""}`}>
                {hud.phase === "won" ? "ГОТОВО" : hud.phase === "infecting" ? "" : hud.phase === "gameover" ? "СТОП" : "ЖИВА"}
              </span>
            </div>
            <div className={`goal-meter${hud.phase === "infecting" || hud.phase === "won" ? " goal-meter-active" : ""}`}>
              <span style={{ width: `${goalProgress}%` }} />
            </div>
            <p className="goal-caption">Заражение начинается только при касании клетки.</p>
          </section>

          <section className="health-section" aria-label={`Осталось жизней: ${hud.health} из 3`}>
            <div>
              <span className="section-label">ЗАПАС ПРОЧНОСТИ</span>
              <span className="health-caption">Берегись аптечек</span>
            </div>
            <div className="health-icons">
              {[0, 1, 2].map((index) => <Heart key={index} filled={index < hud.health} />)}
            </div>
          </section>

          <div className={`feedback-note feedback-${hud.toast ? hud.toastKind : "info"}`} aria-live="polite" key={hud.toastId}>
            <span className="feedback-mark">{hud.toastKind === "warning" && hud.toast ? "!" : "+"}</span>
            <span>{feedback}</span>
          </div>

          <section className="controls-section" aria-label="Управление">
            <div className="section-label controls-title">УПРАВЛЕНИЕ</div>
            <div className="control-line">
              <span className="key-cluster" aria-hidden="true"><i>W</i><span><i>A</i><i>S</i><i>D</i></span></span>
              <span><b>Курсор</b><small>Мышь или палец</small></span>
            </div>
            <p className="mobile-control-hint">На телефоне удерживай и веди пальцем по арене.</p>
          </section>

          <div className="action-row">
            <button className="pause-button" onClick={togglePause} disabled={hud.phase === "ready" || hud.phase === "won" || hud.phase === "gameover"}>
              <span className="action-icon"><PauseIcon paused={paused} /></span>
              <span>{paused ? "Продолжить" : "Пауза"}</span>
              <kbd>ESC</kbd>
            </button>
            <button className="restart-button" onClick={startGame} aria-label="Перезапустить уровень" title="Перезапустить уровень">
              <RestartIcon />
            </button>
          </div>
          <div className="panel-footnote"><span>ПЕРВЫЙ ШТАММ</span><span>VER. 1.0</span></div>
        </aside>
      </main>

      <footer className="page-footer">
        <span>VIRUS <i>©</i> 2026</span>
        <span>СДЕЛАНО ИЗ ЛЮБОПЫТСТВА И ПАРЫ КОЛЮЧЕК</span>
        <span>БЕРЕГИ СЕБЯ / ЗАРАЖАЙ ДРУГИХ</span>
      </footer>
    </div>
  );
}